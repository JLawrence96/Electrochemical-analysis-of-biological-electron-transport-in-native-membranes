%% Plotting inhibition changes

%% Data Input
inhibitor_names = ["DMSO" "DCMU" "HQNO" "PMA"];
load NatureColours.mat
inhibitor_colors = [greens(3,:) ; blues(3,:) ; reds(3,:) ; yellows(4,:) ; greens(2,:)];
units = ["mM" "\muM" "\muM" "\muM"];
largest_replicate_number = 3;

alter_x_axis = [10^-6/10 0];
alter_y_axis_dark_currents = [0 0];
alter_y_axis_photocurrents = [0 0];
alter_y_axis_spike_charges = [0 120];
alter_y_axis_dip_charges = [0 0];

%% Processing
for z = 1:length(inhibitor_names)
    run(append("C03_T_",inhibitor_names(z),"_Paper"))
    close all 
    
    if units(z) == "mM"
        concentrations(z,:) = concentrations_uM;
    else
        concentrations(z,:) = concentrations_uM./1000;
    end
    
    C03_T_AllInhibitors_dark_currents_inhibition(:,[1:no_replicates largest_replicate_number+1 largest_replicate_number+2],z) = C03_T_Inhibitor_dark_currents_inhibition;
    C03_T_AllInhibitors_photocurrents_inhibition(:,[1:no_replicates largest_replicate_number+1 largest_replicate_number+2],z) = C03_T_Inhibitor_photocurrents_inhibition;
    C03_T_AllInhibitors_spike_charges_inhibition(:,[1:no_replicates largest_replicate_number+1 largest_replicate_number+2],z) = C03_T_Inhibitor_spike_charges_inhibition;
    C03_T_AllInhibitors_dip_charges_inhibition(:,[1:no_replicates largest_replicate_number+1 largest_replicate_number+2],z) = C03_T_Inhibitor_dip_charges_inhibition;
    
    clear concentrations_uM;
    clear C03_T_Inhibitor_dark_currents;
    clear C03_T_Inhibitor_photocurrents;
    clear C03_T_Inhibitor_spike_charges;
    clear C03_T_Inhibitor_dip_charges;
    clear C03_T_Inhibitor_dark_currents_relative;
    clear C03_T_Inhibitor_photocurrents_relative;
    clear C03_T_Inhibitor_spike_charges_relative;
    clear C03_T_Inhibitor_dip_charges_relative;  
    clear C03_T_Inhibitor_dark_currents_inhibition;
    clear C03_T_Inhibitor_photocurrents_inhibition;
    clear C03_T_Inhibitor_spike_charges_inhibition;
    clear C03_T_Inhibitor_dip_charges_inhibition;
end


C03_T_AllInhibitors_photocurrents_relative = 100 - C03_T_AllInhibitors_photocurrents_inhibition(:,1:end,:);
C03_T_AllInhibitors_photocurrents_relative(:,end,:) = C03_T_AllInhibitors_photocurrents_inhibition(:,end,:);
min_threshold_photocurrent = max(C03_T_AllInhibitors_photocurrents_relative(:,end-1,1) + C03_T_AllInhibitors_photocurrents_relative(:,end,1));
max_threshold_photocurrent = min(C03_T_AllInhibitors_photocurrents_relative(:,end-1,1) - C03_T_AllInhibitors_photocurrents_relative(:,end,1));

C03_T_AllInhibitors_spike_charges_relative = 100 - C03_T_AllInhibitors_spike_charges_inhibition(:,1:end,:);
C03_T_AllInhibitors_spike_charges_relative(:,end,:) = C03_T_AllInhibitors_spike_charges_inhibition(:,end,:);
min_threshold_spike_charge = max(C03_T_AllInhibitors_spike_charges_relative(:,end-1,1) + C03_T_AllInhibitors_spike_charges_relative(:,end,1));
max_threshold_spike_charge = min(C03_T_AllInhibitors_spike_charges_relative(:,end-1,1) - C03_T_AllInhibitors_spike_charges_relative(:,end,1));


concentrations_plot = concentrations;
concentrations_plot(:,1) = min(min(concentrations(2:end,2:end)))/10;

max_conc = max(max(concentrations_plot(2:end,:)));

if floor(log10(max_conc)) == log10(max_conc)
    x_upper = max_conc+(max_conc/10);
else
    x_upper = 10^ceil(log10(max_conc));
end

%% Plotting inhibition 

% dark_currents
x_lower = min(min(concentrations_plot));

for y = 1:length(inhibitor_names)
    p_C03_T_AllInhibitors_dark_currents_inhibition(y) = errorbar(concentrations_plot(y,:),C03_T_AllInhibitors_dark_currents_inhibition(:,end-1,y),C03_T_AllInhibitors_dark_currents_inhibition(:,end,y),'Color',inhibitor_colors(y,:),'LineWidth',2.5);
    hold on
end

xlabel({append("[Inhibitor] (mM)")});
ylabel({'Dark Current Inhibition (%)'});
box off 

legend([p_C03_T_AllInhibitors_dark_currents_inhibition(1:length(inhibitor_names))],[inhibitor_names],'location','northwest');
legend('AutoUpdate','off')
legend box off

y_lower_dark_currents = 0;
y_lower_dark_currents = y_lower_dark_currents-alter_y_axis_dark_currents(1);
y_upper_dark_currents = 100;
y_upper_dark_currents = y_upper_dark_currents+alter_y_axis_dark_currents(2);

h = gca;
h.XTick = [10.^(1+log10(x_lower):2:log10(x_upper))];

set(gca,'xscale','log')
set(gca, 'layer', 'top')

% h.XTick = [logspace(log(concentrations_plot_DCMU(1))/log(10),log(concentrations_plot_DCMU(end))/log(10),length(concentrations_plot_DCMU))];
% h.XAxis.TickLength = [0.01 0.01];
% h.XMinorTick = 'off';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1.5;
text(concentrations_plot(1)*1.1,y_lower_dark_currents,'//','Color','black','FontSize',17); %inserting break symbols
% line([x_lower+(x_lower/2) x_lower+(1.7*(x_lower/2))],[y_lower_photocurrents y_lower_photocurrents],'LineWidth',2,'Color','white'); 
white_line = annotation('line',[0.187 0.196],[0.152 0.152],'LineWidth',2.2,'Color','white');    
if y_lower_dark_currents<-2
    yline(0,'k--','LineWidth',2)
else
end
hold off

x_lower = x_lower-alter_x_axis(1);
x_upper = x_upper+alter_x_axis(2);

xlim([x_lower x_upper])
ylim([y_lower_dark_currents y_upper_dark_currents])    

% Scaling and saving image
pbaspect([1 1.3 1]);
% h.XTickLabel{1} = [];
set(gcf,'color','none');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_Inhibitors_Dc','svg')

% Photocurrents
x_lower = min(min(concentrations_plot));

for y = 1:length(inhibitor_names)
    p_C03_T_AllInhibitors_photocurrents_inhibition(y) = errorbar(concentrations_plot(y,:),C03_T_AllInhibitors_photocurrents_inhibition(:,end-1,y),C03_T_AllInhibitors_photocurrents_inhibition(:,end,y),'Color',inhibitor_colors(y,:),'LineWidth',2.5);
    hold on
end

xlabel({append("[Inhibitor] (mM)")});
ylabel({'Steady State Photocurrent Inhibition (%)'});
box off 

legend([p_C03_T_AllInhibitors_photocurrents_inhibition(1:length(inhibitor_names))],[inhibitor_names],'location','northwest');
legend('AutoUpdate','off')
legend box off

y_lower_photocurrents = 0;
y_lower_photocurrents = y_lower_photocurrents-alter_y_axis_photocurrents(1);
y_upper_photocurrents = 100;
y_upper_photocurrents = y_upper_photocurrents+alter_y_axis_photocurrents(2);

h = gca;
h.XTick = [10.^(1+log10(x_lower):2:log10(x_upper))];

set(gca,'xscale','log')
set(gca, 'layer', 'top')

% h.XTick = [logspace(log(concentrations_plot_DCMU(1))/log(10),log(concentrations_plot_DCMU(end))/log(10),length(concentrations_plot_DCMU))];
% h.XAxis.TickLength = [0.01 0.01];
% h.XMinorTick = 'off';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1.5;
text(concentrations_plot(1)*1.1,y_lower_photocurrents,'//','Color','black','FontSize',17); %inserting break symbols
% line([x_lower+(x_lower/2) x_lower+(1.7*(x_lower/2))],[y_lower_photocurrents y_lower_photocurrents],'LineWidth',2,'Color','white'); 
white_line = annotation('line',[0.187 0.196],[0.152 0.152],'LineWidth',2.2,'Color','white');    

if y_lower_photocurrents<-2
    yline(0,'k--','LineWidth',2)
else
end
hold off

x_lower = x_lower-alter_x_axis(1);
x_upper = x_upper+alter_x_axis(2);

xlim([x_lower x_upper])
ylim([y_lower_photocurrents y_upper_photocurrents])    

% Scaling and saving image
pbaspect([1 1.3 1]);
% h.XTickLabel{1} = [];
set(gcf,'color','none');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_Inhibitors_Pc','svg')

% spike_charges
x_lower = min(min(concentrations_plot));

for y = 1:length(inhibitor_names)
    p_C03_T_AllInhibitors_spike_charges_inhibition(y) = errorbar(concentrations_plot(y,:),C03_T_AllInhibitors_spike_charges_inhibition(:,end-1,y),C03_T_AllInhibitors_spike_charges_inhibition(:,end,y),'Color',inhibitor_colors(y,:),'LineWidth',2.5);
    hold on
end

xlabel({append("[Inhibitor] (mM)")});
ylabel({'Spike Charge Inhibition (%)'});
box off 

legend([p_C03_T_AllInhibitors_spike_charges_inhibition(1:length(inhibitor_names))],[inhibitor_names],'location','southeast');
legend('AutoUpdate','off')
legend box off

y_lower_spike_charges = 0;
y_lower_spike_charges = y_lower_spike_charges-alter_y_axis_spike_charges(1);
y_upper_spike_charges = 100;
y_upper_spike_charges = y_upper_spike_charges+alter_y_axis_spike_charges(2);

h = gca;
h.XTick = [10.^(1+log10(x_lower):2:log10(x_upper))];

set(gca,'xscale','log')
set(gca, 'layer', 'top')

% h.XTick = [logspace(log(concentrations_plot_DCMU(1))/log(10),log(concentrations_plot_DCMU(end))/log(10),length(concentrations_plot_DCMU))];
% h.XAxis.TickLength = [0.01 0.01];
% h.XMinorTick = 'off';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1.5;
text(concentrations_plot(1)*1.1,y_lower_spike_charges,'//','Color','black','FontSize',17); %inserting break symbols
% line([x_lower+(x_lower/2) x_lower+(1.7*(x_lower/2))],[y_lower_photocurrents y_lower_photocurrents],'LineWidth',2,'Color','white'); 
white_line = annotation('line',[0.203 0.212],[0.16 0.16],'LineWidth',2.2,'Color','white');    

if y_lower_spike_charges<-2
    yline(0,'k--','LineWidth',2)
else
end

hold off

x_lower = x_lower-alter_x_axis(1);
x_upper = x_upper+alter_x_axis(2);

xlim([x_lower x_upper])
ylim([y_lower_spike_charges y_upper_spike_charges])    

% Scaling and saving image
pbaspect([1 1.3 1]);
% h.XTickLabel{1} = [];
set(gcf,'color','none');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_Inhibitors_Sp','svg')

% Dip charge
x_lower = min(min(concentrations_plot));

for y = 1:length(inhibitor_names)
    p_C03_T_AllInhibitors_dip_charges_inhibition(y) = errorbar(concentrations_plot(y,:),C03_T_AllInhibitors_dip_charges_inhibition(:,end-1,y),C03_T_AllInhibitors_dip_charges_inhibition(:,end,y),'Color',inhibitor_colors(y,:),'LineWidth',2.5);
    hold on
end

xlabel({append("[Inhibitor] (mM)")});
ylabel({'Dip Charge Inhibition (%)'});
box off 

legend([p_C03_T_AllInhibitors_dip_charges_inhibition(1:length(inhibitor_names))],[inhibitor_names],'location','northwest');
legend('AutoUpdate','off')
legend box off

y_lower_dip_charges = 0;
y_lower_dip_charges = y_lower_dip_charges-alter_y_axis_dip_charges(1);
y_upper_dip_charges = 100;
y_upper_dip_charges = y_upper_dip_charges+alter_y_axis_dip_charges(2);

h = gca;
h.XTick = [10.^(1+log10(x_lower):2:log10(x_upper))];

set(gca,'xscale','log')
set(gca, 'layer', 'top')

% h.XTick = [logspace(log(concentrations_plot_DCMU(1))/log(10),log(concentrations_plot_DCMU(end))/log(10),length(concentrations_plot_DCMU))];
% h.XAxis.TickLength = [0.01 0.01];
% h.XMinorTick = 'off';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1.5;
text(concentrations_plot(1)*1.1,y_lower_dip_charges,'//','Color','black','FontSize',17); %inserting break symbols
% line([x_lower+(x_lower/2) x_lower+(1.7*(x_lower/2))],[y_lower_photocurrents y_lower_photocurrents],'LineWidth',2,'Color','white'); 
white_line = annotation('line',[0.187 0.196],[0.152 0.152],'LineWidth',2.2,'Color','white');    
if y_lower_dip_charges<-2
    yline(0,'k--','LineWidth',2)
else
end
hold off

x_lower = x_lower-alter_x_axis(1);
x_upper = x_upper+alter_x_axis(2);

xlim([x_lower x_upper])
ylim([y_lower_dip_charges y_upper_dip_charges])    

% Scaling and saving image
pbaspect([1 1.3 1]);
% h.XTickLabel{1} = [];
set(gcf,'color','none');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_Inhibitors_Di','svg')

%% Plotting Relative Changes with DMSO box

% Photocurrents
x_lower = min(min(concentrations_plot));

for y = 2:length(inhibitor_names)
    p_C03_T_AllInhibitors_photocurrents_inhibition(y) = errorbar(concentrations_plot(y,:),C03_T_AllInhibitors_photocurrents_relative(:,end-1,y),C03_T_AllInhibitors_photocurrents_relative(:,end,y),'Color',inhibitor_colors(y,:),'LineWidth',2.5);
    hold on
end

xlabel({append("[Inhibitor] (\muM)")});
ylabel({'\DeltaSteady State Photocurrent (%)'});
box off 

legend([p_C03_T_AllInhibitors_photocurrents_inhibition(2:length(inhibitor_names))],[inhibitor_names(2:end)],'location','southwest');
legend('AutoUpdate','off')
legend box off

y_lower_photocurrents = 0;
y_lower_photocurrents = y_lower_photocurrents-alter_y_axis_photocurrents(1);
y_upper_photocurrents = 100;
y_upper_photocurrents = y_upper_photocurrents+alter_y_axis_photocurrents(2);

h = gca;
h.XTick = [10.^(1+log10(x_lower):1:log10(x_upper))];

set(gca,'xscale','log')
set(gca, 'layer', 'top')

% h.XTick = [logspace(log(concentrations_plot_DCMU(1))/log(10),log(concentrations_plot_DCMU(end))/log(10),length(concentrations_plot_DCMU))];
% h.XAxis.TickLength = [0.01 0.01];
% h.XMinorTick = 'off';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1.5;
text(concentrations_plot(1)*1.1,y_lower_photocurrents,'//','Color','black','FontSize',17); %inserting break symbols
% line([x_lower+(x_lower/2) x_lower+(1.7*(x_lower/2))],[y_lower_photocurrents y_lower_photocurrents],'LineWidth',2,'Color','white'); 
white_line = annotation('line',[0.187 0.196],[0.152 0.152],'LineWidth',2.2,'Color','white');    

if y_lower_photocurrents<-2
    yline(0,'k--','LineWidth',2)
else
end
hold on

x_lower = x_lower-alter_x_axis(1);
x_upper = x_upper+alter_x_axis(2);

xlim([x_lower x_upper])
ylim([y_lower_photocurrents y_upper_photocurrents]) 

threshold_box = area([x_lower x_upper],[min_threshold_spike_charge min_threshold_spike_charge]);
threshold_box.BaseValue = max_threshold_spike_charge;
threshold_box.FaceColor = inhibitor_colors(1,:);
threshold_box.EdgeColor = 'none';
threshold_box.BaseLine.Color = 'none';
uistack(threshold_box,'bottom');
hold on

text(concentrations_plot(1,1)*2,max_threshold_photocurrent-8,'DMSO','Color',inhibitor_colors(end,:),'FontSize',17);

% Scaling and saving image
pbaspect([1 1.3 1]);
% h.XTickLabel{1} = [];
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_Inhibitors_Pc','svg')
hold off

% spike_charges
x_lower = min(min(concentrations_plot));

for y = 2:length(inhibitor_names)
    p_C03_T_AllInhibitors_spike_charges_inhibition(y) = errorbar(concentrations_plot(y,:),C03_T_AllInhibitors_spike_charges_relative(:,end-1,y),C03_T_AllInhibitors_spike_charges_relative(:,end,y),'Color',inhibitor_colors(y,:),'LineWidth',2.5);
    hold on
end

xlabel({append("[Inhibitor] (\muM)")});
ylabel({'\DeltaSpike Charge Inhibition (%)'});
box off 

% legend([p_C03_T_AllInhibitors_spike_charges_inhibition(2:length(inhibitor_names))],[inhibitor_names(2:end)],'location','southwest');
% legend('AutoUpdate','off')
% legend box off

y_lower_spike_charges = 0;
y_lower_spike_charges = y_lower_spike_charges-alter_y_axis_spike_charges(1);
y_upper_spike_charges = 100;
y_upper_spike_charges = y_upper_spike_charges+alter_y_axis_spike_charges(2);

h = gca;
h.XTick = [10.^(1+log10(x_lower):1:log10(x_upper))];

set(gca,'xscale','log')
set(gca, 'layer', 'top')

% h.XTick = [logspace(log(concentrations_plot_DCMU(1))/log(10),log(concentrations_plot_DCMU(end))/log(10),length(concentrations_plot_DCMU))];
% h.XAxis.TickLength = [0.01 0.01];
% h.XMinorTick = 'off';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1.5;
text(concentrations_plot(1)*1.1,y_lower_spike_charges,'//','Color','black','FontSize',17); %inserting break symbols
% line([x_lower+(x_lower/2) x_lower+(1.7*(x_lower/2))],[y_lower_photocurrents y_lower_photocurrents],'LineWidth',2,'Color','white'); 
white_line = annotation('line',[0.203 0.212],[0.16 0.16],'LineWidth',2.2,'Color','white');    

if y_lower_spike_charges<-2
    yline(0,'k--','LineWidth',2)
else
end

hold on

x_lower = x_lower-alter_x_axis(1);
x_upper = x_upper+alter_x_axis(2);

xlim([x_lower x_upper])
ylim([y_lower_spike_charges y_upper_spike_charges])   

threshold_box = area([x_lower x_upper],[min_threshold_spike_charge min_threshold_spike_charge]);
threshold_box.BaseValue = max_threshold_spike_charge;
threshold_box.FaceColor = inhibitor_colors(1,:);
threshold_box.EdgeColor = 'none';
threshold_box.BaseLine.Color = 'none';
uistack(threshold_box,'bottom');
hold on

text(concentrations_plot(1,1)*2,max_threshold_spike_charge-5,'DMSO','Color',inhibitor_colors(end,:),'FontSize',17);

% Scaling and saving image
pbaspect([1 1.3 1]);
% h.XTickLabel{1} = [];
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_Inhibitors_Sp','svg')
hold off

%% Plotting relative changes without DMSO threshold

concentrations_plot = concentrations;
concentrations_plot(:,1) = min(min(concentrations(:,2:end)))/10;

max_conc = max(max(concentrations_plot));

if floor(log10(max_conc)) == log10(max_conc)
    x_upper = max_conc+(max_conc/10);
else
    x_upper = 10^ceil(log10(max_conc));
end

% Photocurrents
x_lower = min(min(concentrations_plot));

for y = 1:length(inhibitor_names)
    p_C03_T_AllInhibitors_photocurrents_relative(y) = errorbar(concentrations_plot(y,:),C03_T_AllInhibitors_photocurrents_relative(:,end-1,y),C03_T_AllInhibitors_photocurrents_relative(:,end,y),'Color',inhibitor_colors(y,:),'LineWidth',2.5);
    hold on
end

xlabel({append("[Inhibitor] (mM)")});
ylabel({'\DeltaSteady State Photocurrent (%)'});
box off 

legend([p_C03_T_AllInhibitors_photocurrents_relative(1:length(inhibitor_names))],[inhibitor_names],'location','southeast');
legend('AutoUpdate','off')
legend box off

y_lower_photocurrents = 0;
y_lower_photocurrents = y_lower_photocurrents-alter_y_axis_photocurrents(1);
y_upper_photocurrents = 100;
y_upper_photocurrents = y_upper_photocurrents+alter_y_axis_photocurrents(2);

h = gca;
h.XTick = [10.^(1+log10(x_lower):2:log10(x_upper))];

set(gca,'xscale','log')

% h.XTick = [logspace(log(concentrations_plot_DCMU(1))/log(10),log(concentrations_plot_DCMU(end))/log(10),length(concentrations_plot_DCMU))];
% h.XAxis.TickLength = [0.01 0.01];
% h.XMinorTick = 'off';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1.5;
text(concentrations_plot(1)*1.1,y_lower_photocurrents,'//','Color','black','FontSize',17); %inserting break symbols
line([x_lower+(x_lower/2) x_lower+(1.7*(x_lower/2))],[y_lower_photocurrents y_lower_photocurrents],'LineWidth',2,'Color','white');    
yline(0,'k--','LineWidth',1.5)
hold off

x_lower = x_lower-alter_x_axis(1);
x_upper = x_upper+alter_x_axis(2);

xlim([x_lower x_upper])
ylim([y_lower_photocurrents y_upper_photocurrents])    

% Scaling and saving image
pbaspect([1 1.3 1]);
% h.XTickLabel{1} = [];
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_Inhibitors_Pc','svg')

% spike_charges
x_lower = min(min(concentrations_plot));

for y = 1:length(inhibitor_names)
    p_C03_T_AllInhibitors_spike_charges_relative(y) = errorbar(concentrations_plot(y,:),C03_T_AllInhibitors_spike_charges_relative(:,end-1,y),C03_T_AllInhibitors_spike_charges_relative(:,end,y),'Color',inhibitor_colors(y,:),'LineWidth',2.5);
    hold on
end

xlabel({append("[Inhibitor] (mM)")});
ylabel({'\DeltaSpike Charge (%)'});
box off 

% legend([p_C03_T_AllInhibitors_spike_charges_relative(1:length(inhibitor_names))],[inhibitor_names],'location','northeast');
% legend('AutoUpdate','off')
% legend box off

y_lower_spike_charges = 0;
y_lower_spike_charges = y_lower_spike_charges-alter_y_axis_spike_charges(1);
y_upper_spike_charges = 100;
y_upper_spike_charges = y_upper_spike_charges+alter_y_axis_spike_charges(2);

h = gca;
h.XTick = [10.^(1+log10(x_lower):2:log10(x_upper))];

set(gca,'xscale','log')

% h.XTick = [logspace(log(concentrations_plot_DCMU(1))/log(10),log(concentrations_plot_DCMU(end))/log(10),length(concentrations_plot_DCMU))];
% h.XAxis.TickLength = [0.01 0.01];
% h.XMinorTick = 'off';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1.5;
text(concentrations_plot(1)*1.1,y_lower_spike_charges,'//','Color','black','FontSize',17); %inserting break symbols
line([x_lower+(x_lower/2) x_lower+(1.7*(x_lower/2))],[y_lower_spike_charges y_lower_spike_charges],'LineWidth',2,'Color','white');    
yline(0,'k--','LineWidth',1.5)
hold off

x_lower = x_lower-alter_x_axis(1);
x_upper = x_upper+alter_x_axis(2);

xlim([x_lower x_upper])
ylim([y_lower_spike_charges y_upper_spike_charges])    

% Scaling and saving image
pbaspect([1 1.3 1]);
% h.XTickLabel{1} = [];
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_Inhibitors_Sp','svg')
