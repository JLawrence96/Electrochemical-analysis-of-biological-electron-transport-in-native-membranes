%% Correlated JTS P700 measurements JTS thylakoids + 100 uM DCMU +/- 1 mM NADPH
% Dependencies: shadedErrorBar.m, Minimiser_Baseliner.m,Cottrell_Solver_Baseline_C

%% Data Input 

% Input Parameters
no_conditions = 2; %How many conditions
no_replicates = 3; %How many biolgical replicates per condition
no_scans = 3; %How many scans should be averaged
concentrations_mM = [0 1]; %Potentials tested in mV, including repeat potentials.


% Fitting Conditions for Chronoamperometry
Echem_intensities = [5 5 5 ; 5 5 5]; %Computing intensities for curve fitting
Echem_start_times = [737.8 1278.5 379.7 ; 1097.6 1103.9 376.8]; %Start time of first scan
Echem_light_on_times = [742.8 1283.5 384.7 ; 1102.6 1108.9 381.8]; %Time at which first light period starts
Echem_light_off_times = [802.8 1343.5 444.7 ; 1162.6 1168.9 441.8]; %Time at which first dark period starts
Echem_end_times = [922.8 1463.5 564.7 ; 1282.6 1288.9 561.8]; %End time of first scan
Echem_linear_baselines = [1 1 1 ; 1 1 1]; %0 = fits dark current with cottrel equation, 1 = fits dark current with straight line.
Echem_light_stabilisation_time = 10; %Point at which photocurrent reaches steady-state
Echem_dark_stabilisation_time = 90; %Point at which dark current reaches steady-state
Echem_spike_stabilisation_time = 15; %Point at which light current reaches steady state, normally 15 seconds
Echem_spacing_time = 180; %space between scans
Echem_radius = 5000; %radius of spherical electrode (um). Assumes porous electrodes are 1000x single pore radius.  
Echem_sampling_rate = 0.1; %sampling reate of chronoamp data
Echem_electrode_surface_area = 0.28; %Surface area of electrode in cm^2

% Fitting Conditions for Chronoamperometry
JTS_start_times = [724.157 844.251 964.146 1083.99 1263.72 1443.65 364.655 544.288 724.157 ; 1083.99 1263.72 1443.65 1083.99 1263.72 1443.65 364.655 544.288 724.157]; %Start time of first scan, first at 9.989
JTS_light_on_times = [729.32 909.153 1088.99 1088.99 1268.72 1448.65 369.655 549.288 729.157 ; 1088.99 1268.72 1448.65 1088.99 1268.72 1448.65 369.655 549.288 729.157]; %Time at which first, second and third light period starts
JTS_light_off_times = [789.157 909.251 1029.146 1148.99 1328.72 1508.65 429.655 609.288 789.157 ; 1148.99 1328.72 1508.65 1148.99 1328.72 1508.65 429.655 609.288 789.157]; %Time at which first dark period starts
JTS_end_times = [809.157 1029.251 1149.146 1268.99 1448.72 1628.65 549.655 729.288 909.157 ; 1268.99 1448.72 1628.65 1268.99 1448.72 1628.65 549.655 729.288 909.157]; %End time of first scan
JTS_linear_baselines = [1 1 1]; %0 = fits dark current with cottrel equation, 1 = fits dark current with straight line.
JTS_experiment_time = 180; %Length of light period and dark period combined
JTS_light_time = 60; %time of light period
JTS_preequilibration_time = 5; %Number of seconds prior to first light which are used for baselining
JTS_light_stabilisation_time = 30; %Point at which dark absorbance reaches steady-state 
JTS_dark_stabilisation_time = 115; %Point at which dark absorbance reaches steady-state 
JTS_DIRK_time = 7; %Region over which DIRK measurement is made (the signal decay kinetics)
JTS_sampling_rate = 0.1; %sampling reate of JTS data

%Normalisation options
normalise_chl = 1;
std_or_se = 1; %0 for standard deviation, 1 for standard error

%Plotting options
Echem_xtime = (0.1:0.1:185)'; %Time range of x axis, should be end_time - start_time
load NatureColours.mat
colors = [greens([3],:) ; blues([3],:)]; %RGB numbers for each condition
axes_colors = [browns([4],:) ; purples([4],:)]; %RGB numbers for each condition
Echem_alter_y_axis = [7 5]; %Will alter lower and upper bounds of graph y axis. + is extend, - contract. First position for lower and second for upper bound. 
JTS_alter_y_axis = [0.05 0.0175]; %Will alter lower and upper bounds of graph y axis. + is extend, - contract. First position for lower and second for upper bound. 

%Data information
directory_name = ""; %Ensure all files are stored in the same directory
Echem_file_names = ["C03_JTS_T+DCMU_ND1" "C03_JTS_T+DCMU_ND2" "C03_JTS_T+DCMU_ND3" ; "C03_JTS_T+DCMU+NADPH_ND1" "C03_JTS_T+DCMU+NADPH_ND2" "C03_JTS_T+DCMU+NADPH_ND3"];
JTS_file_names = ["P700_JTS_T+DCMU_ND1" "P700_JTS_T+DCMU_ND2" "P700_JTS_T+DCMU_ND3" ; "P700_JTS_T+DCMU+NADPH_ND1" "P700_JTS_T+DCMU+NADPH_ND2" "P700_JTS_T+DCMU+NADPH_ND3"];
file_extension = ".ascii";
chl_nM = [4.535525477 5.095466893 3.079677793]; %For chlorophyll normalisation. Set as an array of 1s for each dataset if no normalisation is required.
condition_names = ["TMs + 100 \muM DCMU" "+ 1 mM NADPH"];
concentration_names = ["0" "1"];
condition_chemical = ["[NADPH] (mM)"];

%% Processing EChem
for i = 1:no_conditions; 
    C03_T_JTS(:,1,i) = Echem_xtime;
    C03_T_JTS_Int(:,1,i) = Echem_xtime;

for j = 1:no_replicates;   
    
            input = dlmread(append(directory_name,Echem_file_names(i,j),file_extension));
            tinput = input(:,1);
            Iinput = ((input(:,2)*10^9) /Echem_electrode_surface_area) / chl_nM(j);
            intensity = Echem_intensities(i,j); 
            start_time = Echem_start_times(i,j); 
            light_on = Echem_light_on_times(i,j);
            light_off = Echem_light_off_times(i,j);
            end_time = Echem_end_times(i,j);
            linear_baseline = Echem_linear_baselines(i,j);
            light_stabilisation_time = Echem_light_stabilisation_time;
            dark_stabilisation_time = Echem_dark_stabilisation_time;
            spike_stabilisation_time = Echem_spike_stabilisation_time;
            spacing_time = Echem_spacing_time;
            radius = Echem_radius;
            sampling_rate = Echem_sampling_rate;
            
        for k = 1:no_scans;
            
            Cottrell_Solver_Baseliner_Chrono %Calls baselining function
            
            C03_T_JTS(:,((j-1)*no_scans)+k+1,i) =  Iplot_baseline_corrected;
            C03_T_JTS_dark_currents(((j-1)*no_scans)+k,i) = dark_current;
            C03_T_JTS_photocurrents(((j-1)*no_scans)+k,i) = photocurrent;
            C03_T_JTS_spike_charges(((j-1)*no_scans)+k,i) = spike_charge;
            C03_T_JTS_dip_charges(((j-1)*no_scans)+k,i) = dip_charge;
            
            start_time = start_time+Echem_spacing_time; 
            light_on = light_on+Echem_spacing_time;
            light_off = light_off+Echem_spacing_time;
            end_time = end_time+Echem_spacing_time;
            
        end
    end
end

%% Processing 705 nm
for i = 1:no_conditions; 
    for j = 1:no_replicates;   
    
            input = dlmread(append(directory_name,JTS_file_names(i,j),file_extension));
            tinput = input(:,1);
            Iinput = input(:,2)*10^3 / chl_nM(j);
            experiment_time = JTS_experiment_time;
            light_time = JTS_light_time;
            preequilibration_time = JTS_preequilibration_time;
            sampling_rate = JTS_sampling_rate;
            dark_stabilisation_time = JTS_dark_stabilisation_time;
            
        for k = 1:no_scans;
            
            start_time = JTS_start_times(i,j*no_replicates+k-no_replicates); 
            light_on = JTS_light_on_times(i,j*no_replicates+k-no_replicates);
            light_off = JTS_light_off_times(i,j*no_replicates+k-no_replicates);
            end_time = JTS_end_times(i,j*no_replicates+k-no_replicates);

            Linear_Baseliner_JTS %Calls baselining function
            
            P705_T_JTS(:,1,i) = tplot;
            P705_T_JTS(:,j*no_replicates+k-no_replicates+1,i) =  Iplot_baseline_corrected;
             
        end
    end
end

%Averaging Scans
for l = 1:no_replicates;
    P705_T_JTS(:,(no_scans*no_replicates)+1+l,:) = mean(P705_T_JTS(:,((l-1)*no_scans)+2:((l-1)*no_scans)+no_scans+1,:),2);
end

%% Processing 740 nm

for j = 1:no_replicates;   
    
            input = dlmread(append(directory_name,JTS_file_names(i,j),file_extension));
            tinput = input(:,1);
            Iinput = input(:,3)*10^3 / chl_nM(j);
            experiment_time = JTS_experiment_time;
            light_time = JTS_light_time;
            preequilibration_time = JTS_preequilibration_time;
            sampling_rate = JTS_sampling_rate;
            dark_stabilisation_time = JTS_dark_stabilisation_time;
            
        for k = 1:no_scans;
            
            start_time = JTS_start_times(i,j*no_replicates+k-no_replicates); 
            light_on = JTS_light_on_times(i,j*no_replicates+k-no_replicates);
            light_off = JTS_light_off_times(i,j*no_replicates+k-no_replicates);
            end_time = JTS_end_times(i,j*no_replicates+k-no_replicates);

            Linear_Baseliner_JTS %Calls baselining function
            
            P740_T_JTS(:,1,i) = tplot;
            P740_T_JTS(:,j*no_replicates+k-no_replicates+1,i) =  Iplot_baseline_corrected;
             
        end
end

%Averaging Scans
for l = 1:no_replicates;
    P740_T_JTS(:,(no_scans*no_replicates)+1+l,:) = mean(P740_T_JTS(:,((l-1)*no_scans)+2:((l-1)*no_scans)+no_scans+1,:),2);
end

%% Averaging and calculating percentage changes for JTS;
P700_T_JTS(:,1,:) = P705_T_JTS(:,1,:);
P700_T_JTS(:,2:no_replicates+1,:) = P705_T_JTS(:,end-no_replicates+1:end,:) - P740_T_JTS(:,end-no_replicates+1:end,:);

if std_or_se == 0;
    error_normaliser = 1;
else
    error_normaliser = sqrt(no_replicates);
end

for i = 1:no_conditions;
    
    P700_T_JTS_Relative(:,1,i) = P700_T_JTS(:,1,i);

    for j = 1:no_replicates

        P700_T_JTS_MaxAbs(j,i) = abs(mean(P700_T_JTS((JTS_preequilibration_time+JTS_light_stabilisation_time)/sampling_rate:(JTS_light_time+JTS_preequilibration_time)/sampling_rate,j+1,i)));
        P700_T_JTS_Relative(:,j+1,i) = P700_T_JTS(:,j+1,i) ./ P700_T_JTS_MaxAbs(j,i);

    end
end

P700_T_JTS_DIRK(:,:,:) = P700_T_JTS((JTS_light_time+JTS_preequilibration_time)/sampling_rate:(JTS_light_time+JTS_preequilibration_time+JTS_DIRK_time)/sampling_rate,:,:);
P700_T_JTS_DIRK(:,1,:) = P700_T_JTS_DIRK(:,1,:) - P700_T_JTS_DIRK(1,1,:);
P700_T_JTS_DIRK(:,2:end,:) = (P700_T_JTS_DIRK(:,2:end,:) * -1);

DIRK_decay = @(c,x) c(1)*exp(-1*(1/c(2))*x) + c(3);

for i = 1:no_conditions;

    DIRK_tplot = P700_T_JTS_DIRK(:,1,i);
    
    for j = 1:no_replicates;

        DIRK_Iplot = P700_T_JTS_DIRK(:,j+1,i);
        DIRK_fit_params(:,j,i) = lsqcurvefit(DIRK_decay,[0 5 0],DIRK_tplot,DIRK_Iplot);
        DIRK_fitplot = DIRK_decay(DIRK_fit_params(:,j,i),DIRK_tplot);
        
        plot(DIRK_tplot,DIRK_Iplot);
        hold on
        plot(DIRK_tplot,DIRK_fitplot);
        hold on

        P700_T_JTS_Tau(j,i) = abs(1/DIRK_fit_params(2,j,i));

    end
end

P700_T_JTS_Diff(:,1,:) = P700_T_JTS(1:end-1,1,:);
P700_T_JTS_Diff(:,2:no_replicates+1,:) = diff(-1*P700_T_JTS(:,2:no_replicates+1,:));


P700_T_JTS(:,no_replicates+2,:) = mean(P700_T_JTS(:,2:no_replicates+1,:),2);
P700_T_JTS(:,no_replicates+3,:) = std(P700_T_JTS(:,2:no_replicates+1,:),0,2)/error_normaliser;
P700_T_JTS_Diff(:,no_replicates+2,:) = mean(P700_T_JTS_Diff(:,2:no_replicates+1,:),2);
P700_T_JTS_Diff(:,no_replicates+3,:) = std(P700_T_JTS_Diff(:,2:no_replicates+1,:),0,2)/error_normaliser;
P700_T_JTS_Relative(:,no_replicates+2,:) = mean(P700_T_JTS_Relative(:,2:no_replicates+1,:),2);
P700_T_JTS_Relative(:,no_replicates+3,:) = std(P700_T_JTS_Relative(:,2:no_replicates+1,:),0,2)/error_normaliser;

P700_T_JTS_MaxAbs(no_replicates+1,:) = mean(P700_T_JTS_MaxAbs(1:no_replicates,:));
P700_T_JTS_MaxAbs(no_replicates+2,:) = std(P700_T_JTS_MaxAbs(1:no_replicates,:),0)/error_normaliser;
P700_T_JTS_Tau(no_replicates+1,:) = mean(P700_T_JTS_Tau(1:no_replicates,:));
P700_T_JTS_Tau(no_replicates+2,:) = std(P700_T_JTS_Tau(1:no_replicates,:),0)/error_normaliser;

%% Averaging and calculating percentage changes for Echem;

%Averaging scans
for l = 1:no_replicates;
    C03_T_JTS(:,(no_scans*no_replicates)+1+l,:) = mean(C03_T_JTS(:,((l-1)*no_scans)+2:((l-1)*no_scans)+no_scans+1,:),2);
    C03_T_JTS_Int(:,(no_scans*no_replicates)+1+l,:) = cumtrapz(C03_T_JTS(:,(no_scans*no_replicates)+1+l,:));
    C03_T_JTS_dark_currents((no_scans*no_replicates)+l,:) = mean(C03_T_JTS_dark_currents(((l-1)*no_scans)+1:((l-1)*no_scans)+no_scans,:));
    C03_T_JTS_photocurrents((no_scans*no_replicates)+l,:) = mean(C03_T_JTS_photocurrents(((l-1)*no_scans)+1:((l-1)*no_scans)+no_scans,:));
    C03_T_JTS_spike_charges((no_scans*no_replicates)+l,:) = mean(C03_T_JTS_spike_charges(((l-1)*no_scans)+1:((l-1)*no_scans)+no_scans,:));
    C03_T_JTS_dip_charges((no_scans*no_replicates)+l,:) = mean(C03_T_JTS_dip_charges(((l-1)*no_scans)+1:((l-1)*no_scans)+no_scans,:));
end

%Averaging replicates and calculating errors

if std_or_se == 0;
    error_normaliser = 1;
else
    error_normaliser = sqrt(no_replicates);
end

C03_T_JTS(:,(no_scans*no_replicates)+no_replicates+2,:) = mean(C03_T_JTS(:,(no_scans*no_replicates)+2:(no_scans*no_replicates)+no_replicates+1,:),2);
C03_T_JTS(:,(no_scans*no_replicates)+no_replicates+3,:) = std(C03_T_JTS(:,(no_scans*no_replicates)+2:(no_scans*no_replicates)+no_replicates+1,:),0,2)/error_normaliser;
C03_T_JTS_Int(:,(no_scans*no_replicates)+no_replicates+2,:) = mean(C03_T_JTS_Int(:,(no_scans*no_replicates)+2:(no_scans*no_replicates)+no_replicates+1,:),2);
C03_T_JTS_Int(:,(no_scans*no_replicates)+no_replicates+3,:) = std(C03_T_JTS_Int(:,(no_scans*no_replicates)+2:(no_scans*no_replicates)+no_replicates+1,:),0,2)/error_normaliser;

C03_T_JTS_dark_currents((no_scans*no_replicates)+no_replicates+1,:) = mean(C03_T_JTS_dark_currents((no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates,:));
C03_T_JTS_dark_currents((no_scans*no_replicates)+no_replicates+2,:) = std(C03_T_JTS_dark_currents((no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates,:),0)/error_normaliser;
C03_T_JTS_photocurrents((no_scans*no_replicates)+no_replicates+1,:) = mean(C03_T_JTS_photocurrents((no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates,:));
C03_T_JTS_photocurrents((no_scans*no_replicates)+no_replicates+2,:) = std(C03_T_JTS_photocurrents((no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates,:),0)/error_normaliser;
C03_T_JTS_spike_charges((no_scans*no_replicates)+no_replicates+1,:) = mean(C03_T_JTS_spike_charges((no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates,:));
C03_T_JTS_spike_charges((no_scans*no_replicates)+no_replicates+2,:) = std(C03_T_JTS_spike_charges((no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates,:),0)/error_normaliser;
C03_T_JTS_dip_charges((no_scans*no_replicates)+no_replicates+1,:) = mean(C03_T_JTS_dip_charges((no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates,:));
C03_T_JTS_dip_charges((no_scans*no_replicates)+no_replicates+2,:) = std(C03_T_JTS_dip_charges((no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates,:),0)/error_normaliser;

%%Significance testing

all_combinations = nchoosek(1:no_conditions,2);

for n = 1:height(all_combinations);
    [h_photocurrents(n),p_photocurrents(n)] = ttest2(C03_T_JTS_photocurrents(no_replicates*no_scans+1:no_replicates*no_scans+no_replicates,all_combinations(n,1)),C03_T_JTS_photocurrents(no_replicates*no_scans+1:no_replicates*no_scans+no_replicates,all_combinations(n,2)));
    [h_spike_charges(n),p_spike_charges(n)] = ttest2(C03_T_JTS_spike_charges(no_replicates*no_scans+1:no_replicates*no_scans+no_replicates,all_combinations(n,1)),C03_T_JTS_spike_charges(no_replicates*no_scans+1:no_replicates*no_scans+no_replicates,all_combinations(n,2)));
    [h_MaxAbs(n),p_MaxAbs(n)] = ttest2(P700_T_JTS_MaxAbs(1:no_replicates,all_combinations(n,1)),P700_T_JTS_MaxAbs(1:no_replicates,all_combinations(n,2)));
    [h_Tau(n),p_Tau(n)] = ttest2(P700_T_JTS_Tau(1:no_replicates,all_combinations(n,1)),P700_T_JTS_Tau(1:no_replicates,all_combinations(n,2)));
end

%% Plotting Chronoampeormetry and Spectroscopy Curve
close all

%Plotting curves
for m = no_conditions:-1:1;
    
    subplot(2,1,1);
    
    p_C03_T_JTS(m) = shadedErrorBar(C03_T_JTS(:,1,m),C03_T_JTS(:,(no_scans*no_replicates)+no_replicates+2,m),C03_T_JTS(:,(no_scans*no_replicates)+no_replicates+3,m),'lineProps',{'LineWidth',2.5,'color',colors(m,:)});
    hold on

    if m == 1;
        legend('AutoUpdate','off');
        leg = legend([p_C03_T_JTS.mainLine],condition_names,'location','northeast');
        legend box off
    else
    end        

end

%Graph limits chronoamperometry
max_current = ceil(max(max(C03_T_JTS(:,(no_scans*no_replicates)+no_replicates+2,:))));
max_current_range = (ceil(max_current*10^-(numel(num2str(abs(max_current)))-1))) * 10^(numel(num2str(abs(max_current)))-1);

x_lower = 0;
x_upper = Echem_xtime(end);
y_lower = 0-Echem_alter_y_axis(1);
y_upper = max_current_range+Echem_alter_y_axis(2);

xlim([x_lower x_upper])
ylim([y_lower y_upper]);

%Adding annotations chronoamperometry
onbox = area([Echem_light_on_times(1)-Echem_start_times(1) Echem_light_off_times(1)-Echem_start_times(1)],[y_upper y_upper]);
onbox.BaseValue = y_lower;
onbox.FaceColor = [1 1 1];
onbox.EdgeColor = 'none';
uistack(onbox,'bottom');
hold on

%Plot Formatting chronoamperometry
box on
pec_label = ylabel({'Photocurrent Density (nA [nmol Chl \ita\rm]^{-1} cm^{-2})'});
pec_label.Position(1) = pec_label.Position(1)-4;
pec_label.Position(2) = pec_label.Position(2)-24;
g = gca;
g.TickDir = 'out';
g.Color = [0.8 0.8 0.8];
g.XTick = [];
yyaxis left
g.YMinorTick = 'on';
yyaxis right
g.YTick = [];
g.YAxis(2).Color = 'k';
g.TickDir = 'out';
g.FontName = 'Helvetica Ltd Std';
g.FontSize = 17;
g.LineWidth = 1.5;
g.YAxis(1).Color = axes_colors(1,:);
g.YAxis(1).LineWidth = 1.75;
set(g ,'Layer', 'Top');
pbaspect([2 1 1]);
hold off
z(1) = gca

for m = no_conditions:-1:1;
    
    subplot(2,1,2);
    p_P700_T_JTS(m) = shadedErrorBar(P700_T_JTS(:,1,1),P700_T_JTS(:,no_replicates+2,m),P700_T_JTS(:,no_replicates+3,m),'lineProps',{'LineWidth',2.5,'color',colors(m,:)});
    box on
    hold on

end

%Graph limits spectroscopy
min_abs = min(min(P700_T_JTS(:,no_replicates+2,:)));
min_abs_range = round(min_abs,1,'significant');

x_lower = 0;
x_upper = Echem_xtime(end);
y_lower = min_abs_range-JTS_alter_y_axis(1);
y_upper = 0+JTS_alter_y_axis(2);

xlim([x_lower x_upper])
ylim([y_lower y_upper]);

%Adding annotations spectroscopy
onbox = area([Echem_light_on_times(1)-Echem_start_times(1) Echem_light_off_times(1)-Echem_start_times(1)],[y_upper y_upper]);
onbox.BaseValue = y_lower;
onbox.FaceColor = [1 1 1];
onbox.EdgeColor = 'none';
uistack(onbox,'bottom');
hold on

pec_ox_arrow = annotation('textarrow',[0.66 0.66],[0.58 0.75],'String','','FontName','Helvetica Ltd Std','Color',axes_colors(1,:),'FontSize',17);
pec_arrow = annotation('textbox',[0.66 0.69 0.005 0.005],'String','Electrode','EdgeColor','none','FontName','Helvetica Ltd Std','FontWeight','bold','Color',axes_colors(1,:),'FontSize',17);
pec_red_arrow = annotation('textarrow',[0.66 0.66],[0.75 0.58],'String','Reduction','HeadStyle','none','FontName','Helvetica Ltd Std','Color',axes_colors(1,:),'FontSize',17);
pec_text = annotation('textbox',[0.2215 0.925 0.005 0.005],'String','Electrochemistry','EdgeColor','none','FontName','Helvetica Ltd Std','FontWeight','bold','Color',axes_colors(1,:),'FontSize',17);

spec_ox_arrow = annotation('textarrow',[0.66 0.66],[0.17 0.33],'String','Oxidation','FontName','Helvetica Ltd Std','Color',axes_colors(2,:),'FontSize',17);
spec_arrow = annotation('textbox',[0.66 0.27 0.005 0.005],'String','P700','EdgeColor','none','FontName','Helvetica Ltd Std','FontWeight','bold','Color',axes_colors(2,:),'FontSize',17);
spec_red_arrow = annotation('textarrow',[0.66 0.66],[0.33 0.17],'String','Reduction','FontName','Helvetica Ltd Std','Color',axes_colors(2,:),'FontSize',17);
spec_text = annotation('textbox',[0.2375 0.515 0.005 0.005],'String','Spectroscopy','EdgeColor','white','FontName','Helvetica Ltd Std','FontWeight','bold','Color',axes_colors(2,:),'FontSize',17);

%Plot Formatting spectroscopy
box off
xlabel({'','Time (s)'});
h(1) = gca;
pbaspect([2 1 1]);
h(1).LineWidth = 1.5;
h(1).FontName = 'Helvetica Ltd Std';
h(1).FontSize = 17;
z(2) = gca;

h(2) = axes('Position',h(1).Position,'XAxisLocation','top','YAxisLocation','left','color','none');
pbaspect([2 1 1]);
h(2).LineWidth = 1.5;
h(2).FontName = 'Helvetica Ltd Std';
h(2).FontSize = 17;
z(3) = gca;

h(3) = axes('Position',h(1).Position,'XAxisLocation','bottom','YAxisLocation','right','color','none');
spec_label = ylabel({'P700 (\DeltaI/Ix10^{3} [nmol Chl \ita\rm]^{-1})'});
spec_label.Position(1) = spec_label.Position(1)+202;
spec_label.Position(2) = spec_label.Position(2)-0.625;
pbaspect([2 1 1]);
h(3).LineWidth = 1.5;
h(3).FontName = 'Helvetica Ltd Std';
h(3).FontSize = 17;
h(3).YAxis(1).Color = axes_colors(2,:);
h(3).YAxis(1).LineWidth = 1.75;
z(4) = gca;

h(1).Color = [0.8 0.8 0.8];
h(2).XLim = h(1).XLim;
h(3).XLim = h(1).XLim;
h(3).YLim = h(1).YLim;

h(1).XTick = [];
h(1).YTick = [];
h(2).YTick = [];

h(2).XMinorTick = 'on';
h(3).XMinorTick = 'on';
h(3).YMinorTick = 'on';

h(2).XTickLabel = [];
h(3).TickDir = 'out';

hold off

% hold off
% 
% z(1) = subplot(2,1,1); 
% z(2) = subplot(2,1,2);
% 
plot_bottom = z(2).Position(2);
plot_top = z(1).Position(2) + z(1).Position(4);
plot_space = plot_top-plot_bottom;
z(1).Position = [z(1).Position(1) plot_bottom+(plot_space/2) z(1).Position(3)+0.01 plot_space/2];
z(2).Position = [z(1).Position(1) z(2).Position(2) z(1).Position(3) plot_space/2];
z(3).Position = [z(1).Position(1) z(3).Position(2) z(1).Position(3) plot_space/2];
z(4).Position = [z(1).Position(1) z(4).Position(2) z(1).Position(3) plot_space/2];


% Scaling and saving image
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 1000, 800])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_P700_T_Curve','svg')


%% Plotting Absolute Parameters

%Photocurrent

close all

for w = 1:no_conditions;
    
  bar_spacing = 1/no_conditions/1.2;
    
  p_C03_T_JTS_photocurrents_bar(w) = bar((w-1)*bar_spacing,C03_T_JTS_photocurrents(end-1,w),'BarWidth',bar_spacing*0.9,'FaceColor',colors(w,:),'LineWidth',1.5);
  hold on
  p_C03_T_JTS_photocurrents_error(w) = errorbar((w-1)*bar_spacing,C03_T_JTS_photocurrents(end-1,w),C03_T_JTS_photocurrents(end,w),'Color','k','LineWidth',1.5);
  hold on

end

significant_index_photocurrents = find(p_photocurrents<0.05);
sig_bar_positions_photocurrents = num2cell((all_combinations(significant_index_photocurrents,:)*bar_spacing)-bar_spacing,2)';
sig_p_values_photocurrents = p_photocurrents(significant_index_photocurrents);
p_C03_T_AllDarkTimes_photocurrents_sigstar = sigstar(sig_bar_positions_photocurrents,sig_p_values_photocurrents,1);

xlabel({condition_chemical});
if normalise_chl == 1;
    ylabel({'Steady State Photocurrent (nA [nmol Chl \ita\rm]^{-1} cm^{-2})'});
else
    ylabel({'Steady State Photocurrent (nA cm^{-2})'});
end

xlim([0-(bar_spacing/1.5) ((w-1)*bar_spacing)+(bar_spacing/1.5)])
% ylim([0 10])

box off
h = gca;
h.YAxis.Color = axes_colors(1,:);
h.XTick = [((1:no_conditions)-1)*bar_spacing];
h.XTickLabel = concentration_names;
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1.5;
h.YAxis.LineWidth = 1.75;
hold on

% Scaling and saving image
pbaspect([0.6 2 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 375, 800])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'P700_T_JTS_NADPH_Pc','svg')

hold off

%Spike Charge

close all

for w = 1:no_conditions;
    
  bar_spacing = 1/no_conditions/1.2;
    
  p_C03_T_JTS_spike_charges_bar(w) = bar((w-1)*bar_spacing,C03_T_JTS_spike_charges(end-1,w)./1000,'BarWidth',bar_spacing*0.9,'FaceColor',colors(w,:),'LineWidth',1.5);
  hold on
  p_C03_T_JTS_spike_charges_error(w) = errorbar((w-1)*bar_spacing,C03_T_JTS_spike_charges(end-1,w)./1000,C03_T_JTS_spike_charges(end,w)./1000,'Color','k','LineWidth',1.5);
  hold on

end

significant_index_spike_charges = find(p_spike_charges<0.05);
sig_bar_positions_spike_charges = num2cell((all_combinations(significant_index_spike_charges,:)*bar_spacing)-bar_spacing,2)';
sig_p_values_spike_charges = p_spike_charges(significant_index_spike_charges);
p_C03_T_AllDarkTimes_spike_charges_sigstar = sigstar(sig_bar_positions_spike_charges,sig_p_values_spike_charges,1);

xlabel({condition_chemical});
if normalise_chl == 1;
    ylabel({'Spike Charge (\muC [nmol Chl \ita\rm]^{-1} cm^{-2})'});
else
    ylabel({'Spike Charge (\muC cm^{-2})'});
end

xlim([0-(bar_spacing/1.5) ((w-1)*bar_spacing)+(bar_spacing/1.5)])
% ylim([0 10])

box off
h = gca;
h.YAxis.Color = axes_colors(1,:);
h.XTick = [((1:no_conditions)-1)*bar_spacing];
h.XTickLabel = concentration_names;
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1.5;
h.YAxis.LineWidth = 1.75;
hold on

% Scaling and saving image
pbaspect([0.6 2 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 400, 800])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'P700_T_JTS_NADPH_Sp','svg')

hold off

%Max Abs

close all

for w = 1:no_conditions;
    
  bar_spacing = 1/no_conditions/1.2;
    
  p_P700_T_JTS_MaxAbs_bar(w) = bar((w-1)*bar_spacing,P700_T_JTS_MaxAbs(end-1,w),'BarWidth',bar_spacing*0.9,'FaceColor',colors(w,:),'LineWidth',1.5);
  hold on
  p_P700_T_JTS_MaxAbs_error(w) = errorbar((w-1)*bar_spacing,P700_T_JTS_MaxAbs(end-1,w),P700_T_JTS_MaxAbs(end,w),'Color','k','LineWidth',1.5);
  hold on

end

significant_index_MaxAbs = find(p_MaxAbs<0.05);
sig_bar_positions_MaxAbs = num2cell((all_combinations(significant_index_MaxAbs,:)*bar_spacing)-bar_spacing,2)';
sig_p_values_MaxAbs = p_MaxAbs(significant_index_MaxAbs);
p_C03_T_AllDarkTimes_MaxAbs_sigstar = sigstar(sig_bar_positions_MaxAbs,sig_p_values_MaxAbs,1);

xlabel({condition_chemical});
if normalise_chl == 1;
    ylabel({'Steady State P700^{+} (\DeltaI/Ix10^{3} [nmol Chl \ita\rm]^{-1})'});
else
    ylabel({'Steady State P700^{+} (\DeltaI/Ix10^{3})'});
end

xlim([0-(bar_spacing/1.5) ((w-1)*bar_spacing)+(bar_spacing/1.5)])
% ylim([0 10])

box off
h = gca;
h.YAxis.Color = axes_colors(2,:);
h.XTick = [((1:no_conditions)-1)*bar_spacing];
h.XTickLabel = concentration_names;
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1.5;
h.YAxis.LineWidth = 1.75;
hold on

% Scaling and saving image
pbaspect([0.6 2 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 375, 800])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'P700_T_JTS_NADPH_MaxAbs','svg')

hold off

%Tau

close all

for w = 1:no_conditions;
    
  bar_spacing = 1/no_conditions/1.2;
    
  p_P700_T_JTS_Tau_bar(w) = bar((w-1)*bar_spacing,P700_T_JTS_Tau(end-1,w),'BarWidth',bar_spacing*0.9,'FaceColor',colors(w,:),'LineWidth',1.5);
  hold on
  p_P700_T_JTS_Tau_error(w) = errorbar((w-1)*bar_spacing,P700_T_JTS_Tau(end-1,w),P700_T_JTS_Tau(end,w),'Color','k','LineWidth',1.5);
  hold on

end

significant_index_Tau = find(p_Tau<0.05);
sig_bar_positions_Tau = num2cell((all_combinations(significant_index_Tau,:)*bar_spacing)-bar_spacing,2)';
sig_p_values_Tau = p_Tau(significant_index_Tau);
p_C03_T_AllDarkTimes_Tau_sigstar = sigstar(sig_bar_positions_Tau,sig_p_values_Tau,1);

xlabel({condition_chemical});
ylabel({'P700^{+} Re-reduction Rate (s^{-1})'});

xlim([0-(bar_spacing/1.5) ((w-1)*bar_spacing)+(bar_spacing/1.5)])
% ylim([0 10])

box off
h = gca;
h.YAxis.Color = axes_colors(2,:);
h.XTick = [((1:no_conditions)-1)*bar_spacing];
h.XTickLabel = concentration_names;
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1.5;
h.YAxis.LineWidth = 1.75;
hold on

% Scaling and saving image
pbaspect([0.6 2 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 375, 800])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'P700_T_JTS_NADPH_Tau','svg')

hold off