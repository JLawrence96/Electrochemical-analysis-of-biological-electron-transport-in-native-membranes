%% Correlated JTS P700 measurements JTS thylakoids + 100 uM DCMU +/- 1 mM NADPH
% Dependencies: shadedErrorBar.m, Minimiser_Baseliner.m,Cottrell_Solver_Baseline_C

%% Data Input 

% Input Parameters
no_conditions = 2; %How many conditions
no_replicates = 3; %How many biolgical replicates per condition

% Fitting Conditions for Chronoamperometry
start_times = [0.0998919]; %Start time of first scan, first at 9.989
light_on_times = [9.99909]; %Time at which first, second and third light period starts
DIRK_light_on_times = [60.0002]; %Time at which first, second and third light period starts
light_off_times = [69.9872]; %Time at which first dark period starts
DIRK_end_times = [80.0007];
end_times = [129.897]; %End time of first scan
experiment_time = 120; %Length of light period and dark period combined
DIRK_experiment_time = 20; %Length of light period and dark period combined
light_time = 60; %time of light period
DIRK_light_time = 10;
preequilibration_time = 5; %Number of seconds prior to first light which are used for baselining
light_stabilisation_time = 55; %Point at which dark absorbance reaches steady-state 
dark_stabilisation_time = 50; %Point at which dark absorbance reaches steady-state 
DIRK_time = 5;
sampling_rate = 0.1; %sampling reate of JTS data
DIRK_sampling_rate = 0.002; %sampling reate of JTS data

%Normalisation options
std_or_se = 1; %0 for standard deviation, 1 for standard error

%Plotting options
load NatureColours.mat
colors = [greens(3,:) ; blues(3,:)];
condition_names = ["TMs" "+100 \muM DCMU"];
condition_chemical = ["DCMU (\muM)"];
concentration_names = [0 100];
alter_y_axis = [20 3 ; 0 0 ; 0 0 ; 0 0]; %Will alter lower and upper bounds of graph y axis. + is extend, - contract. First position for lower and second for upper bound. 

%Data information
directory_name = ""; %Ensure all files are stored in the same directory
file_names = ["ECS_ThylSol_500uE_NO1" "ECS_ThylSol_500uE_NO2" "ECS_ThylSol_500uE_NO3" ; "ECS_ThylSol+DCMU_500uE_NO1" "ECS_ThylSol+DCMU_500uE_NO2" "ECS_ThylSol+DCMU_500uE_NO3"];
file_extension = ".ascii";


%% Processing 485 nm data
for i = 1:no_conditions; 
    for j = 1:no_replicates;   
    
        input = dlmread(append(directory_name,file_names(i,j),file_extension));
        tinput = input(:,1);
        Iinput = input(:,2)*10^3;
        experiment_time = experiment_time;
        light_time = light_time;
        preequilibration_time = preequilibration_time;
        sampling_rate = sampling_rate;
        dark_stabilisation_time = dark_stabilisation_time;
                      
        start_time = start_times; 
        light_on = light_on_times;
        light_off = light_off_times;
        end_time = end_times;

        Linear_Baseliner_JTS_StartOnlyFlat_ECS %Calls baselining function
            
        A485_ThylSol{i}(:,1) = tplot;
        A485_ThylSol{i}(:,j+1) =  Iplot_baseline_corrected;

    end
end

%% Processing 500 nm data
for i = 1:no_conditions; 
    for j = 1:no_replicates;   
    
        input = dlmread(append(directory_name,file_names(i,j),file_extension));
        tinput = input(:,1);
        Iinput = input(:,3)*10^3;
        experiment_time = experiment_time;
        light_time = light_time;
        preequilibration_time = preequilibration_time;
        sampling_rate = sampling_rate;
        dark_stabilisation_time = dark_stabilisation_time;
                      
        start_time = start_times; 
        light_on = light_on_times;
        light_off = light_off_times;
        end_time = end_times;

        Linear_Baseliner_JTS_StartOnlyFlat_ECS %Calls baselining function
            
        A500_ThylSol{i}(:,1) = tplot;
        A500_ThylSol{i}(:,j+1) =  Iplot_baseline_corrected;

    end
end

%% Calculating parameters

for i = 1:no_conditions;
        
    ECS_ThylSol{i} = zeros(length(A485_ThylSol{i}),no_replicates+1);
    ECS_ThylSol{i}(:,1) = A485_ThylSol{i}(:,1);
    ECS_ThylSol{i}(:,2:end) = A500_ThylSol{i}(:,2:end) - A485_ThylSol{i}(:,2:end);

    for j = 1:no_replicates;

            ECS_ThylSol_pmf(i,j) = abs(mean(ECS_ThylSol{i}((preequilibration_time+light_stabilisation_time)/sampling_rate:(preequilibration_time+light_time)/sampling_rate,j+1)));       
        
        end
end

DIRK_decay = @(c,x) c(1)*exp(-1*(1/c(2))*x) + c(3);

for i = 1:no_conditions;
    
    ECS_ThylSol_DIRK{i}(:,:) = ECS_ThylSol{i}(zeroed_light_off_index: zeroed_DIRK_end_time_index,:);
    ECS_ThylSol_DIRK{i}(:,1) = ECS_ThylSol_DIRK{i}(:,1) - ECS_ThylSol_DIRK{i}(1,1);
    DIRK_tplot = ECS_ThylSol_DIRK{i}(:,1);
    
    for j = 1:no_replicates;

        DIRK_Iplot = ECS_ThylSol_DIRK{i}(:,j+1);
        DIRK_fit_params(:,j,i) = lsqcurvefit(DIRK_decay,[0 5 0],DIRK_tplot,DIRK_Iplot);
        DIRK_fitplot = DIRK_decay(DIRK_fit_params(:,j,i),DIRK_tplot);
        
        plot(DIRK_tplot,DIRK_Iplot);
        hold on
        plot(DIRK_tplot,DIRK_fitplot);
        hold on

        ECS_ThylSol_gH(i,j) = abs(1/DIRK_fit_params(2,j,i));
        ECS_ThylSol_vH(i,j) = ECS_ThylSol_gH(i,j) * ECS_ThylSol_pmf(i,j);

    end
end

%% Averaging

if std_or_se == 0;
    error_normaliser = 1;
else
    error_normaliser = sqrt(no_replicates);
end

%Averaging Scans for ECS
for i = 1:no_conditions
    for l = 1:no_replicates;

        ECS_ThylSol{i}(:,no_replicates+2) = mean(ECS_ThylSol{i}(:,2:no_replicates+1),2);
        ECS_ThylSol_pmf(i,no_replicates+1) = mean(ECS_ThylSol_pmf(i,1:no_replicates),2);
        ECS_ThylSol_gH(i,no_replicates+1) = mean(ECS_ThylSol_gH(i,1:no_replicates),2);
        ECS_ThylSol_vH(i,no_replicates+1) = mean(ECS_ThylSol_vH(i,1:no_replicates),2);

        ECS_ThylSol{i}(:,no_replicates+3) = std(ECS_ThylSol{i}(:,2:no_replicates+1),0,2)./error_normaliser;
        ECS_ThylSol_pmf(i,no_replicates+2) = std(ECS_ThylSol_pmf(i,1:no_replicates),0,2)./error_normaliser;
        ECS_ThylSol_gH(i,no_replicates+2) = std(ECS_ThylSol_gH(i,1:no_replicates),0,2)./error_normaliser;
        ECS_ThylSol_vH(i,no_replicates+2) = std(ECS_ThylSol_vH(i,1:no_replicates),0,2)./error_normaliser;

    end
end


%% Plotting ECS Curve
close all

%Plotting curves
for n = 1:no_conditions
    
    p_ECS_ThylSol(n) = shadedErrorBar(ECS_ThylSol{n}(:,1),ECS_ThylSol{n}(:,no_replicates+2),ECS_ThylSol{n}(:,no_replicates+3),'lineProps',{'LineWidth',2.5,'color',colors(n,:)});
    hold on

end

legend('AutoUpdate','off')
legend([p_ECS_ThylSol(1:n).mainLine],condition_names,'location','northwest');
legend box off

%Graph limits
max_abs = max(max(ECS_ThylSol{n}(:,no_replicates+2,:)));
max_abs_range = round(max_abs,1,'significant');

x_lower = 0;
x_upper = tplot(end);
y_lower = 0-alter_y_axis(1,1);
y_upper = max_abs_range+alter_y_axis(1,2);
xlim([x_lower x_upper])
ylim([y_lower y_upper]);

%Adding annotations
onbox1 = area([5 65],[y_upper y_upper]);
onbox1.BaseValue = y_lower;
onbox1.FaceColor = [1 1 1];
onbox1.EdgeColor = 'none';
uistack(onbox1,'bottom');
hold on

%Plot Formatting
box off
xlabel({'Time (s)'});
ylabel({'ECS (A.U.)'});
h = gca;
h.Color = [0.8 0.8 0.8];
h.XMinorTick = 'on';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1;
set(h ,'Layer', 'Top');
hold on

hold off

% Scaling and saving image
pbaspect([1 1.3 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'ECS_ThylSol_Curve','svg')

%Zoomed in
xlim([60 70])

% Scaling and saving image
pbaspect([1 1.3 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'ECS_ThylSol_Curve_Zoom','svg')

close all

%% Plotting Absolute Parameters

%pmf

close all

for w = 1:no_conditions;
    
  bar_spacing = 1/no_conditions/1.2;
    
  p_ECS_ThylSol_pmf_bar(w) = bar((w-1)*bar_spacing,ECS_ThylSol_pmf(w,end-1),'BarWidth',bar_spacing*0.9,'FaceColor',colors(w,:),'LineWidth',1.5);
  hold on
  p_ECS_ThylSol_pmf_error(w) = errorbar((w-1)*bar_spacing,ECS_ThylSol_pmf(w,end-1),ECS_ThylSol_pmf(w,end),'Color','k','LineWidth',1.5);
  hold on

end

xlabel({condition_chemical});
ylabel({'\itpmf\rm (\DeltaECS)'});

xlim([0-(bar_spacing/1.5) ((w-1)*bar_spacing)+(bar_spacing/1.5)])
% ylim([0 10])

box off
h = gca;
h.XTick = [((1:no_conditions)-1)*bar_spacing];
h.XTickLabel = concentration_names;
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1.5;
h.YAxis.LineWidth = 1.75;
hold on

% Scaling and saving image
pbaspect([0.6 1.3 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 375, 800])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'ECS_ThylSol_pmf','svg')

hold off

%gH+

close all

for w = 1:no_conditions;
    
  bar_spacing = 1/no_conditions/1.2;
    
  p_ECS_ThylSol_gH_bar(w) = bar((w-1)*bar_spacing,ECS_ThylSol_gH(w,end-1),'BarWidth',bar_spacing*0.9,'FaceColor',colors(w,:),'LineWidth',1.5);
  hold on
  p_ECS_ThylSol_gH_error(w) = errorbar((w-1)*bar_spacing,ECS_ThylSol_gH(w,end-1),ECS_ThylSol_gH(w,end),'Color','k','LineWidth',1.5);
  hold on

end

xlabel({condition_chemical});
ylabel({'\itg\rmH^{+} (s^{-1})'});

xlim([0-(bar_spacing/1.5) ((w-1)*bar_spacing)+(bar_spacing/1.5)])
% ylim([0 10])

box off
h = gca;
h.XTick = [((1:no_conditions)-1)*bar_spacing];
h.XTickLabel = concentration_names;
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1.5;
h.YAxis.LineWidth = 1.75;
hold on

% Scaling and saving image
pbaspect([0.6 1.3 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 375, 800])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'ECS_ThylSol_gH','svg')

hold off

%vH+

close all

for w = 1:no_conditions;
    
  bar_spacing = 1/no_conditions/1.2;
    
  p_ECS_ThylSol_vH_bar(w) = bar((w-1)*bar_spacing,ECS_ThylSol_vH(w,end-1),'BarWidth',bar_spacing*0.9,'FaceColor',colors(w,:),'LineWidth',1.5);
  hold on
  p_ECS_ThylSol_vH_error(w) = errorbar((w-1)*bar_spacing,ECS_ThylSol_vH(w,end-1),ECS_ThylSol_vH(w,end),'Color','k','LineWidth',1.5);
  hold on

end

xlabel({condition_chemical});
ylabel({'\itv\rmH^{+} (s)'});

xlim([0-(bar_spacing/1.5) ((w-1)*bar_spacing)+(bar_spacing/1.5)])
% ylim([0 10])

box off
h = gca;
h.XTick = [((1:no_conditions)-1)*bar_spacing];
h.XTickLabel = concentration_names;
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1.5;
h.YAxis.LineWidth = 1.75;
hold on

% Scaling and saving image
pbaspect([0.6 1.3 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 375, 800])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'ECS_ThylSol_vH','svg')

hold off
