%% TMs absorbance spectrum
%% Data Input
CV_Blank_Light = dlmread("CV_Electrolyte_Slow_Dark_3.ascii");
CV_T_DMSO_Light = dlmread("CV_SL_T+DMSO_NJ1.ascii");
CV_T_DCMU_Light = dlmread("CV_SL_T+DCMU_NI2.ascii");
CV_T_HQNO_Light = dlmread("CV_SL_T+HQNO_NI2.ascii");

CV_Blank_Dark = dlmread("CV_Electrolyte_Slow_Light_4.ascii");
CV_T_DMSO_Dark = dlmread("CV_SD_T+DMSO_NJ1.ascii");
CV_T_DCMU_Dark = dlmread("CV_SD_T+DCMU_NI2.ascii");
CV_T_HQNO_Dark = dlmread("CV_SD_T+HQNO_NI2.ascii");

load NatureColours.mat
colors = [0.6 0.6 0.6 ; greens(3,:) ; blues(3,:) ; reds(3,:)]; %RGB numbers for each condition
normalise_chl = 0;

no_peaks_Light = 5;
no_peaks_Dark = 5;

chl = 17.037;

%% Processing
if normalise_chl == 1
    chl_plug = chl
    ytitle_plug = 'Current Density (\muA [nmol Chl \ita\rm]^{-1} cm^{-2})';
else
    chl_plug = 1;
    ytitle_plug = 'Current Density (\muA cm^{-2})';
end


CV_Blank_Dark_scan(:,1) = (CV_Blank_Dark(:,2) .* 1000) + 200;
CV_Blank_Dark_scan(:,2) = CV_Blank_Dark(:,3)*10^6./chl_plug./0.75;
CV_Blank_Light_scan(:,1) = (CV_Blank_Light(:,2) .* 1000) + 200;
CV_Blank_Light_scan(:,2) = CV_Blank_Light(:,3)*10^6./chl_plug./0.75;

CV_T_DMSO_Dark_scan(:,1) = (CV_T_DMSO_Dark(:,1) .* 1000) + 200;
CV_T_DMSO_Dark_scan(:,2) = CV_T_DMSO_Dark(:,2)*10^6./chl_plug./0.75;
CV_T_DMSO_Light_scan(:,1) = (CV_T_DMSO_Light(:,1) .* 1000) + 200;
CV_T_DMSO_Light_scan(:,2) = CV_T_DMSO_Light(:,2)*10^6./chl_plug./0.75;

CV_T_DCMU_Dark_scan(:,1) = (CV_T_DCMU_Dark(:,2) .* 1000) + 200;
CV_T_DCMU_Dark_scan(:,2) = CV_T_DCMU_Dark(:,3)*10^6./chl_plug./0.75;
CV_T_DCMU_Light_scan(:,1) = (CV_T_DCMU_Light(:,2) .* 1000) + 200;
CV_T_DCMU_Light_scan(:,2) = CV_T_DCMU_Light(:,3)*10^6./chl_plug./0.75;

CV_T_HQNO_Dark_scan(:,1) = (CV_T_HQNO_Dark(:,2) .* 1000) + 200;
CV_T_HQNO_Dark_scan(:,2) = CV_T_HQNO_Dark(:,3)*10^6./chl_plug./0.75;
CV_T_HQNO_Light_scan(:,1) = (CV_T_HQNO_Light(:,2) .* 1000) + 200;
CV_T_HQNO_Light_scan(:,2) = CV_T_HQNO_Light(:,3)*10^6./chl_plug./0.75;

%% Peak Finding

[red_peaks red_locs] = findpeaks(-smooth(CV_T_DMSO_Dark_scan(1:end/2,2)),'MinPeakProminence',0.1);
[ox_peaks ox_locs] = findpeaks(smooth(CV_T_DMSO_Dark_scan(end/2+1:end,2)),'MinPeakProminence',0.01);
ox_locs = ox_locs + (length(CV_T_DMSO_Dark_scan)/2);
DMSO_Dark_peaks = CV_T_DMSO_Dark_scan([red_locs ; ox_locs],:);

[red_peaks red_locs] = findpeaks(-smooth(CV_T_DCMU_Dark_scan(1:end/2,2)),'MinPeakProminence',0.1);
[ox_peaks ox_locs] = findpeaks(smooth(CV_T_DCMU_Dark_scan(end/2+1:end,2)),'MinPeakProminence',0.1);
ox_locs = ox_locs + (length(CV_T_DCMU_Dark_scan)/2);
DCMU_Dark_peaks = CV_T_DCMU_Dark_scan([red_locs ; ox_locs],:);

[red_peaks red_locs] = findpeaks(-smooth(CV_T_HQNO_Dark_scan(1:end/2,2)),'MinPeakProminence',0.1);
[ox_peaks ox_locs] = findpeaks(smooth(CV_T_HQNO_Dark_scan(end/2+1:end,2)),'MinPeakProminence',0.001);
ox_locs = ox_locs + (length(CV_T_HQNO_Dark_scan)/2);
HQNO_Dark_peaks = CV_T_HQNO_Dark_scan([red_locs ; ox_locs],:);

[red_peaks red_locs] = findpeaks(-smooth(CV_T_DMSO_Light_scan(1:end/2,2)),'MinPeakProminence',0.1);
[ox_peaks ox_locs] = findpeaks(smooth(CV_T_DMSO_Light_scan(end/2+1:end,2)),'MinPeakProminence',0.1);
ox_locs = ox_locs + (length(CV_T_DMSO_Light_scan)/2);
DMSO_Light_peaks = CV_T_DMSO_Light_scan([red_locs ; ox_locs],:);

[red_peaks red_locs] = findpeaks(-smooth(CV_T_DCMU_Light_scan(1:end/2,2)),'MinPeakProminence',0.1);
[ox_peaks ox_locs] = findpeaks(smooth(CV_T_DCMU_Light_scan(end/2+1:end,2)),'MinPeakProminence',0.1);
ox_locs = ox_locs + (length(CV_T_DCMU_Light_scan)/2);
DCMU_Light_peaks = CV_T_DCMU_Light_scan([red_locs ; ox_locs],:);

[red_peaks red_locs] = findpeaks(-smooth(CV_T_HQNO_Light_scan(1:end/2,2)),'MinPeakProminence',0.1);
[ox_peaks ox_locs] = findpeaks(smooth(CV_T_HQNO_Light_scan(end/2+1:end,2)),'MinPeakProminence',0.1);
ox_locs = ox_locs + (length(CV_T_HQNO_Light_scan)/2);
HQNO_Light_peaks = CV_T_HQNO_Light_scan([red_locs ; ox_locs],:);

plot_peaks_Dark = [1 1].*[129 ; DMSO_Dark_peaks(2:3,1) ; HQNO_Dark_peaks(3,1) ; 355];
line_alter_Dark = [0.84 0.95 0.95 0.84 0.95];

plot_peaks_Light = [1 1].*[111 ; DMSO_Light_peaks(2:3,1) ; HQNO_Light_peaks(3,1) ; 366];
line_alter_Light = [0.84 0.95 0.95 0.84 0.95];


%% Plotting Dark CV

%Plotting curves

p_CV_Blank_Dark = plot(CV_Blank_Dark_scan(:,1),CV_Blank_Dark_scan(:,2),'LineWidth',2.5,'color',colors(1,:));
hold on
p_CV_T_DMSO_Dark = plot(CV_T_DMSO_Dark_scan(:,1),CV_T_DMSO_Dark_scan(:,2),'LineWidth',2.5,'color',colors(2,:));
hold on
p_CV_T_DCMU_Dark = plot(CV_T_DCMU_Dark_scan(:,1),CV_T_DCMU_Dark_scan(:,2),'LineWidth',2.5,'color',colors(3,:));
hold on
p_CV_T_HQNO_Dark = plot(CV_T_HQNO_Dark_scan(:,1),CV_T_HQNO_Dark_scan(:,2),'LineWidth',2.5,'color',colors(4,:));
hold on

ylim([-40 50])

bounds = ylim;

for i = 1:no_peaks_Dark

    p_Em_lines(i) = plot(plot_peaks_Dark(i,:), [bounds(1) bounds(2)*line_alter_Dark(i)], '--','LineWidth',1,'Color',[0.4 0.4 0.4])                % First Vertical Line at ‘x=4.5’
    hold on

end



% annotation("text",[0.148 0.904],[0.873 0.873],'String','Red_{1}','FontName','Helvetica Ltd Std','FontSize',17,'FontWeight','bold','Color',[0.4 0.4 0.4]);
text(plot_peaks_Dark(:,1)'-60,[bounds(2)*0.9 bounds(2) bounds(2) bounds(2)*0.9 bounds(2)],{'$E_{red}^{2}$','$E_{red}^{1}$','$E_{ox}^{1}$','$E_{ox}^{2}$','$E_{ox}^{3}$'},'Interpreter','latex','FontName','Helvetica Ltd Std','FontSize',17)

% uistack(p_Em_lines,"bottom")

xpos = 250;
ypos = 0.9;

%Adding legend
legend([p_CV_Blank_Dark p_CV_T_DMSO_Dark p_CV_T_DCMU_Dark p_CV_T_HQNO_Dark],["Blank" "TMs + 1% DMSO" "TMs + 100 \muM DCMU" "TMs + 10 \muM HQNO"],'Position',[0.7 0.19 0.1 0.1]);
legend box off
% t = text(xpos,ypos,append("\itE\rm_{m} = ",num2str(round(CV_T_DCMU_Dark_Em))," mV vs SHE"))
% t.FontName = 'Helvetica Ltd Std';
% t.FontSize = 15;
% 
% Peaks_index_DCMU = [721 835 1354 1474];
% Peaks_mV_DCMU = CV_T_DCMU_Dark_scan(Peaks_index_DCMU,1)

%Graph limits
xlim([-210 810])
ylim([-40 50])

%Plot Formatting
box off
xlabel({'Potential (mV vs SHE)'});
ylabel({ytitle_plug});
h = gca;
h.Color = [1 1 1];
h.XMinorTick = 'on';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1;
set(h ,'Layer', 'Top');
hold off

% Scaling and saving image
pbaspect([1.5 1.3 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 700, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'CV_T_Comparison_Dark','svg')

%% Plotting Light CV

%Plotting curves

p_CV_Blank_Light = plot(CV_Blank_Light_scan(:,1),CV_Blank_Light_scan(:,2),'LineWidth',2.5,'color',colors(1,:));
hold on
p_CV_T_DMSO_Light = plot(CV_T_DMSO_Light_scan(:,1),CV_T_DMSO_Light_scan(:,2),'LineWidth',2.5,'color',colors(2,:));
hold on
p_CV_T_DCMU_Light = plot(CV_T_DCMU_Light_scan(:,1),CV_T_DCMU_Light_scan(:,2),'LineWidth',2.5,'color',colors(3,:));
hold on
p_CV_T_HQNO_Light = plot(CV_T_HQNO_Light_scan(:,1),CV_T_HQNO_Light_scan(:,2),'LineWidth',2.5,'color',colors(4,:));
hold on

ylim([-40 50])

bounds = ylim;

for i = 1:no_peaks_Light

    p_Em_lines(i) = plot(plot_peaks_Light(i,:), [bounds(1) bounds(2)*line_alter_Light(i)], '--','LineWidth',1,'Color',[0.4 0.4 0.4])                % First Vertical Line at ‘x=4.5’
    hold on

end



% annotation("text",[0.148 0.904],[0.873 0.873],'String','Red_{1}','FontName','Helvetica Ltd Std','FontSize',17,'FontWeight','bold','Color',[0.4 0.4 0.4]);
text(plot_peaks_Light(:,1)'-60,[bounds(2)*0.9 bounds(2) bounds(2) bounds(2)*0.9 bounds(2)],{'$E_{red}^{2}$','$E_{red}^{1}$','$E_{ox}^{1}$','$E_{ox}^{2}$','$E_{ox}^{3}$'},'Interpreter','latex','FontName','Helvetica Ltd Std','FontSize',17)

% uistack(p_Em_lines,"bottom")

xpos = 250;
ypos = 0.9;

%Adding legend
% legend([p_CV_Blank_Light p_CV_T_DMSO_Light p_CV_T_DCMU_Light p_CV_T_HQNO_Light],["Blank" "TMs + 1% DMSO" "TMs + 100 \muM DCMU" "TMs + 10 \muM HQNO"],'Position',[0.68 0.19 0.1 0.1]);
% legend box off
% t = text(xpos,ypos,append("\itE\rm_{m} = ",num2str(round(CV_T_DCMU_Light_Em))," mV vs SHE"))
% t.FontName = 'Helvetica Ltd Std';
% t.FontSize = 15;
% 
% Peaks_index_DCMU = [721 835 1354 1474];
% Peaks_mV_DCMU = CV_T_DCMU_Light_scan(Peaks_index_DCMU,1)

%Graph limits
xlim([-210 810])
ylim([-40 50])

%Plot Formatting
box off
xlabel({'Potential (mV vs SHE)'});
ylabel({ytitle_plug});
h = gca;
h.Color = [1 1 1];
h.XMinorTick = 'on';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1;
set(h ,'Layer', 'Top');
hold off

% Scaling and saving image
pbaspect([1.5 1.3 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 700, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'CV_T_Comparison_Light','svg')

%% For Table


DMSO_peaks = ["-12" "-11" ; "+129" "+111"; "+167" "+161" ; "NA" "NA" ; "+355" "NA"]
DCMU_peaks = ["-24" "-2" ; "+129" "+117"; "+170" "+179" ; "+279" "NA" ; "NA" "+366"]
HQNO_peaks = ["-34" "-36" ; "+129" "+111"; "+167" "+153" ; "+275" "+273" ; "+367" "NA"]

