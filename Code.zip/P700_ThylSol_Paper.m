%% Correlated JTS P700 measurements JTS thylakoids + 100 uM DCMU +/- 1 mM NADPH
% Dependencies: shadedErrorBar.m, Minimiser_Baseliner.m,Cottrell_Solver_Baseline_C

%% Data Input 

% Input Parameters
no_conditions = 2; %How many conditions
no_replicates = 3; %How many biolgical replicates per condition
no_lightintensities = 8; %How many light intensities
lightintensities_uE = [10 25 50 100 250 500 750 1000]; %Potentials tested in mV, including repeat potentials.

% Fitting Conditions for Chronoamperometry
start_times = [124.89 244.884 364.679 484.573 604.467 724.362 844.256 964.151]; %Start time of first scan, first at 9.989
light_on_times = [129.884 249.879 369.673 489.568 609.462 729.357 849.251 969.146]; %Time at which first, second and third light period starts
light_off_times = [189.841 309.835 429.63 549.524 669.419 789.313 909.208 1029.1]; %Time at which first dark period starts
end_times = [249.879 369.673 489.568 609.462 729.357 849.251 969.146 1089.04]; %End time of first scan
linear_baselines = [1 1 1 1]; %0 = fits dark current with cottrel equation, 1 = fits dark current with straight line.
experiment_time = 120; %Length of light period and dark period combined
light_time = 60; %time of light period
preequilibration_time = 5; %Number of seconds prior to first light which are used for baselining
light_stabilisation_time = 30; %Point at which dark absorbance reaches steady-state 
dark_stabilisation_time = 55; %Point at which dark absorbance reaches steady-state 
DIRK_time = 7; %Region over which DIRK measurement is made
sampling_rate = 0.1; %sampling reate of JTS data

%Normalisation options
std_or_se = 1; %0 for standard deviation, 1 for standard error

%Plotting options
load NatureColours.mat
colors = [greens(3,:) ; blues(3,:)];
colors_intensities = [createcolormap(no_lightintensities, greens(1,:), greens(3,:), greens(6,:)) ; createcolormap(no_lightintensities, blues(1,:), blues(3,:), blues(6,:))]; %Select colours to use. Number of colours should equal number of concentrations
plot_names = ["" "DCMU"];
condition_names = ["TMs" "+100 \muM DCMU"];
alter_y_axis = [0.3 0.05 ; 0.3 0.05 ; 0.15 -0.25 ; 0.15 0.05 ; 0 0 ; 0 0]; %Will alter lower and upper bounds of graph y axis. + is extend, - contract. First position for lower and second for upper bound. 

%Data information
directory_name = ""; %Ensure all files are stored in the same directory
file_names = ["P700_JTS_ThylSol+MV_ND1" "P700_JTS_ThylSol+MV_ND2" "P700_JTS_ThylSol+MV_ND3" ; "P700_JTS_ThylSol+MV+DCMU_ND1" "P700_JTS_ThylSol+MV+DCMU_ND2" "P700_JTS_ThylSol+MV+DCMU_ND3"];
file_extension = ".ascii";


%% Processing 705nm data
for i = 1:no_conditions; 
    for j = 1:no_replicates;   
    
            input = dlmread(append(directory_name,file_names(i,j),file_extension));
            tinput = input(:,1);
            Iinput = input(:,2)*10^3;
            experiment_time = experiment_time;
            light_time = light_time;
            preequilibration_time = preequilibration_time;
            sampling_rate = sampling_rate;
            dark_stabilisation_time = dark_stabilisation_time;
            
        for k = 1:no_lightintensities;
            
            start_time = start_times(k); 
            light_on = light_on_times(k);
            light_off = light_off_times(k);
            end_time = end_times(k);

            Linear_Baseliner_JTS %Calls baselining function
            
            P705_ThylSol{i}(:,1,k) = tplot;
            P705_ThylSol{i}(:,j+1,k) =  Iplot_baseline_corrected;

        end
    end
end

%% Processing 740nm data
for i = 1:no_conditions; 
    for j = 1:no_replicates;   
    
            input = dlmread(append(directory_name,file_names(i,j),file_extension));
            tinput = input(:,1);
            Iinput = input(:,3)*10^3;
            experiment_time = experiment_time;
            light_time = light_time;
            preequilibration_time = preequilibration_time;
            sampling_rate = sampling_rate;
            dark_stabilisation_time = dark_stabilisation_time;
            
        for k = 1:no_lightintensities;
            
            start_time = start_times(k); 
            light_on = light_on_times(k);
            light_off = light_off_times(k);
            end_time = end_times(k);

            Linear_Baseliner_JTS %Calls baselining function
            
            P740_ThylSol{i}(:,1,k) = tplot;
            P740_ThylSol{i}(:,j+1,k) =  Iplot_baseline_corrected;

        end
    end
end

%% Calculating parameters

for i = 1:no_conditions;
    
    P700_ThylSol{i} = zeros(length(P705_ThylSol{i}),no_replicates+1,no_lightintensities);
    P700_ThylSol{i}(:,1,:) = P705_ThylSol{i}(:,1,:); 
    P700_ThylSol{i}(:,2:end,:) = P705_ThylSol{i}(:,2:end,:)-P740_ThylSol{i}(:,2:end,:); 
    
    for j = 1:no_replicates;
        for k = 1:no_lightintensities;

            P700_ThylSol_MaxAbs(k,j,i) = abs(mean(P700_ThylSol{i}((preequilibration_time+light_stabilisation_time)/sampling_rate:(preequilibration_time+light_time)/sampling_rate,j+1,k)));
            P740_ThylSol_MaxAbs(k,j,i) = abs(mean(P740_ThylSol{i}((preequilibration_time+light_stabilisation_time)/sampling_rate:(preequilibration_time+light_time)/sampling_rate,j+1,k)));
        
        end
    end
end

%% Averaging

if std_or_se == 0;
    error_normaliser = 1;
else
    error_normaliser = sqrt(no_replicates);
end

%Averaging Scans for PAM
for i = 1:no_conditions
    for l = 1:no_replicates;

        P700_ThylSol{i}(:,no_replicates+2,:) = mean(P700_ThylSol{i}(:,2:no_replicates+1,:),2);
        P700_ThylSol_MaxAbs(:,no_replicates+1,i) = mean(P700_ThylSol_MaxAbs(:,1:no_replicates,i),2);
        P740_ThylSol{i}(:,no_replicates+2,:) = mean(P740_ThylSol{i}(:,2:no_replicates+1,:),2);
        P740_ThylSol_MaxAbs(:,no_replicates+1,i) = mean(P740_ThylSol_MaxAbs(:,1:no_replicates,i),2);

        P700_ThylSol{i}(:,no_replicates+3,:) = std(P700_ThylSol{i}(:,2:no_replicates+1,:),0,2)./error_normaliser;
        P700_ThylSol_MaxAbs(:,no_replicates+2,i) = std(P700_ThylSol_MaxAbs(:,1:no_replicates,i),0,2)./error_normaliser;
        P740_ThylSol{i}(:,no_replicates+3,:) = std(P740_ThylSol{i}(:,2:no_replicates+1,:),0,2)./error_normaliser;
        P740_ThylSol_MaxAbs(:,no_replicates+2,i) = std(P740_ThylSol_MaxAbs(:,1:no_replicates,i),0,2)./error_normaliser;
    end
end


%% Plotting P700 Curve
close all

%Plotting curves
for n = 1:no_conditions
    for m = 1:no_lightintensities;
        intensity_names(m) = append(num2str(lightintensities_uE(m))," \muE m^{-2} s^{-1}");
    
        p_P700_ThylSol(n,m) = shadedErrorBar(P700_ThylSol{n}(:,1,1),P700_ThylSol{n}(:,no_replicates+2,m),P700_ThylSol{n}(:,no_replicates+3,m),'lineProps',{'LineWidth',2.5,'color',colors_intensities(((n-1)*no_lightintensities)+m,:)});
        if m == no_conditions;

        else
        end
        hold on
    
    end

    % legend('AutoUpdate','off')
    % legend([p_P700_ThylSol(n,1:end).mainLine],intensity_names,'location','northwest');
    % legend box off
    
    %Graph limits
    max_abs = max(max(P700_ThylSol{n}(:,no_replicates+2,:)));
    max_abs_range = round(max_abs,1,'significant');

    x_lower = 0;
    x_upper = tplot(end);
    y_lower = 0-alter_y_axis(n,1);
    y_upper = max_abs_range+alter_y_axis(n,2);
    xlim([x_lower x_upper])
     ylim([y_lower y_upper]);

    %Adding annotations
    onbox1 = area([5 65],[y_upper y_upper]);
    onbox1.BaseValue = y_lower;
    onbox1.FaceColor = [1 1 1];
    onbox1.EdgeColor = 'none';
    uistack(onbox1,'bottom');
    hold on

    %Plot Formatting
    box off
    xlabel({'Time (seconds)'});
    ylabel({'P700^{+} (\DeltaI/Ix10^{3})'});
    h = gca;
    h.Color = [0.8 0.8 0.8];
    h.XMinorTick = 'on';
    h.YMinorTick = 'on';
    h.TickDir = 'out';
    h.FontName = 'Helvetica Ltd Std';
    h.FontSize = 17;
    h.LineWidth = 1;
    set(h ,'Layer', 'Top');
    hold off

    % Scaling and saving image
    pbaspect([1 1.3 1]);
    set(gcf, 'Renderer', 'painter');
    set(gcf,'color','w');
    set(gcf, 'Position',  [100, 100, 500, 600])
    set(gcf, 'InvertHardCopy', 'off');
    saveas(gcf,append('P700_ThylSol_Curve_',plot_names(n)),'svg')
    
    close all

end

%% Plotting Plastocyanin Curve
close all

%Plotting curves
for n = 1:no_conditions
    for m = 1:no_lightintensities;
        intensity_names(m) = append(num2str(lightintensities_uE(m))," \muE m^{-2} s^{-1}");
    
        p_P740_ThylSol(n,m) = shadedErrorBar(P740_ThylSol{n}(:,1,1),P740_ThylSol{n}(:,no_replicates+2,m),P740_ThylSol{n}(:,no_replicates+3,m),'lineProps',{'LineWidth',2.5,'color',colors_intensities(((n-1)*no_lightintensities)+m,:)});
        if m == no_conditions;

        else
        end
        hold on
    
    end

    % legend('AutoUpdate','off')
    % legend([p_P740_ThylSol(n,1:end).mainLine],intensity_names,'location','northwest');
    % legend box off
    
    %Graph limits
    max_abs = max(max(P740_ThylSol{n}(:,no_replicates+2,:)));
    max_abs_range = round(max_abs,1,'significant');

    x_lower = 0;
    x_upper = tplot(end);
    y_lower = 0-alter_y_axis(n+no_conditions,1);
    y_upper = max_abs_range+alter_y_axis(n+no_conditions,2);
    xlim([x_lower x_upper])
    ylim([y_lower y_upper]);

    %Adding annotations
    onbox1 = area([5 65],[y_upper y_upper]);
    onbox1.BaseValue = y_lower;
    onbox1.FaceColor = [1 1 1];
    onbox1.EdgeColor = 'none';
    uistack(onbox1,'bottom');
    hold on

    %Plot Formatting
    box off
    xlabel({'Time (seconds)'});
    ylabel({'Pc Redox Changes (\DeltaI/Ix10^{3})'});
    h = gca;
    h.Color = [0.8 0.8 0.8];
    h.XMinorTick = 'on';
    h.YMinorTick = 'on';
    h.TickDir = 'out';
    h.FontName = 'Helvetica Ltd Std';
    h.FontSize = 17;
    h.LineWidth = 1;
    set(h ,'Layer', 'Top');
    hold off

    % Scaling and saving image
    pbaspect([1 1.3 1]);
    set(gcf, 'Renderer', 'painter');
    set(gcf,'color','w');
    set(gcf, 'Position',  [100, 100, 500, 600])
    set(gcf, 'InvertHardCopy', 'off');
    saveas(gcf,append('Plastocyanin_ThylSol_Curve_',plot_names(n)),'svg')
    
    close all

end


%% Plotting Absolute P700 Parameters
close all

for i = 1: no_conditions;
    
    p_P700_ThylSol_MaxAbs(i) = errorbar(lightintensities_uE,P700_ThylSol_MaxAbs(:,no_replicates+1,i),P700_ThylSol_MaxAbs(:,no_replicates+2,i),'Color',colors(i,:),'LineWidth',3);
    hold on

end

legend([p_P700_ThylSol_MaxAbs],condition_names,'location','northeast');
legend box off

xlabel({'Light Intensity (\mumol photons m^{-2} s^{-1})'});
ylabel({'Steady State P700^{+} (\DeltaI/Ix10^{3})'});
box off

xlim([lightintensities_uE(1) lightintensities_uE(end)])
    
pbaspect([1 1 1]);
h = gca;
h.XAxis.TickLength = [0.005 0.005];
h.XMinorTick = 'off';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize= 17;
h.LineWidth = 1;
hold on

% Scaling and saving image

pbaspect([1 1.3 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'P700_ThylSol_MaxAbs','svg')

%% Plotting Absolute Plastocyanin Parameters
close all

for i = 1: no_conditions;
    
    p_P740_ThylSol_MaxAbs(i) = errorbar(lightintensities_uE,P740_ThylSol_MaxAbs(:,no_replicates+1,i),P740_ThylSol_MaxAbs(:,no_replicates+2,i),'Color',colors(i,:),'LineWidth',3);
    hold on

end

legend([p_P740_ThylSol_MaxAbs],condition_names,'location','northeast');
legend box off

xlabel({'Light Intensity (\mumol photons m^{-2} s^{-1})'});
ylabel({'Steady State Pc Reduction (\DeltaI/Ix10^{3})'});
box off

xlim([lightintensities_uE(1) lightintensities_uE(end)])
    
pbaspect([1 1 1]);
h = gca;
h.XAxis.TickLength = [0.005 0.005];
h.XMinorTick = 'off';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize= 17;
h.LineWidth = 1;
hold on

% Scaling and saving image

pbaspect([1 1.3 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'Plastocyanin_ThylSol_MaxAbs','svg')
