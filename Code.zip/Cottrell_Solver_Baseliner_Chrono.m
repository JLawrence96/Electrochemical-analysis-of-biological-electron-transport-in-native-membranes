% Cottrell Solver

%% Input processing

sampling = sampling_rate * 10^(5-intensity);

real_start_time = round(start_time + sampling_rate,4);
real_end_time = round(end_time,4);
real_light_on = round(light_on + sampling_rate,4);
real_light_off = round(light_off + sampling_rate,4);
real_dark_stabilisation_time = round(real_light_off + dark_stabilisation_time,4);
real_light_stabilisation_time = round(real_light_on + light_stabilisation_time,4);
real_spike_stabilisation_time = round(real_light_on + spike_stabilisation_time,4);

start_time_index = find(abs(tinput-real_start_time)<0.25*sampling_rate);
end_time_index = find(abs(tinput-real_end_time)<0.25*sampling_rate);
light_range_index = find(tinput >= real_light_on & tinput <= real_dark_stabilisation_time);
spike_range_index = find(tinput >= real_light_on & tinput <= real_spike_stabilisation_time);
dark_current_range_index = find(tinput >= real_dark_stabilisation_time & tinput <= real_end_time);
photocurrent_range_index = find(tinput >= real_light_stabilisation_time & tinput <= real_light_off);
dark_dip_range_index = find(tinput >= real_light_off & tinput <= (real_light_off + 10));

zeroed_start_time = sampling_rate;
zeroed_end_time = real_end_time - start_time;
zeroed_light_on = real_light_on - start_time;
zeroed_light_off = real_light_off - start_time;
zeroed_dark_stabilisation_time = real_dark_stabilisation_time - start_time;
zeroed_light_stabilisation_time = real_light_stabilisation_time - start_time;
zeroed_light_range_index = light_range_index -start_time_index;
zeroed_spike_range_index = spike_range_index -start_time_index;
zeroed_photocurrent_range_index = photocurrent_range_index - start_time_index;
zeroed_dark_current_range_index = dark_current_range_index - start_time_index;
zeroed_dark_dip_range_index = dark_dip_range_index - start_time_index;

tdata = tinput([start_time_index:light_range_index(1),light_range_index(end):end_time_index],:);
tdata = tdata-start_time;
Idata = Iinput([start_time_index:light_range_index(1),light_range_index(end):end_time_index],:);
Idata = Idata;

tplot = tinput([start_time_index:end_time_index],:);
tplot = tplot-start_time;
Iplot = Iinput([start_time_index:end_time_index],:);
Iplot = Iplot;

%% Linear or Cotterell 

if linear_baseline == 1;
    % Linear Solver
    
    Linear_Baseliner(tdata,Idata);
    final_m = m_value;
    final_c = c_value;
    optim_guess = (final_m * tplot) + final_c;

else
    %Cotterell Solver
        
    %Time window Shifter
    tmod = 0;
    tmodmax = sampling * 1000000000;

    iteration = 1
    iter_lambda_error = zeros(1,4);
    iter_lambda_error2 = zeros(1,4);

    while tmod < tmodmax;
        Minimiser_Baseliner(tdata+tmod,Idata,radius);
        iter_lambda_error2(1) = tmod;
        iter_lambda_error2(2) = lambda_value;
        iter_lambda_error2(3) = D_value;
        iter_lambda_error2(4) = error_value;
        hold on
        if iter_lambda_error2(4) > iter_lambda_error(4) && iter_lambda_error(4) > 0;
            break
        else
            tmod = tmod + sampling;
            iteration = 1 + iteration
            iter_lambda_error = iter_lambda_error2;
        end
    end

    final_tmod = iter_lambda_error(1);
    final_lambda = iter_lambda_error(2);
    final_D = iter_lambda_error(3);
    optim_guess=cottrell_sphere(final_lambda, final_D, tplot+tmod, radius);
end
%% Processed Scans and Parameters
Iplot_baseline_corrected = (Iplot-optim_guess);
dark_current = mean(Iplot(zeroed_dark_current_range_index));
photocurrent = mean(Iplot_baseline_corrected(zeroed_photocurrent_range_index));
spike_current = max(Iplot_baseline_corrected);

if photocurrent < 0
    photocurrent = 0;
end

% min_photocurrent = min(Iplot_baseline_corrected(321:580))
photocurrent_corrected = Iplot_baseline_corrected-photocurrent;
photocurrent_corrected(photocurrent_corrected < 0)=0;
spike_charge = trapz(photocurrent_corrected(zeroed_spike_range_index));

dip_region = Iplot_baseline_corrected(zeroed_dark_dip_range_index);
dip_region(dip_region > 0) = 0;
dip_charge = trapz(abs(dip_region));


subplot(1,3,1);
plot(tplot,Iplot);
hold on
plot(tplot,optim_guess);
hold on

subplot(1,3,2);
plot(tplot,Iplot_baseline_corrected);
hold on

subplot(1,3,3);
plot(tplot,photocurrent_corrected);
hold on

%% Clearance
% clearvars -except Fc1 Fc2 Fc3 Fc4 Fc5 Fc6 Fc7 Fc8 Fc9 Fc10 Fc11 Fc12 final_tmod final_D final_lambda optim_guess photocurrent spike_charge


function data=cottrell_sphere(lambda, D, tdata, r)
        data=lambda * D *(((pi * D * tdata).^-1/2) + (r^-1));
end

