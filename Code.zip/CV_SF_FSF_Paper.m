%% TMs absorbance spectrum
%% Data Input
CV_Electrolyte = dlmread("Lysis_CV.ascii");
CV_SF = dlmread("SF_CV.ascii");
CV_FSF = dlmread("FSF_CV.ascii");
condition_names = ["Blank" ; "SF" ; "Filtered SF"];

load NatureColours.mat
colors = [0.6 0.6 0.6 ;  blues(3,:) ; purples(3,:) ]; %RGB numbers for each condition


%% Processing
CV_Electrolyte_scan(:,1) = (CV_Electrolyte(:,1) .* 1000) + 200;
CV_Electrolyte_scan(:,2) = CV_Electrolyte(:,2)*10^6;

CV_SF_scan(:,1) = (CV_SF(:,1) .* 1000) + 200;
CV_SF_scan(:,2) = CV_SF(:,2)*10^6;

CV_FSF_scan(:,1) = (CV_FSF(:,1) .* 1000) + 200;
CV_FSF_scan(:,2) = CV_FSF(:,2)*10^6;

CV_SF_OxPeak_index = find(CV_SF_scan(:,2)==max(CV_SF_scan(:,2)));
CV_SF_RedPeak_index = find(CV_SF_scan(:,2)==min(CV_SF_scan(:,2)));
CV_SF_OxPeak = CV_SF_scan(CV_SF_OxPeak_index(round(length(CV_SF_OxPeak_index)/2)),1);
CV_SF_RedPeak = CV_SF_scan(CV_SF_RedPeak_index(round(length(CV_SF_RedPeak_index)/2)),1);
CV_SF_Em = CV_SF_RedPeak + ((CV_SF_OxPeak - CV_SF_RedPeak)./2)

CV_FSF_OxPeak_index = find(CV_FSF_scan(:,2)==max(CV_FSF_scan(:,2)));
CV_FSF_RedPeak_index = find(CV_FSF_scan(:,2)==min(CV_FSF_scan(:,2)));
CV_FSF_OxPeak = CV_FSF_scan(CV_FSF_OxPeak_index(round(length(CV_FSF_OxPeak_index)/2)),1);
CV_FSF_RedPeak = CV_FSF_scan(CV_FSF_RedPeak_index(round(length(CV_FSF_RedPeak_index)/2)),1);
CV_FSF_Em = CV_FSF_RedPeak + ((CV_FSF_OxPeak - CV_FSF_RedPeak)./2)

%% Plotting

%Plotting curves
p_CV_Electrolyte = plot(CV_Electrolyte_scan(:,1),CV_Electrolyte_scan(:,2),'LineWidth',2.5,'color',colors(1,:));
hold on
p_CV_SF = plot(CV_SF_scan(:,1),CV_SF_scan(:,2),'LineWidth',2.5,'color',colors(2,:));
hold on
p_CV_FSF = plot(CV_FSF_scan(:,1),CV_FSF_scan(:,2),'LineWidth',2.5,'color',colors(3,:));
hold on

xpos = -550;
ypos = 1.8;
 
t = text(xpos,ypos,append("\itE\rm_{m} = +",num2str(round(CV_FSF_Em))," mV vs SHE"))
t.FontName = 'Helvetica Ltd Std';
t.FontSize = 15;

legend([p_CV_Electrolyte p_CV_SF p_CV_FSF],condition_names,'location','southeast');
legend box off

%Graph limits
xlim([-610 700])
% ylim([-70 60])

%Plot Formatting
box off
xlabel({'Potential (mV vs SHE)'});
ylabel({'Current (\muA)'});
h = gca;
h.Color = [1 1 1];
h.XMinorTick = 'on';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1;
set(h ,'Layer', 'Top');
hold off

% Scaling and saving image
pbaspect([1.5 1.3 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 700, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'CV_SF_FSF','svg')
