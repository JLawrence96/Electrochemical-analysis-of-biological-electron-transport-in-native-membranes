% Linear Solver
% Dimensionless Parameter Minimiser

function Linear_Baseliner(tdata,Idata)  

initial_guess=[rand(1) rand(1)];
options=optimset('TolFun', 1e-15, 'MaxIter', 1e100000, 'MaxfunEvals', 1e1000); %This should be plenty
param_min=fminsearch(@fitting, initial_guess, options);

assignin('base','m_value',param_min(1))
assignin('base','c_value',param_min(2))

    function data=straight_line(m, c, tdata) %This is the cotterel equation function
        data= (m * tdata) + c; %This is the spherical treatment of the cotterel function, so change that to the standard treatment. 
end
    
 function error2=fitting(param_guess) %This is the error fitting function
        m_guess=param_guess(1); 
        c_guess=param_guess(2);
        simulation=straight_line(m_guess, c_guess, tdata);
        error2=round((sum((simulation-Idata).^2)),5);
        assignin('base','error_value',error2);
 end


end

%Once the code has finished running please remember to save the final
%optimised parameters (e.g. D_findal = D_guess after the function). 