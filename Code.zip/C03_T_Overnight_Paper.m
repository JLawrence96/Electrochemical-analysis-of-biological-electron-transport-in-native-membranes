%% Chronoamperommetry Synechocystis thylakoids
% Dependencies: shadedErrorBar.m, Minimiser_Baseliner.m,Cottrell_Solver_Baseline_C

%% Data Input 

% Input Parameters
no_replicates = 3; %How many biolgical replicates per condition
no_scans = 200; %How many scans should be averaged

% Fitting Conditions
intensities = [5 5 5]; %Computing intensities for curve fitting
start_times = [125.2 124.9 245]; %Start time of first scan
light_on_times = [130.2 129.9 250]; %Time at which first light period starts
light_off_times = [190.2 189.9 310]; %Time at which first dark period starts
end_times = [250.2 249.9 370]; %End time of first scan
linear_baselines = [1 1 1]; %0 = fits dark current with cottrel equation, 1 = fits dark current with straight line.
light_stabilisation_time = 30; %Point at which photocurrent reaches steady-state
dark_stabilisation_time = 45; %Point at which dark current reaches steady-state
spike_stabilisation_time = 15; %Point at which light current reaches steady state, normally 15 seconds
spacing_time = 120; %space between scans
radius = 5000; %radius of spherical electrode (um). Assumes porous electrodes are 1000x single pore radius.  
sampling_rate = 0.1; %sampling reate of chronoamp data
electrode_surface_area = 0.75; %Surface area of electrode in cm^2

%Normalisation options
normalise_chl = 1;
std_or_se = 1; %0 for standard deviation, 1 for standard error

%Plotting options
xtime = (0.1:0.1:125)'; %Time range of x axis, should be end_time - start_time
load NatureColours.mat
colors = [greens([3],:)]; %Select colours to use. Number of colours should equal number of concentrations
alter_y_axis = [2 0]; %Will alter lower and upper bounds of graph y axis. + is extend, - contract. First position for lower and second for upper bound. 


%Data information
directory_name = ""; %Ensure all files are stored in the same directory
file_names = ["C03_T_ON_NH1" "C03_T_ON_NH3" "C03_T_Overnight_NL3"];
file_extension = ".ascii";
chl_nM = [13.467 15.886 4.855]; %For chlorophyll normalisation. Set as an array of 1s for each dataset if no normalisation is required.

%% Processing
 time_mod = 0;
 time_mod2 = 0;
 time_mod3 = 0;

for j = 1:no_replicates;   
    
            C03_T_Overnight(:,1,j) = xtime;

            input = dlmread(append(directory_name,file_names(j),file_extension));
            tinput = input(:,1);
            Iinput = ((input(:,2)*10^9) /electrode_surface_area) / chl_nM(j);
            intensity = intensities(j); 
            start_time_0 = start_times(j); 
            light_on_0 = light_on_times(j);
            light_off_0 = light_off_times(j);
            end_time_0 = end_times(j);

            linear_baseline = linear_baselines(j);
            
        for k = 1:no_scans;
           
            time_mod = round((k/2.5))*0.1;
            time_mod2 = round((k/10))*0.1;
            time_mod3 = round((k/40))*0.1;

            start_time = start_time_0 + ((k-1)*spacing_time) + time_mod + time_mod2 + time_mod3; 
            light_on = light_on_0 + ((k-1)*spacing_time) + time_mod  + time_mod2 + time_mod3;
            light_off = light_off_0 + ((k-1)*spacing_time) + time_mod  + time_mod2 + time_mod3;
            end_time = end_time_0 + ((k-1)*spacing_time) + time_mod  + time_mod2 + time_mod3;

            Cottrell_Solver_Baseliner_Chrono %Calls baselining function
            
            C03_T_Overnight(:,j+1,k) =  Iplot_baseline_corrected;
            C03_T_Overnight_dark_currents(k,j) = dark_current;
            C03_T_Overnight_photocurrents(k,j) = photocurrent;
            C03_T_Overnight_spike_charges(k,j) = spike_charge;
            C03_T_Overnight_dip_charges(k,j) = dip_charge;
            

            
        end
    end

%% Averaging and calculating percentage changes;
C03_T_Overnight_dark_currents_relative = (C03_T_Overnight_dark_currents ./ C03_T_Overnight_dark_currents(1,:)).*100;
C03_T_Overnight_photocurrents_relative = (C03_T_Overnight_photocurrents ./ C03_T_Overnight_photocurrents(1,:)).*100;
C03_T_Overnight_spike_charges_relative = (C03_T_Overnight_spike_charges ./ C03_T_Overnight_spike_charges(1,:)).*100;
C03_T_Overnight_dip_charges_relative = (C03_T_Overnight_dip_charges ./ C03_T_Overnight_dip_charges(1,:)).*100;


if std_or_se == 0;
    error_normaliser = 1;
else
    error_normaliser = sqrt(no_replicates);
end

C03_T_Overnight_dark_currents_relative(:,no_replicates+1) = mean(C03_T_Overnight_dark_currents_relative,2);
C03_T_Overnight_dark_currents_relative(:,no_replicates+2) = std(C03_T_Overnight_dark_currents_relative,0,2)/error_normaliser;
C03_T_Overnight_photocurrents_relative(:,no_replicates+1) = mean(C03_T_Overnight_photocurrents_relative,2);
C03_T_Overnight_photocurrents_relative(:,no_replicates+2) = std(C03_T_Overnight_photocurrents_relative,0,2)/error_normaliser;
C03_T_Overnight_spike_charges_relative(:,no_replicates+1) = mean(C03_T_Overnight_spike_charges_relative,2);
C03_T_Overnight_spike_charges_relative(:,no_replicates+2) = std(C03_T_Overnight_spike_charges_relative,0,2)/error_normaliser;
C03_T_Overnight_dip_charges_relative(:,no_replicates+1) = mean(C03_T_Overnight_dip_charges_relative,2);
C03_T_Overnight_dip_charges_relative(:,no_replicates+2) = std(C03_T_Overnight_dip_charges_relative,0,2)/error_normaliser;

%% Plotting Curves
close all

xplot = 0:120/60:(120*(no_scans-1))/60;
%Plotting curves
p_C03_T_Overnight(1) = shadedErrorBar(xplot,C03_T_Overnight_photocurrents_relative(:,no_replicates+1),C03_T_Overnight_photocurrents_relative(:,no_replicates+2),'lineProps',{'LineWidth',2.5,'color',colors(1,:)});
hold on
% p_C03_T_Overnight(2) = shadedErrorBar(xplot,C03_T_Overnight_spike_charges_relative(:,no_replicates+1),C03_T_Overnight_spike_charges_relative(:,no_replicates+2),'lineProps',{'LineWidth',2.5,'color',colors(1,:)});
% hold on

%Graph limits
% xlim([x_lower x_upper])
ylim([20 100]);

%Plot Formatting
box off
xlabel({'Time (min)'});
ylabel({'Relative Steady State Photocurrent (%)'});
h = gca;
h.Color = [1 1 1];
h.XMinorTick = 'on';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 15;
h.LineWidth = 1;
set(h ,'Layer', 'Top');
hold off

% Scaling and saving image
pbaspect([2.6 1.3 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 1200, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_Overnight_Curve','svg')
