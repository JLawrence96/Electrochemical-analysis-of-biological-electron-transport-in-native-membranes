%% Chronoamperommetry Thylakoid Membranes + HQNO
% Dependencies: shadedErrorBar.m, Minimiser_Baseliner.m,Cottrell_Solver_Baseline_C

%% Data Input 

% Input Parameters
no_concentrations = 6; %How many conditions will be compared
no_replicates = 3; %How many biolgical replicates per condition
no_scans = 3; %How many scans should be averaged
concentrations_uM = [0 0.1 0.5 1 5 10]; %Potentials tested in mV, including repeat potentials.
chemical_units = "\muM";

% Fitting Conditions
intensities = [5 5 5 5 5 5 ; 5 5 5 5 5 5 ; 5 5 5 5 5 5]; %Computing intensities for curve fitting
start_times = [125 125 125 125 125 125 ; 125 125 125 125 125 125 ; 125 125 125 125 125 125]; %Start time of first scan
light_on_times = [130 130 130 130 130 130 ; 130 130 130 130 130 130 ; 130 130 130 130 130 130]; %Time at which first light period starts
light_off_times = [190 190 190 190 190 190 ; 190 190 190 190 190 190 ; 190 190 190 190 190 190]; %Time at which first dark period starts
end_times = [250 250 250 250 250 250 ; 250 250 250 250 250 250 ; 250 250 250 250 250 250]; %End time of first scan
linear_baselines = [1 1 1 1 1 1 ; 1 1 1 1 1 1 ; 1 1 1 1 1 1]; %0 = fits dark current with cottrel equation, 1 = fits dark current with straight line.
light_stabilisation_time = 30; %Point at which photocurrent reaches steady-state
dark_stabilisation_time = 45; %Point at which dark current reaches steady-state
spike_stabilisation_time = 15; %Point at which light current reaches steady state, normally 15 seconds
spacing_time = 120; %space between scans
radius = 5000; %radius of spherical electrode (um). Assumes porous electrodes are 1000x single pore radius.  
sampling_rate = 0.1; %sampling reate of chronoamp data
electrode_surface_area = 0.75; %Surface area of electrode in cm^2

%Normalisation options
normalise_chl = 1;
std_or_se = 1; %0 for standard deviation, 1 for standard error

%Plotting options
xtime = (0.1:0.1:125)'; %Time range of x axis, should be end_time - start_time
load NatureColours.mat
colors = [reds(1:6,:)]; %Select colours to use. Number of colours should equal number of concentrations

%Data information
directory_name = ""; %Ensure all files are stored in the same directory
file_names = ["C03_T+HQNO_NC3" "C03_T+HQNO_NG2" "C03_T+HQNO_NG3"];
file_extension = ".ascii";
chl_nM = [12.487 16.490 13.859]; %For chlorophyll normalisation. Set as an array of 1s for each dataset if no normalisation is required.
chemical_name = "HQNO";

%% Processing
for i = 1:no_concentrations;
    
        C03_T_HQNO(:,1,i) = xtime;
        
    for j = 1:no_replicates;
                    
            input = dlmread(append(directory_name,file_names(j),"_",num2str(i),file_extension));
            tinput = input(:,1);
            Iinput = ((input(:,2)*10^9) /electrode_surface_area) / chl_nM(j);
            intensity = intensities(j,i); 
            start_time = start_times(j,i); 
            light_on = light_on_times(j,i);
            light_off = light_off_times(j,i);
            end_time = end_times(j,i);
            linear_baseline = linear_baselines(j,i);
            
        for k = 1:no_scans;
            
            Cottrell_Solver_Baseliner_Chrono %Calls baselining function
            
            C03_T_HQNO(:,((j-1)*no_scans)+k+1,i) =  Iplot_baseline_corrected;
            C03_T_Inhibitor_dark_currents(i,((j-1)*no_scans)+k) = dark_current;
            C03_T_Inhibitor_photocurrents(i,((j-1)*no_scans)+k) = photocurrent;
            C03_T_Inhibitor_spike_charges(i,((j-1)*no_scans)+k) = spike_charge;
            C03_T_Inhibitor_dip_charges(i,((j-1)*no_scans)+k) = dip_charge;
            
            start_time = start_time+spacing_time; 
            light_on = light_on+spacing_time;
            light_off = light_off+spacing_time;
            end_time = end_time+spacing_time;
            
        end
    end
end

%% Averaging and calculating percentage changes;

%Averaging scans
for l = 1:no_replicates;
    C03_T_HQNO(:,(no_scans*no_replicates)+1+l,:) = mean(C03_T_HQNO(:,((l-1)*no_scans)+2:((l-1)*no_scans)+no_scans+1,:),2);
    C03_T_Inhibitor_dark_currents(:,(no_scans*no_replicates)+l) = mean(C03_T_Inhibitor_dark_currents(:,((l-1)*no_scans)+1:((l-1)*no_scans)+no_scans),2);
    C03_T_Inhibitor_photocurrents(:,(no_scans*no_replicates)+l) = mean(C03_T_Inhibitor_photocurrents(:,((l-1)*no_scans)+1:((l-1)*no_scans)+no_scans),2);
    C03_T_Inhibitor_spike_charges(:,(no_scans*no_replicates)+l) = mean(C03_T_Inhibitor_spike_charges(:,((l-1)*no_scans)+1:((l-1)*no_scans)+no_scans),2);
    C03_T_Inhibitor_dip_charges(:,(no_scans*no_replicates)+l) = mean(C03_T_Inhibitor_dip_charges(:,((l-1)*no_scans)+1:((l-1)*no_scans)+no_scans),2);
end


%Averaging replicates and calculating errors

if std_or_se == 0;
    error_normaliser = 1;
else
    error_normaliser = sqrt(no_replicates);
end

C03_T_HQNO(:,(no_scans*no_replicates)+no_replicates+2,:) = mean(C03_T_HQNO(:,(no_scans*no_replicates)+2:(no_scans*no_replicates)+no_replicates+1,:),2);
C03_T_HQNO(:,(no_scans*no_replicates)+no_replicates+3,:) = std(C03_T_HQNO(:,(no_scans*no_replicates)+2:(no_scans*no_replicates)+no_replicates+1,:),0,2)/error_normaliser;
C03_T_Inhibitor_dark_currents(:,(no_scans*no_replicates)+no_replicates+1) = mean(C03_T_Inhibitor_dark_currents(:,(no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates),2);
C03_T_Inhibitor_dark_currents(:,(no_scans*no_replicates)+no_replicates+2) = std(C03_T_Inhibitor_dark_currents(:,(no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates),0,2)/error_normaliser;
C03_T_Inhibitor_photocurrents(:,(no_scans*no_replicates)+no_replicates+1) = mean(C03_T_Inhibitor_photocurrents(:,(no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates),2);
C03_T_Inhibitor_photocurrents(:,(no_scans*no_replicates)+no_replicates+2) = std(C03_T_Inhibitor_photocurrents(:,(no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates),0,2)/error_normaliser;
C03_T_Inhibitor_spike_charges(:,(no_scans*no_replicates)+no_replicates+1) = mean(C03_T_Inhibitor_spike_charges(:,(no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates),2);
C03_T_Inhibitor_spike_charges(:,(no_scans*no_replicates)+no_replicates+2) = std(C03_T_Inhibitor_spike_charges(:,(no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates),0,2)/error_normaliser;
C03_T_Inhibitor_dip_charges(:,(no_scans*no_replicates)+no_replicates+1) = mean(C03_T_Inhibitor_dip_charges(:,(no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates),2);
C03_T_Inhibitor_dip_charges(:,(no_scans*no_replicates)+no_replicates+2) = std(C03_T_Inhibitor_dip_charges(:,(no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates),0,2)/error_normaliser;

%Calculating relative changes to parameters

C03_T_Inhibitor_dark_currents_relative(1,1:no_replicates) = 0;
C03_T_Inhibitor_dark_currents_relative(2:no_concentrations,1:no_replicates) = (C03_T_Inhibitor_dark_currents(2:end,no_scans*no_replicates+1:(no_scans*no_replicates)+no_replicates) - C03_T_Inhibitor_dark_currents(1,no_scans*no_replicates+1:(no_scans*no_replicates)+no_replicates));
C03_T_Inhibitor_photocurrents_relative(1,1:no_replicates) = 100;
C03_T_Inhibitor_photocurrents_relative(2:no_concentrations,1:no_replicates) = (C03_T_Inhibitor_photocurrents(2:end,no_scans*no_replicates+1:(no_scans*no_replicates)+no_replicates) ./ C03_T_Inhibitor_photocurrents(1,no_scans*no_replicates+1:(no_scans*no_replicates)+no_replicates)) *100;
C03_T_Inhibitor_spike_charges_relative(1,1:no_replicates) = 100;
C03_T_Inhibitor_spike_charges_relative(2:no_concentrations,1:no_replicates) = (C03_T_Inhibitor_spike_charges(2:end,no_scans*no_replicates+1:(no_scans*no_replicates)+no_replicates) ./ C03_T_Inhibitor_spike_charges(1,no_scans*no_replicates+1:(no_scans*no_replicates)+no_replicates)) *100;
C03_T_Inhibitor_dip_charges_relative(1,1:no_replicates) = 100;
C03_T_Inhibitor_dip_charges_relative(2:no_concentrations,1:no_replicates) = (C03_T_Inhibitor_dip_charges(2:end,no_scans*no_replicates+1:(no_scans*no_replicates)+no_replicates) ./ C03_T_Inhibitor_dip_charges(1,no_scans*no_replicates+1:(no_scans*no_replicates)+no_replicates)) *100;

%Calculating % Inhibition to parameters

C03_T_Inhibitor_dark_currents_inhibition(1,1:no_replicates) = 0;
C03_T_Inhibitor_dark_currents_inhibition(2:no_concentrations,1:no_replicates) = 100 - ((C03_T_Inhibitor_dark_currents(2:end,no_scans*no_replicates+1:(no_scans*no_replicates)+no_replicates) ./ C03_T_Inhibitor_dark_currents(1,no_scans*no_replicates+1:(no_scans*no_replicates)+no_replicates)) * 100);
C03_T_Inhibitor_photocurrents_inhibition(1,1:no_replicates) = 0;
C03_T_Inhibitor_photocurrents_inhibition(2:no_concentrations,1:no_replicates) = 100 - ((C03_T_Inhibitor_photocurrents(2:end,no_scans*no_replicates+1:(no_scans*no_replicates)+no_replicates) ./ C03_T_Inhibitor_photocurrents(1,no_scans*no_replicates+1:(no_scans*no_replicates)+no_replicates)) *100);
C03_T_Inhibitor_spike_charges_inhibition(1,1:no_replicates) = 0;
C03_T_Inhibitor_spike_charges_inhibition(2:no_concentrations,1:no_replicates) = 100 - ((C03_T_Inhibitor_spike_charges(2:end,no_scans*no_replicates+1:(no_scans*no_replicates)+no_replicates) ./ C03_T_Inhibitor_spike_charges(1,no_scans*no_replicates+1:(no_scans*no_replicates)+no_replicates)) *100);
C03_T_Inhibitor_dip_charges_inhibition(1,1:no_replicates) = 0;
C03_T_Inhibitor_dip_charges_inhibition(2:no_concentrations,1:no_replicates) = 100 - ((C03_T_Inhibitor_dip_charges(2:end,no_scans*no_replicates+1:(no_scans*no_replicates)+no_replicates) ./ C03_T_Inhibitor_dip_charges(1,no_scans*no_replicates+1:(no_scans*no_replicates)+no_replicates)) *100);

%Averaging replicates and calculating errors of relative measurements

C03_T_Inhibitor_dark_currents_relative(:,no_replicates+1) = mean(C03_T_Inhibitor_dark_currents_relative(:,1:no_replicates),2);
C03_T_Inhibitor_dark_currents_relative(:,no_replicates+2) = std(C03_T_Inhibitor_dark_currents_relative(:,1:no_replicates),0,2)/error_normaliser;
C03_T_Inhibitor_photocurrents_relative(:,no_replicates+1) = mean(C03_T_Inhibitor_photocurrents_relative(:,1:no_replicates),2);
C03_T_Inhibitor_photocurrents_relative(:,no_replicates+2) = std(C03_T_Inhibitor_photocurrents_relative(:,1:no_replicates),0,2)/error_normaliser;
C03_T_Inhibitor_spike_charges_relative(:,no_replicates+1) = mean(C03_T_Inhibitor_spike_charges_relative(:,1:no_replicates),2);
C03_T_Inhibitor_spike_charges_relative(:,no_replicates+2) = std(C03_T_Inhibitor_spike_charges_relative(:,1:no_replicates),0,2)/error_normaliser;
C03_T_Inhibitor_dip_charges_relative(:,no_replicates+1) = mean(C03_T_Inhibitor_dip_charges_relative(:,1:no_replicates),2);
C03_T_Inhibitor_dip_charges_relative(:,no_replicates+2) = std(C03_T_Inhibitor_dip_charges_relative(:,1:no_replicates),0,2)/error_normaliser;

%Averaging replicates and calculating errors of inhibition measurements

C03_T_Inhibitor_dark_currents_inhibition(:,no_replicates+1) = mean(C03_T_Inhibitor_dark_currents_inhibition(:,1:no_replicates),2);
C03_T_Inhibitor_dark_currents_inhibition(:,no_replicates+2) = std(C03_T_Inhibitor_dark_currents_inhibition(:,1:no_replicates),0,2)/error_normaliser;
C03_T_Inhibitor_photocurrents_inhibition(:,no_replicates+1) = mean(C03_T_Inhibitor_photocurrents_inhibition(:,1:no_replicates),2);
C03_T_Inhibitor_photocurrents_inhibition(:,no_replicates+2) = std(C03_T_Inhibitor_photocurrents_inhibition(:,1:no_replicates),0,2)/error_normaliser;
C03_T_Inhibitor_spike_charges_inhibition(:,no_replicates+1) = mean(C03_T_Inhibitor_spike_charges_inhibition(:,1:no_replicates),2);
C03_T_Inhibitor_spike_charges_inhibition(:,no_replicates+2) = std(C03_T_Inhibitor_spike_charges_inhibition(:,1:no_replicates),0,2)/error_normaliser;
C03_T_Inhibitor_dip_charges_inhibition(:,no_replicates+1) = mean(C03_T_Inhibitor_dip_charges_inhibition(:,1:no_replicates),2);
C03_T_Inhibitor_dip_charges_inhibition(:,no_replicates+2) = std(C03_T_Inhibitor_dip_charges_inhibition(:,1:no_replicates),0,2)/error_normaliser;

%% Plotting Chronoampeormetry Curve
close all

%Plotting curves
for m = 1:no_concentrations;
    condition_names(m) = append(num2str(concentrations_uM(m))," ",chemical_units," ",chemical_name);
    
    p_C03_T_HQNO(m) = shadedErrorBar(C03_T_HQNO(:,1),C03_T_HQNO(:,(no_scans*no_replicates)+no_replicates+2,m),C03_T_HQNO(:,(no_scans*no_replicates)+no_replicates+3,m),'lineProps',{'LineWidth',2.5,'color',colors(m,:)});
    if m == no_concentrations;
        legend('AutoUpdate','off')
        leg = legend([p_C03_T_HQNO.mainLine],condition_names,'location','northeast');
        legend box off
    else
    end
    hold on
    
end

%Graph limits
max_current = ceil(max(max(C03_T_HQNO(:,(no_scans*no_replicates)+no_replicates+2,:))));
max_current_range = (ceil(max_current*10^-(numel(num2str(abs(max_current)))-1))) * 10^(numel(num2str(abs(max_current)))-1);

x_lower = 0;
x_upper = xtime(end);
y_lower = -2;
y_upper = max_current_range+5;

xlim([x_lower x_upper])
ylim([y_lower y_upper]);

%Adding annotations
onbox = area([light_on_times(1)-start_times(1) light_off_times(1)-start_times(1)],[y_upper y_upper]);
onbox.BaseValue = y_lower;
onbox.FaceColor = [1 1 1];
onbox.EdgeColor = 'none';
uistack(onbox,'bottom');
hold on

%Plot Formatting
box off
xlabel({'Time (seconds)'});
ylabel({'Photocurrent Density (nA [nmol Chl \ita\rm]^{-1} cm^{-2})'});
h = gca;
h.Color = [0.8 0.8 0.8];
h.XMinorTick = 'on';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 15;
h.LineWidth = 1;
set(h ,'Layer', 'Top');
hold off

% Scaling and saving image
pbaspect([1 1.2 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_HQNO_Curve','svg')

%% Plotting relative changes
close all

concentrations_plot = [concentrations_uM(2)/10 ; concentrations_uM(2:end)'];

% subplot(1,3,1)
p_C03_T_Inhibitor_dark_currents_relative = errorbar(concentrations_plot,C03_T_Inhibitor_dark_currents_relative(:,no_replicates+1),C03_T_Inhibitor_dark_currents_relative(:,no_replicates+2),'Color',colors(round(no_concentrations/2),:),'LineWidth',2.5);
xlabel({append("[",chemical_name,"] (",chemical_units,")")});
if normalise_chl == 1;
    ylabel({'\DeltaDark Current (nA [nmol Chl \ita\rm]^{-1} cm^{-2})'});
else
    ylabel({'\DeltaDark Current (nA cm^{-2})'});
end
box off
 
xlim([concentrations_plot(1) concentrations_plot(end)])
% ylim([0 150])    
    
pbaspect([1.5 1 1]);
set(gca,'xscale','log')
h = gca;
h.XTickLabel = concentrations_uM;
h.XTick = [logspace(log(concentrations_plot(1))/log(10),log(concentrations_plot(end))/log(10),length(concentrations_plot))];
h.XAxis.TickLength = [0.005 0.005];
h.XMinorTick = 'off';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 15;
h.LineWidth = 1;
text(concentrations_plot(1)*1.1,0,'//','Color','black','FontSize',20); %inserting break symbols
line([concentrations_plot(1)+0.00025 concentrations_plot(1)+0.00045],[0 0],'LineWidth',2,'Color','white');    
hold off

% Scaling and saving image
pbaspect([1 1.2 1]);
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_HQNO_RelativeDc','svg')

% subplot(1,3,2)
p_C03_T_Inhibitor_photocurrents_relative = errorbar(concentrations_plot,C03_T_Inhibitor_photocurrents_relative(:,no_replicates+1),C03_T_Inhibitor_photocurrents_relative(:,no_replicates+2),'Color',colors(round(no_concentrations/2),:),'LineWidth',2.5);
xlabel({append("[",chemical_name,"] (",chemical_units,")")});
if normalise_chl == 1;
    ylabel({'\DeltaPhotocurrent (%)'});
else
    ylabel({'\DeltaPhotocurrent (%)'});
end
box off
 
xlim([concentrations_plot(1) concentrations_plot(end)])
% ylim([0 150])    

pbaspect([1.5 1 1]);
set(gca,'xscale','log')

h = gca;
h.XTickLabel = concentrations_uM;
h.XTick = [logspace(log(concentrations_plot(1))/log(10),log(concentrations_plot(end))/log(10),length(concentrations_plot))];
h.XAxis.TickLength = [0.005 0.005];
h.XMinorTick = 'off';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 15;
h.LineWidth = 1;
text(concentrations_plot(1)*1.1,0,'//','Color','black','FontSize',20); %inserting break symbols
line([concentrations_plot(1)+0.00025 concentrations_plot(1)+0.00045],[0 0],'LineWidth',2,'Color','white');    
hold off

% Scaling and saving image
pbaspect([1 1.2 1]);
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_HQNO_RelativePc','svg')


% subplot(1,3,3)
p_C03_T_Inhibitor_spike_charges_relative = errorbar(concentrations_plot,C03_T_Inhibitor_spike_charges_relative(:,no_replicates+1),C03_T_Inhibitor_spike_charges_relative(:,no_replicates+2),'Color',colors(round(no_concentrations/2),:),'LineWidth',2.5);
xlabel({append("[",chemical_name,"] (",chemical_units,")")});
if normalise_chl == 1;
    ylabel({'\DeltaSpike Charge (%)'});
else
    ylabel({'\DeltaSpike Charge (%)'});
end
box off
 
xlim([concentrations_plot(1) concentrations_plot(end)])
% ylim([0 150])    
    
pbaspect([1.5 1 1]);
set(gca,'xscale','log')
h = gca;
h.XTickLabel = concentrations_uM;
h.XTick = [logspace(log(concentrations_plot(1))/log(10),log(concentrations_plot(end))/log(10),length(concentrations_plot))];
h.XAxis.TickLength = [0.005 0.005];
h.XMinorTick = 'off';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 15;
h.LineWidth = 1;
text(concentrations_plot(1)*1.1,0,'//','Color','black','FontSize',20); %inserting break symbols
line([concentrations_plot(1)+0.00025 concentrations_plot(1)+0.00045],[0 0],'LineWidth',2,'Color','white');    
hold off

% Scaling and saving image
pbaspect([1 1.2 1]);
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_HQNO_RelativeSp','svg')

% subplot(2,2,4)
p_C03_T_Inhibitor_dip_charges_relative = errorbar(concentrations_plot,C03_T_Inhibitor_dip_charges_relative(:,no_replicates+1),C03_T_Inhibitor_dip_charges_relative(:,no_replicates+2),'Color',colors(round(no_concentrations/2),:),'LineWidth',2.5);
xlabel({append("[",chemical_name,"] (",chemical_units,")")});
if normalise_chl == 1;
    ylabel({'\DeltaDip Charge (%)'});
else
    ylabel({'\DeltaDip Charge (%)'});
end
box off
 
xlim([concentrations_plot(1) concentrations_plot(end)])
% ylim([0 150])    
    
pbaspect([1.5 1 1]);
set(gca,'xscale','log')
h = gca;
h.XTickLabel = concentrations_uM;
h.XTick = [logspace(log(concentrations_plot(1))/log(10),log(concentrations_plot(end))/log(10),length(concentrations_plot))];
h.XAxis.TickLength = [0.005 0.005];
h.XMinorTick = 'off';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 15;
h.LineWidth = 1;
text(concentrations_plot(1)*1.1,0,'//','Color','black','FontSize',20); %inserting break symbols
line([concentrations_plot(1)+0.00025 concentrations_plot(1)+0.00045],[0 0],'LineWidth',2,'Color','white');    
hold off

% Scaling and saving image
pbaspect([1 1.2 1]);
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_HQNO_RelativeDi','svg')

%% Plotting inhibition changes
close all

concentrations_plot = [concentrations_uM(2)/10 ; concentrations_uM(2:end)'];

% subplot(1,3,1)
p_C03_T_Inhibitor_dark_currents_inhibition = errorbar(concentrations_plot,C03_T_Inhibitor_dark_currents_inhibition(:,no_replicates+1),C03_T_Inhibitor_dark_currents_inhibition(:,no_replicates+2),'Color',colors(round(no_concentrations/2),:),'LineWidth',2.5);
xlabel({append("[",chemical_name,"] (",chemical_units,")")});
ylabel({'Dark Current Inhibition (%)'});
box off
 
xlim([concentrations_plot(1) concentrations_plot(end)])
% ylim([0 100])    
    
pbaspect([1.5 1 1]);
set(gca,'xscale','log')
h = gca;
h.XTickLabel = concentrations_uM;
h.XTick = [logspace(log(concentrations_plot(1))/log(10),log(concentrations_plot(end))/log(10),length(concentrations_plot))];
h.XAxis.TickLength = [0.005 0.005];
h.XMinorTick = 'off';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 15;
h.LineWidth = 1;
text(concentrations_plot(1)*1.1,0,'//','Color','black','FontSize',20); %inserting break symbols
line([concentrations_plot(1)+0.0003 concentrations_plot(1)+0.00052],[0 0],'LineWidth',2,'Color','white');      
hold off

% Scaling and saving image
pbaspect([1 1.2 1]);
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_HQNO_InhibitionDc','svg')

% subplot(1,3,2)
p_C03_T_Inhibitor_photocurrents_inhibition = errorbar(concentrations_plot,C03_T_Inhibitor_photocurrents_inhibition(:,no_replicates+1),C03_T_Inhibitor_photocurrents_inhibition(:,no_replicates+2),'Color',colors(round(no_concentrations/2),:),'LineWidth',2.5);
xlabel({append("[",chemical_name,"] (",chemical_units,")")});
ylabel({'Steady State Photocurrent Inhibition (%)'});
box off 

xlim([concentrations_plot(1) concentrations_plot(end)])
% ylim([0 100])    

pbaspect([1.5 1 1]);
set(gca,'xscale','log')

h = gca;
h.XTickLabel = concentrations_uM;
h.XTick = [logspace(log(concentrations_plot(1))/log(10),log(concentrations_plot(end))/log(10),length(concentrations_plot))];
h.XAxis.TickLength = [0.005 0.005];
h.XMinorTick = 'off';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 15;
h.LineWidth = 1;
text(concentrations_plot(1)*1.1,0,'//','Color','black','FontSize',20); %inserting break symbols
line([concentrations_plot(1)+0.0003 concentrations_plot(1)+0.00052],[0 0],'LineWidth',2,'Color','white');    
hold off

% Scaling and saving image
pbaspect([1 1.2 1]);
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_HQNO_InhibitionPc','svg')


% subplot(1,3,3)
p_C03_T_Inhibitor_spike_charges_inhibition = errorbar(concentrations_plot,C03_T_Inhibitor_spike_charges_inhibition(:,no_replicates+1),C03_T_Inhibitor_spike_charges_inhibition(:,no_replicates+2),'Color',colors(round(no_concentrations/2),:),'LineWidth',2.5);
xlabel({append("[",chemical_name,"] (",chemical_units,")")});
ylabel({'Spike Charge Inhibition (%)'});
box off
 
xlim([concentrations_plot(1) concentrations_plot(end)])
 % ylim([-120 100])    
    
pbaspect([1.5 1 1]);
set(gca,'xscale','log')
h = gca;
h.XTickLabel = concentrations_uM;
h.XTick = [logspace(log(concentrations_plot(1))/log(10),log(concentrations_plot(end))/log(10),length(concentrations_plot))];
h.XAxis.TickLength = [0.005 0.005];
h.XMinorTick = 'off';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 15;
h.LineWidth = 1;
text(concentrations_plot(1)*1.1,-120,'//','Color','black','FontSize',20); %inserting break symbols
line([concentrations_plot(1)+0.0003 concentrations_plot(1)+0.00052],[-120 -120],'LineWidth',2,'Color','white');       
hold off

% Scaling and saving image
pbaspect([1 1.2 1]);
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_HQNO_InhibitionSp','svg')

% subplot(2,2,4)
p_C03_T_Inhibitor_dip_charges_inhibition = errorbar(concentrations_plot,C03_T_Inhibitor_dip_charges_inhibition(:,no_replicates+1),C03_T_Inhibitor_dip_charges_inhibition(:,no_replicates+2),'Color',colors(round(no_concentrations/2),:),'LineWidth',2.5);
xlabel({append("[",chemical_name,"] (",chemical_units,")")});
ylabel({'Dark Dip Charge Inhibition (%)'});
box off
 
xlim([concentrations_plot(1) concentrations_plot(end)])
% ylim([0 100])    
    
pbaspect([1.5 1 1]);
set(gca,'xscale','log')
h = gca;
h.XTickLabel = concentrations_uM;
h.XTick = [logspace(log(concentrations_plot(1))/log(10),log(concentrations_plot(end))/log(10),length(concentrations_plot))];
h.XAxis.TickLength = [0.005 0.005];
h.XMinorTick = 'off';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 15;
h.LineWidth = 1;
text(concentrations_plot(1)*1.1,0,'//','Color','black','FontSize',20); %inserting break symbols
line([concentrations_plot(1)+0.0003 concentrations_plot(1)+0.00052],[0 0],'LineWidth',2,'Color','white');     
hold off

% Scaling and saving image
pbaspect([1 1.2 1]);
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_HQNO_InhibitionDi','svg')
