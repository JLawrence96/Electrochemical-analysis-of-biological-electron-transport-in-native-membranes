%% TMs absorbance spectrum
%% Data Input
CV_T_Electrolyte = dlmread("CV_Electrolyte_Slow_Dark_3.ascii");
CV_T_FeCN = dlmread("CV_FeCN_Slow_1.ascii");
CV_T_HQNO = dlmread("CV_HQNO_Slow_1.ascii");

load NatureColours.mat
colors = [0.6 0.6 0.6 ; oranges(3,:) ; reds(3,:)]; %RGB numbers for each condition
normalise_chl = 0;

chl = 1;

%% Processing
if normalise_chl == 1
    chl_plug = chl
    ytitle_plug = 'Current Density (\muA [nmol Chl \ita\rm]^{-1} cm^{-2})';
else
    chl_plug = 1;
    ytitle_plug = 'Current Density (\muA cm^{-2})';
end

CV_T_Electrolyte_scan(:,1) = (CV_T_Electrolyte(:,2) .* 1000) + 200;
CV_T_Electrolyte_scan(:,2) = CV_T_Electrolyte(:,3)*10^6./chl_plug./0.75;

CV_T_FeCN_scan(:,1) = (CV_T_FeCN(:,2) .* 1000) + 200;
CV_T_FeCN_scan(:,2) = CV_T_FeCN(:,3)*10^6./chl_plug./0.75;

CV_T_HQNO_scan(:,1) = (CV_T_HQNO(:,2) .* 1000) + 200;
CV_T_HQNO_scan(:,2) = CV_T_HQNO(:,3)*10^6./chl_plug./0.75;

CV_T_FeCN_OxPeak_index = find(CV_T_FeCN_scan(:,2)==max(CV_T_FeCN_scan(:,2)));
CV_T_FeCN_RedPeak_index = find(CV_T_FeCN_scan(:,2)==min(CV_T_FeCN_scan(:,2)));
CV_T_FeCN_OxPeak = CV_T_FeCN_scan(CV_T_FeCN_OxPeak_index(round(length(CV_T_FeCN_OxPeak_index)/2)),1);
CV_T_FeCN_RedPeak = CV_T_FeCN_scan(CV_T_FeCN_RedPeak_index(round(length(CV_T_FeCN_RedPeak_index)/2)),1);
CV_T_FeCN_Em = CV_T_FeCN_RedPeak + ((CV_T_FeCN_OxPeak - CV_T_FeCN_RedPeak)./2)

%% Plotting

%Plotting curves
p_CV_T_Electrolyte = plot(CV_T_Electrolyte_scan(:,1),CV_T_Electrolyte_scan(:,2),'LineWidth',2.5,'color',colors(1,:));
hold on
p_CV_T_FeCN = plot(CV_T_FeCN_scan(:,1),CV_T_FeCN_scan(:,2),'LineWidth',2.5,'color',colors(2,:));
hold on
p_CV_T_HQNO = plot(CV_T_HQNO_scan(:,1),CV_T_HQNO_scan(:,2),'LineWidth',2.5,'color',colors(3,:));
hold on

xpos = 250;
ypos = 0.9;

%Adding legend
legend([p_CV_T_Electrolyte p_CV_T_FeCN p_CV_T_HQNO],["Electrolyte" "+1 mM Fe(CN)_{6}" "+10 \muM HQNO"],'Location','northwest');
legend box off
% t = text(xpos,ypos,append("\itE\rm_{m} = ",num2str(round(CV_T_FeCN_Em))," mV vs SHE"))
% t.FontName = 'Helvetica Ltd Std';
% t.FontSize = 15;

% Peaks_index_FeCN = [721 835 1354 1474];
% Peaks_mV_FeCN = CV_T_FeCN_scan(Peaks_index_FeCN,1)

%Graph limits
xlim([-210 810])
ylim([-50 70])

%Plot Formatting
box off
xlabel({'Potential (mV vs SHE)'});
ylabel({ytitle_plug});
h = gca;
h.Color = [1 1 1];
h.XMinorTick = 'on';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 15;
h.LineWidth = 1;
set(h ,'Layer', 'Top');
hold off

% Scaling and saving image
pbaspect([1 1.3 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'CV_T_FeCN_HQNO','svg')

