%% Stepped Chronoamperommetry Thylakoid Membranes + Soluble Fraction + Filtered Soluble Fraction

% Dependencies: shadedErrorBar.m, Minimiser_Baseliner.m, Cottrell_Solver_Baseline_SCFL
% 
%% Data Input 

% Input Parameters
no_conditions = 2; %How many conditions will be compared
no_replicates = 3; %How many biolgical replicates per condition
potentials_mV = [-600 -600:100:700]; %Potentials tested in mV, including repeat potentials. 
light_on = 90; %Time at which first light period starts
light_off = 120; %Time at which first dark period starts
time_per_potential = 150; %How many seconds per potential
sampling_rate = 0.1; %sampling reate of chronoamp data
electrode_surface_area = 0.75; %Surface area of electrode in cm^2

%Normalisation options
normalise_maxdarkcurrent = 1;
normalise_chl = 1;
std_or_se = 1; %0 for standard deviation, 1 for standard error
linear_potentials =  [2:length(potentials_mV); 2:length(potentials_mV)];
intensity = 4;
light_stabilisation_time = 25; %Point at which photocurrent reaches steady-state
dark_stabilisation_time = 20; %Point at which dark current reaches steady-state
spike_stabilisation_time = 15; %Point at which light current reaches steady state, normally 15 seconds
radius = 5000; %Radius of electrode based on spherical treatment
sampling_rate = 0.1; %scan rate 

%Plotting options
include_first_potential = 0; %should the first potential in the stepped chrono be excluded
dark_time_window = 17; %How much of the dark period should be visible in the plot
condition_names = ["TMs" "TMs + SF"];
load NatureColours.mat
colors = [ greens(3,:) ; blues(3,:)]; %RGB numbers for each condition
arrow_colors = [greens(4,:) ; yellows(4,:) ; reds(4,:) ; greens(4,:) ; browns(4,:) ; purples(4,:)];
alter_y_axis = [-0.5 -0.3]; %Will alter lower and upper bounds of graph y axis. + is extend, - contract. First position for lower and second for upper bound. 
uA_units_plot = 1; %change scale of y axis to uA rather than nA
uA_units_parameter = 0; %change scale of y axis to uA rather than nA

%Data information
directory_name = ""; %Ensure all files are stored in the same directory
file_names = ["SCFL_T_V1" "SCFL_T_W1" "SCFL_T_W2" "SCFL_TS_V2" "SCFL_TS_W1" "SCFL_TS_W2"];
file_extension = ".ascii";
chl_nM = [17.16220443 28.72499468 25.70131103 23.93749557 29.00496539 23.57353365]; %For chlorophyll normalisation. Set as an array of 1s for each dataset if no normalisation is required. 

%% Concatenating, normalising and averaging
no_potentials = length(potentials_mV); 
xtime = sampling_rate:sampling_rate:no_potentials*time_per_potential;
SCFL_T_TS = zeros(length(xtime),(2*no_replicates)+3,no_conditions);

%Normalsising to chlorophyll and surface area
if normalise_chl == 0;
    chl_nM = ones(1,length(chl_nM));
else
end

for h = 1:no_conditions;
    SCFL_T_TS(:,1,h) = xtime;
    for i = 1:no_replicates;
        input = dlmread(append(directory_name,file_names((h*no_replicates)-no_replicates+i),file_extension));
        SCFL_T_TS(:,i+1,h) = ((input(1:length(xtime),2) *10^9 /(uA_units_plot*10^3)) /electrode_surface_area) / chl_nM(((h-1)*no_replicates)+i);
        clear input
    end
end

%Normalising to maximum dark current
spacing_time = light_off-light_on;

if normalise_maxdarkcurrent == 1;
    j = light_on;
    while j < xtime(end)+light_on;   
        current_range = ((j-dark_time_window)/sampling_rate):((j+dark_time_window+spacing_time)/sampling_rate);
        max_dark_current_mean = mean(SCFL_T_TS(current_range(length(current_range)),2:1+no_replicates,:)); %Calculates the largest final current value recorded across each replicate   
        diff_dark_current = max_dark_current_mean(:,:,:) - SCFL_T_TS(((j+dark_time_window+spacing_time)/sampling_rate),2:1+no_replicates,:);
        SCFL_T_TS(current_range,2+no_replicates:1+(2*no_replicates),:) = SCFL_T_TS(current_range,2:1+no_replicates,:) + diff_dark_current(:,:,:);
        j = j + 150;   
    end
else
end

% Mean and error calculation


    
for h = 1:no_conditions;
  
    if std_or_se == 0;  
        error_normaliser = 1;
    else
        error_normaliser = sqrt(no_replicates); 
    end
 

    SCFL_T_TS(:,2+(2*no_replicates),:) = mean(SCFL_T_TS(:,1+no_replicates+[1:no_replicates],:),2);
    SCFL_T_TS(:,3+(2*no_replicates),:) = std(SCFL_T_TS(:,1+no_replicates+[1:no_replicates],:),0,2)/error_normaliser;
    
end

%% Plotting and formatting stepped chronoamperometry plot

close all 

% Seperates scans at each applied potential into a seperate dataset
k = 0;
l = 1;
while k < xtime(end);   
    current_range = ((k+light_on-dark_time_window)/sampling_rate):((k+light_off+dark_time_window)/sampling_rate); %values to plot
    xc_T_TS(:,l,:) = SCFL_T_TS(current_range,1,:); %time
    yc_T_TS(:,l,:) = SCFL_T_TS(current_range,2+(2*no_replicates),:); %current (mean)
    eyc_T_TS(:,l,:) = SCFL_T_TS(current_range,3+(2*no_replicates),:); %current (std)
    bounds(:,l) = [k k+light_on-dark_time_window]; %Axis break bounds
    k = k + time_per_potential;   
    l = l + 1;   
  end

% Plotting scans
for m = 1:no_conditions;
    for n = 1:1:width(xc_T_TS);
        shift = n*range(bounds(:,n,:)); 
        xc_T_TS_altered(:,n,m) = xc_T_TS(:,n,m) - (xc_T_TS(:,n,m) >= bounds(2,n,:))*shift; %altering x axis to cutout dark current
        p_SCFL_T_TS(m,n) = shadedErrorBar(xc_T_TS_altered(:,n,m),yc_T_TS(:,n,m),eyc_T_TS(:,n,m),'lineProps',{'LineWidth',3.5,'color',colors(m,:)}); %plotting curve 
        hold on
    end
end

% Scaling x and y axis
min_current = floor(min(min(SCFL_T_TS(:,end-1,:))));
min_current_range = (floor(min_current*10^-(numel(num2str(abs(min_current)))-1))) * 10^(numel(num2str(abs(min_current)))-1);
max_current = ceil(max(max(SCFL_T_TS(:,end-1,:))));
max_current_range = (ceil(max_current*10^-(numel(num2str(abs(max_current)))-1))) * 10^(numel(num2str(abs(max_current)))-1);

x_spacing = (xc_T_TS_altered(1,2,1) - xc_T_TS_altered(end,1,1))/2;
x_lower = xc_T_TS_altered(1,2-include_first_potential,1)-x_spacing;
x_upper= xc_T_TS_altered(end,end,1)+x_spacing;
y_lower = min_current_range-alter_y_axis(1);
y_upper = max_current_range+alter_y_axis(2);

xlim([x_lower x_upper]);
ylim([y_lower y_upper]);
xtics = x_lower+x_spacing:dark_time_window:x_upper-x_spacing;
 
% General formatting
box off
xlabel({' ','Time (s)'});

if uA_units_plot == 0; %change scale of y axis to uA rather than nA
    ylabel({'Current Density (nA [nmol Chl \ita\rm]^{-1} cm^{-2})'});
else
    ylabel({'Current Density (\muA [nmol Chl \ita\rm]^{-1} cm^{-2})'});
end

h = gca;
h.Color = [0.8 0.8 0.8];
h.XTick = [xtics];
h.XTickLabel = [];
h.XAxis.TickLength = [0.005 0.005];
h.XMinorTick = 'off';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1;

%Adding annotations
for o = 2-include_first_potential:1:width(xc_T_TS); 
    
    qx1 = xc_T_TS_altered(1,o,1)+dark_time_window;
    qx2 = xc_T_TS_altered(end,o,1)-dark_time_window;
    qx3 = qx1+((qx2-qx1)/2);
    qy = y_lower-((y_upper-y_lower)/22);

    onbox = area([qx1 qx2],[y_upper y_upper]); %inserting light boxes
    onbox.BaseValue = y_lower-1000;
    onbox.FaceColor = [1 1 1];
    onbox.EdgeColor = 'none';
    uistack(onbox,'bottom');
    
    if potentials_mV(o) <= 0;
        text(qx3,qy,append(num2str(potentials_mV(o))," mV"),'HorizontalAlignment','Center','FontName','Helvetica Ltd Std','FontSize',17)
    else; 
        text(qx3,qy,append("+",num2str(potentials_mV(o))," mV"),'HorizontalAlignment','Center','FontName','Helvetica Ltd Std','FontSize',17)
    end

    hold on

end;

line([x_lower x_upper],[y_lower y_lower],'LineWidth',1.5,'Color','black'); 
for p = 2-include_first_potential:1:width(xc_T_TS)-1; 
    text(xc_T_TS_altered(end,p,1)+(0.5*x_spacing),min_current_range-alter_y_axis(1),'//','Color','black','FontSize',20); %inserting break symbols
    line([xc_T_TS_altered(end,p,1)+(0.9*x_spacing)  xc_T_TS_altered(end,p,1)+(1.3*x_spacing)],[min_current_range-alter_y_axis(1) min_current_range-alter_y_axis(1)],'LineWidth',2,'Color','white'); 
end
hold on

annotation("textbox",[0.1265 1 0.4 0.01],'String','Expected Onset Potential:','FontName','Helvetica Ltd Std','FontSize',17,'FontWeight','bold','EdgeColor','white');
annotation("textarrow",[0.148 0.904],[0.895 0.895],'String','PSI','FontName','Helvetica Ltd Std','FontSize',17,'FontWeight','bold','LineWidth',1.5,'Color',arrow_colors(1,:));
% annotation("textarrow",[0.248 0.904],[0.895 0.895],'String','Fd','FontName','Helvetica Ltd Std','FontSize',17,'FontWeight','bold','LineWidth',1.5,'Color',arrow_colors(2,:));
annotation("textarrow",[0.424 0.904],[0.917 0.917],'String','Cyt \itb\bf_{6}\itf','FontName','Helvetica Ltd Std','FontSize',17,'FontWeight','bold','LineWidth',1.5,'Color',arrow_colors(3,:));
annotation("textarrow",[0.472 0.904],[0.939 0.939],'String','PSII','FontName','Helvetica Ltd Std','FontSize',17,'FontWeight','bold','LineWidth',1.5,'Color',arrow_colors(4,:));
annotation("textarrow",[0.525 0.904],[0.984 0.984],'String','SF','FontName','Helvetica Ltd Std','FontSize',17,'FontWeight','bold','LineWidth',1.5,'Color',arrow_colors(6,:));
annotation("textarrow",[0.525 0.904],[0.961 0.961],'String','PQ','FontName','Helvetica Ltd Std','FontSize',17,'FontWeight','bold','LineWidth',1.5,'Color',arrow_colors(5,:));

%Adding legend
legend([p_SCFL_T_TS(:).mainLine],condition_names,'location','northwest');
legend box off

% Scaling and saving image
pbaspect([4 1.4 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [0, 0, 2150, 800])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'SCFL_T_TS_Curve_','svg')


%% Calculating photocurrents, dark currents and spike charges
close all

for s = 1:no_conditions
    for t = 1:no_replicates
        
        tinput = SCFL_T_TS(:,1,s); %time data 
        Iinput = SCFL_T_TS(:,t+1,s); %current data
        
        chl = chl_nM((s*no_replicates)-no_replicates+t); %chlorophyll concentration in any unit used
            
        u = 1;
        
        for v = 2-include_first_potential:1:no_potentials;
        
            if ismember(v,linear_potentials(s,:)) == 1
                linear_baseline = 1;
            else
                linear_baseline = 0;
            end

            start_time = 85 +(time_per_potential*(v-1));
            light_on = 90 + (time_per_potential*(v-1));
            light_off = 120 + (time_per_potential*(v-1));
            end_time = 149.5 + (time_per_potential*(v-1));
            spacing_time = end_time-start_time;
            
            Cottrell_Solver_Baseliner_SCF

            SCFL_T_TS_dark_currents(u,t,s) = dark_current;
            SCFL_T_TS_photocurrents(u,t,s) = photocurrent;
            SCFL_T_TS_spike_charges(u,t,s) = spike_charge;
            SCFL_T_TS_dip_charges(u,t,s) = dip_charge;
            
            u = u + 1;
        end
    end
end

% Mean and error calculation

for h = 1:no_conditions;
   
    if std_or_se == 0;  
        error_normaliser = 1;
    else
        error_normaliser = sqrt(no_replicates); 
    end
 

    SCFL_T_TS_dark_currents(:,no_replicates+1,h) = mean(SCFL_T_TS_dark_currents(:,1:no_replicates,h),2); %dark currents in nA
    SCFL_T_TS_dark_currents(:,no_replicates+2,h) = std(SCFL_T_TS_dark_currents(:,1:no_replicates,h),0,2)/error_normaliser;
    SCFL_T_TS_photocurrents(:,no_replicates+1,h) = mean(SCFL_T_TS_photocurrents(:,1:no_replicates,h),2); %photocurrents in nA
    SCFL_T_TS_photocurrents(:,no_replicates+2,h) = std(SCFL_T_TS_photocurrents(:,1:no_replicates,h),0,2)/error_normaliser;
    SCFL_T_TS_spike_charges(:,no_replicates+1,h) = mean(SCFL_T_TS_spike_charges(:,1:no_replicates,h)/1000,2); %spike charges in uQ
    SCFL_T_TS_spike_charges(:,no_replicates+2,h) = std(SCFL_T_TS_spike_charges(:,1:no_replicates,h)/1000,0,2)/error_normaliser;
    SCFL_T_TS_dip_charges(:,no_replicates+1,h) = mean(SCFL_T_TS_dip_charges(:,1:no_replicates,h)/1000,2); %dip charges in uQ
    SCFL_T_TS_dip_charges(:,no_replicates+2,h) = std(SCFL_T_TS_dip_charges(:,1:no_replicates,h)/1000,0,2)/error_normaliser;
    
end

%% Plotting photocurrent parameters

close all

x_spacing = potentials_mV(end)-potentials_mV(end-1);
x_lower = potentials_mV(1)-(x_spacing/10);
x_upper = potentials_mV(end)+(x_spacing/10);

for w = 1:no_conditions;
    
    % subplot(2,2,1)
    p_SCFL_T_TS_dark_currents(w) = errorbar(potentials_mV(2-include_first_potential:end),SCFL_T_TS_dark_currents(:,no_replicates+1,w)*10^3,SCFL_T_TS_dark_currents(:,no_replicates+2,w)*10^3,'Color',colors(w,:),'LineWidth',2.5);
    % if w == 3;
    %     legend([p_SCFL_T_TS_dark_currents(4) p_SCFL_T_TS_dark_currents(3) p_SCFL_T_TS_dark_currents(2) p_SCFL_T_TS_dark_currents(1)],condition_names,'location','northwest');
    %     legend box off
    % else
    % end
    xlabel({'Potential (mV vs SHE)'});
    if normalise_chl == 1;
        ylabel({'Dark Current Density',' (nA [nmol Chl \ita\rm]^{-1} cm^{-2})'});
    else
        ylabel({'Dark Current Density',' (nA cm^{-2})'});
    end
    box off
    xlim([x_lower x_upper]);
    h = gca;
    set(get(gca(),'XAxis'),'MinorTickValues',potentials_mV(2-include_first_potential:end))
    h.XAxis.TickLength = [0.01 0.01];
    h.XMinorTick = 'on';
    h.YMinorTick = 'on';
    h.TickDir = 'out';
    h.FontName = 'Helvetica Ltd Std';
    h.FontSize = 17;
    h.LineWidth = 1;
    hold on

end

% Scaling and saving image
pbaspect([1 1.3 1]);
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'SCFL_T_TS_Dc','svg')

hold off 

for w = 1:no_conditions;
    
    % subplot(2,2,2)
    p_SCFL_T_TS_photocurrents(w) = errorbar(potentials_mV(2-include_first_potential:end),SCFL_T_TS_photocurrents(:,no_replicates+1,w)*10^3,SCFL_T_TS_photocurrents(:,no_replicates+2,w)*10^3,'Color',colors(w,:),'LineWidth',2.5);
    if w == no_conditions;
        legend([p_SCFL_T_TS_photocurrents],condition_names,'location','northwest');
        legend box off
    else
    end
    xlabel({'Potential (mV vs SHE)'});
    if normalise_chl == 1;
        ylabel({'Steady State Photocurrent (nA [nmol Chl \ita\rm]^{-1} cm^{-2})'});
    else
        ylabel({'Steady State Photocurrent (nA cm^{-2})'});
    end
    box off
    xlim([x_lower x_upper]);
    ylim([0 35]);
    h = gca;
    set(get(gca(),'XAxis'),'MinorTickValues',potentials_mV(2-include_first_potential:end))
    h.XAxis.TickLength = [0.01 0.01];
    h.XMinorTick = 'on';
    h.YMinorTick = 'on';
    h.TickDir = 'out';
    h.FontName = 'Helvetica Ltd Std';
    h.FontSize = 17;
    h.LineWidth = 1;
    ytickformat('%.1f')
    hold on

end

% Scaling and saving image
pbaspect([1 1.3 1]);
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'SCFL_T_TS_Pc','svg')

hold off

for w = 1:no_conditions;

    % subplot(2,2,3)
    p_SCFL_T_TS_spike_charges(w) = errorbar(potentials_mV(2-include_first_potential:end),SCFL_T_TS_spike_charges(:,no_replicates+1,w)*10^3,SCFL_T_TS_spike_charges(:,no_replicates+2,w)*10^3,'Color',colors(w,:),'LineWidth',2.5);
    % if w == 3;
    %     legend([p_SCFL_T_TS_spike_charges(4) p_SCFL_T_TS_spike_charges(3) p_SCFL_T_TS_spike_charges(2) p_SCFL_T_TS_spike_charges(1)],condition_names,'location','northeast');
    %     legend box off
    % else
    % end
    xlabel({'Potential (mV vs SHE)'});
    if normalise_chl == 1;
        ylabel({'Spike Charge (\muC [nmol Chl \ita\rm]^{-1} cm^{-2})'});
    else
        ylabel({'Spike Charge (\muC cm^{-2})'});
    end
    box off
    xlim([x_lower x_upper]);
    pbaspect([1.5 1 1]);
    h = gca;
    set(get(gca(),'XAxis'),'MinorTickValues',potentials_mV(2-include_first_potential:end))
    h.XAxis.TickLength = [0.01 0.01];
    h.XMinorTick = 'on';
    h.YMinorTick = 'on';
    h.TickDir = 'out';
    h.FontName = 'Helvetica Ltd Std';
    h.FontSize = 17;
    h.LineWidth = 1;
    ytickformat('%.2f')
    hold on

end

% Scaling and saving image
pbaspect([1 1.3 1]);
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'SCFL_T_TS_Sp','svg')

hold off

for w = 1:no_conditions;

    % subplot(2,2,4)
    p_SCFL_T_TS_dip_charges(w) = errorbar(potentials_mV(2-include_first_potential:end),SCFL_T_TS_dip_charges(:,no_replicates+1,w)*10^3,SCFL_T_TS_dip_charges(:,no_replicates+2,w)*10^3,'Color',colors(w,:),'LineWidth',2.5);
%     if w == 3;
%     legend([p_SCFL_T_TS_dip_charges(4) p_SCFL_T_TS_dip_charges(3) p_SCFL_T_TS_dip_charges(2) p_SCFL_T_TS_dip_charges(1)],condition_names,'location','northwest');
%         legend box off
%     else
%     end
    xlabel({'Potential (mV vs SHE)'});
    if normalise_chl == 1;
        ylabel({'Dip Charge Density',' (\muC [nmol Chl \ita\rm]^{-1} cm^{-2})'});
    else
        ylabel({'Dip Charge Density',' (\muC cm^{-2})'});
    end
    box off
    xlim([x_lower x_upper]);
    h = gca;
    set(get(gca(),'XAxis'),'MinorTickValues',potentials_mV(2-include_first_potential:end))
    h.XAxis.TickLength = [0.01 0.01];
    h.XMinorTick = 'on';
    h.YMinorTick = 'on';
    h.TickDir = 'out';
    h.FontName = 'Helvetica Ltd Std';
    h.FontSize = 17;
    h.LineWidth = 1;
    ytickformat('%.2f')
    hold on

end

% Scaling and saving image
pbaspect([1 1.3 1]);
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'SCFL_T_TS_Di','svg')
