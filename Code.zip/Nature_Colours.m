reds_hex = ["#F9C9C7" "#EA9A9D" "#D95D5B" "#C23637" "#912322" "#681714"];
blues_hex = ["#C1E4FA" "#92C4E9" "#4D8FCB" "#0067A9" "#004586" "#002752"];
yellows_hex = ["#FFEFBB" "#F5D77F" "#E8C047" "#C59527" "#926C17" "#604B14"];
olives_hex = ["#F2EFAA" "#DBD75C" "#C2BF02" "#909A15" "#5B6C1C" "#2F3D19"];
greens_hex = ["#D4E4BF" "#96C36E" "#57AA3E" "#3D892E" "#1F662A" "#153319"];
teals_hex = ["#C5E3EB" "#8CCCCE" "#42B4B5" "#018F99" "#005D6E" "#003245"];
oranges_hex = ["#FDDBB5" "#FBB874" "#F48F3D" "#EB6302" "#AE450B" "#792C02"];
purples_hex = ["#E8D0E6" "#CDA0CB" "#B271AB" "#9E4589" "#6E2769" "#3F1847"];
browns_hex = ["#F7E2D1" "#D8B599" "#B78E72" "#885F4D" "#6A4638" "#3C281D"];

reds = hex2rgb(reds_hex);
blues = hex2rgb(blues_hex);
yellows = hex2rgb(yellows_hex);
olives = hex2rgb(olives_hex);
greens = hex2rgb(greens_hex);
teals = hex2rgb(teals_hex);
oranges = hex2rgb(oranges_hex);
purples = hex2rgb(purples_hex);
browns = hex2rgb(browns_hex);

save("NatureColours.mat","reds","blues","yellows","olives","greens","teals","oranges","purples","browns")