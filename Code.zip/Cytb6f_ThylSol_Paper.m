%% Correlated JTS Cytb measurements JTS thylakoids + 100 uM DCMU +/- 1 mM NADPH
% Dependencies: shadedErrorBar.m, Minimiser_Baseliner.m,Cottrell_Solver_Baseline_C

%% Data Input 

% Input Parameters
no_conditions = 2; %How many conditions
no_replicates = 3; %How many biolgical replicates per condition
no_lightintensities = 8; %How many light intensities
lightintensities_uE = [10 25 50 100 250 500 750 1000]; %Potentials tested in mV, including repeat potentials.

% Fitting Conditions for Chronoamperometry
start_times = [125.05 245.005 364.86 484.815 604.371 722.927 842.583 962.238]; %Start time of first scan, first at 9.989
light_on_times = [130.043 249.997 369.851 489.606 609.361 727.922 847.577 967.232]; %Time at which first, second and third light period starts
light_off_times = [190.07 309.925 429.78 549.335 669.191 907.303 787.747 1026.96]; %Time at which first dark period starts
end_times = [250.096 369.254 489.606 609.361 728.22 847.577 967.232 1086.89]; %End time of first scan
linear_baselines = [1 1 1 1]; %0 = fits dark current with cottrel equation, 1 = fits dark current with straight line.
experiment_time = 120; %Length of light period and dark period combined
light_time = 60; %time of light period
preequilibration_time = 5; %Number of seconds prior to first light which are used for baselining
light_stabilisation_time = 30; %Point at which dark absorbance reaches steady-state 
dark_stabilisation_time = 55; %Point at which dark absorbance reaches steady-state 
DIRK_time = 7; %Region over which DIRK measurement is made
sampling_rate = 0.1; %sampling reate of JTS data

%Normalisation options
std_or_se = 1; %0 for standard deviation, 1 for standard error

%Plotting options
load NatureColours.mat
colors = [greens(3,:) ; blues(3,:)];
colors_intensities = [createcolormap(no_lightintensities, greens(1,:), greens(3,:), greens(6,:)) ; createcolormap(no_lightintensities, blues(1,:), blues(3,:), blues(6,:))]; %Select colours to use. Number of colours should equal number of concentrations
plot_names = ["" "DCMU"];
condition_names = ["TMs" "+100 \muM DCMU"];
alter_y_axis = [0.8 0 ; 0.8 0 ; 1.2 0 ; 1.2 0 ; 0 0 ; 0 0]; %Will alter lower and upper bounds of graph y axis. + is extend, - contract. First position for lower and second for upper bound. 

%Data information
directory_name = ""; %Ensure all files are stored in the same directory
file_names = ["Cyt_JTS_ThylSol+FCN_ND1" "Cyt_JTS_ThylSol+FCN_ND2" "Cyt_JTS_ThylSol+FCN_ND3" ; "Cyt_JTS_ThylSol+FCN+DCMU_ND1" "Cyt_JTS_ThylSol+FCN+DCMU_ND2" "Cyt_JTS_ThylSol+FCN+DCMU_ND3"];
file_extension = ".ascii";


%% Processing 546nm data
for i = 1:no_conditions; 
    for j = 1:no_replicates;   
    
            input = dlmread(append(directory_name,file_names(i,j),file_extension));
            tinput = input(:,1);
            Iinput = input(:,2)*10^3;
            experiment_time = experiment_time;
            light_time = light_time;
            preequilibration_time = preequilibration_time;
            sampling_rate = sampling_rate;
            dark_stabilisation_time = dark_stabilisation_time;
            
        for k = 1:no_lightintensities;
            
            start_time = start_times(k); 
            light_on = light_on_times(k);
            light_off = light_off_times(k);
            end_time = end_times(k);

            Linear_Baseliner_JTS %Calls baselining function
            
            A546_ThylSol{i}(:,1,k) = tplot;
            A546_ThylSol{i}(:,j+1,k) =  Iplot_baseline_corrected;

        end
    end
end

%% Processing 554nm data
for i = 1:no_conditions; 
    for j = 1:no_replicates;   
    
            input = dlmread(append(directory_name,file_names(i,j),file_extension));
            tinput = input(:,1);
            Iinput = input(:,3)*10^3;
            experiment_time = experiment_time;
            light_time = light_time;
            preequilibration_time = preequilibration_time;
            sampling_rate = sampling_rate;
            dark_stabilisation_time = dark_stabilisation_time;
            
        for k = 1:no_lightintensities;
            
            start_time = start_times(k); 
            light_on = light_on_times(k);
            light_off = light_off_times(k);
            end_time = end_times(k);

            Linear_Baseliner_JTS %Calls baselining function
            
            A554_ThylSol{i}(:,1,k) = tplot;
            A554_ThylSol{i}(:,j+1,k) =  Iplot_baseline_corrected;

        end
    end
end

%% Processing 563nm data
for i = 1:no_conditions; 
    for j = 1:no_replicates;   
    
            input = dlmread(append(directory_name,file_names(i,j),file_extension));
            tinput = input(:,1);
            Iinput = input(:,4)*10^3;
            experiment_time = experiment_time;
            light_time = light_time;
            preequilibration_time = preequilibration_time;
            sampling_rate = sampling_rate;
            dark_stabilisation_time = dark_stabilisation_time;
            
        for k = 1:no_lightintensities;
            
            start_time = start_times(k); 
            light_on = light_on_times(k);
            light_off = light_off_times(k);
            end_time = end_times(k);

            Linear_Baseliner_JTS %Calls baselining function
            
            A563_ThylSol{i}(:,1,k) = tplot;
            A563_ThylSol{i}(:,j+1,k) =  Iplot_baseline_corrected;

        end
    end
end

%% Processing 574nm data
for i = 1:no_conditions; 
    for j = 1:no_replicates;   
    
            input = dlmread(append(directory_name,file_names(i,j),file_extension));
            tinput = input(:,1);
            Iinput = input(:,5)*10^3;
            experiment_time = experiment_time;
            light_time = light_time;
            preequilibration_time = preequilibration_time;
            sampling_rate = sampling_rate;
            dark_stabilisation_time = dark_stabilisation_time;
            
        for k = 1:no_lightintensities;
            
            start_time = start_times(k); 
            light_on = light_on_times(k);
            light_off = light_off_times(k);
            end_time = end_times(k);

            Linear_Baseliner_JTS %Calls baselining function
            
            A574_ThylSol{i}(:,1,k) = tplot;
            A574_ThylSol{i}(:,j+1,k) =  Iplot_baseline_corrected;

        end
    end
end

%% Calculating parameters

for i = 1:no_conditions;
    
    Cytb_ThylSol{i} = zeros(length(A546_ThylSol{i}),no_replicates+1,no_lightintensities);
    Cytb_ThylSol{i}(:,1,:) = A546_ThylSol{i}(:,1,:); 
    Cytb_ThylSol{i}(:,2:end,:) = A563_ThylSol{i}(:,2:end,:) - (0.607 .* A574_ThylSol{i}(:,2:end,:)) + (0.393 .* A546_ThylSol{i}(:,2:end,:)); 
    
    Cytf_ThylSol{i} = zeros(length(A546_ThylSol{i}),no_replicates+1,no_lightintensities);
    Cytf_ThylSol{i}(:,1,:) = A546_ThylSol{i}(:,1,:); 
    Cytf_ThylSol{i}(:,2:end,:) = A554_ThylSol{i}(:,2:end,:) - (0.607 .* A574_ThylSol{i}(:,2:end,:)) + (0.393 .* A546_ThylSol{i}(:,2:end,:)); 
    
    for j = 1:no_replicates;
        for k = 1:no_lightintensities;

            Cytb_ThylSol_MaxAbs(k,j,i) = abs(mean(Cytb_ThylSol{i}((preequilibration_time+light_stabilisation_time)/sampling_rate:(preequilibration_time+light_time)/sampling_rate,j+1,k)));
            Cytf_ThylSol_MaxAbs(k,j,i) = abs(mean(Cytf_ThylSol{i}((preequilibration_time+light_stabilisation_time)/sampling_rate:(preequilibration_time+light_time)/sampling_rate,j+1,k)));
        
        end
    end
end

%% Averaging

if std_or_se == 0;
    error_normaliser = 1;
else
    error_normaliser = sqrt(no_replicates);
end

%Averaging Scans for PAM
for i = 1:no_conditions
    for l = 1:no_replicates;

        Cytb_ThylSol{i}(:,no_replicates+2,:) = mean(Cytb_ThylSol{i}(:,2:no_replicates+1,:),2);
        Cytb_ThylSol_MaxAbs(:,no_replicates+1,i) = mean(Cytb_ThylSol_MaxAbs(:,1:no_replicates,i),2);
        Cytf_ThylSol{i}(:,no_replicates+2,:) = mean(Cytf_ThylSol{i}(:,2:no_replicates+1,:),2);
        Cytf_ThylSol_MaxAbs(:,no_replicates+1,i) = mean(Cytf_ThylSol_MaxAbs(:,1:no_replicates,i),2);

        Cytb_ThylSol{i}(:,no_replicates+3,:) = std(Cytb_ThylSol{i}(:,2:no_replicates+1,:),0,2)./error_normaliser;
        Cytb_ThylSol_MaxAbs(:,no_replicates+2,i) = std(Cytb_ThylSol_MaxAbs(:,1:no_replicates,i),0,2)./error_normaliser;
        Cytf_ThylSol{i}(:,no_replicates+3,:) = std(Cytf_ThylSol{i}(:,2:no_replicates+1,:),0,2)./error_normaliser;
        Cytf_ThylSol_MaxAbs(:,no_replicates+2,i) = std(Cytf_ThylSol_MaxAbs(:,1:no_replicates,i),0,2)./error_normaliser;
    end
end


%% Plotting Cytb Curve
close all

%Plotting curves
for n = 1:no_conditions
    for m = 1:no_lightintensities;
        intensity_names(m) = append(num2str(lightintensities_uE(m))," \muE m^{-2} s^{-1}");
    
        p_Cytb_ThylSol(n,m) = shadedErrorBar(Cytb_ThylSol{n}(:,1,1),Cytb_ThylSol{n}(:,no_replicates+2,m),Cytb_ThylSol{n}(:,no_replicates+3,m),'lineProps',{'LineWidth',2.5,'color',colors_intensities(((n-1)*no_lightintensities)+m,:)});
        if m == no_conditions;

        else
        end
        hold on
    
    end

    % legend('AutoUpdate','off')
    % legend([p_Cytb_ThylSol(n,1:end).mainLine],intensity_names,'location','northwest');
    % legend box off
    
    %Graph limits
    max_abs = max(max(Cytb_ThylSol{n}(:,no_replicates+2,:)));
    max_abs_range = round(max_abs,1,'significant');

    x_lower = 0;
    x_upper = tplot(end);
    y_lower = 0-alter_y_axis(n,1);
    y_upper = max_abs_range+alter_y_axis(n,2);
    xlim([x_lower x_upper])
     ylim([y_lower y_upper]);

    %Adding annotations
    onbox1 = area([5 65],[y_upper y_upper]);
    onbox1.BaseValue = y_lower;
    onbox1.FaceColor = [1 1 1];
    onbox1.EdgeColor = 'none';
    uistack(onbox1,'bottom');
    hold on

    %Plot Formatting
    box off
    xlabel({'Time (seconds)'});
    ylabel({'Cyt \itb\rm Redox Changes (\DeltaI/Ix10^{3})'});
    h = gca;
    h.Color = [0.8 0.8 0.8];
    h.XMinorTick = 'on';
    h.YMinorTick = 'on';
    h.TickDir = 'out';
    h.FontName = 'Helvetica Ltd Std';
    h.FontSize = 17;
    h.LineWidth = 1;
    set(h ,'Layer', 'Top');
    hold off

    % Scaling and saving image
    pbaspect([1 1.3 1]);
    set(gcf, 'Renderer', 'painter');
    set(gcf,'color','w');
    set(gcf, 'Position',  [100, 100, 500, 600])
    set(gcf, 'InvertHardCopy', 'off');
    saveas(gcf,append('Cytb_ThylSol_Curve_',plot_names(n)),'svg')
    
    close all

end

%% Plotting Cytf Curve
close all

%Plotting curves
for n = 1:no_conditions
    for m = 1:no_lightintensities;
        intensity_names(m) = append(num2str(lightintensities_uE(m))," \muE m^{-2} s^{-1}");
    
        p_Cytf_ThylSol(n,m) = shadedErrorBar(Cytf_ThylSol{n}(:,1,1),Cytf_ThylSol{n}(:,no_replicates+2,m),Cytf_ThylSol{n}(:,no_replicates+3,m),'lineProps',{'LineWidth',2.5,'color',colors_intensities(((n-1)*no_lightintensities)+m,:)});
        if m == no_conditions;

        else
        end
        hold on
    
    end

    % legend('AutoUpdate','off')
    % legend([p_Cytf_ThylSol(n,1:end).mainLine],intensity_names,'location','northwest');
    % legend box off
    
    %Graph limits
    max_abs = max(max(Cytf_ThylSol{n}(:,no_replicates+2,:)));
    max_abs_range = round(max_abs,1,'significant');

    x_lower = 0;
    x_upper = tplot(end);
    y_lower = 0-alter_y_axis(n+no_conditions,1);
    y_upper = max_abs_range+alter_y_axis(n+no_conditions,2);
    xlim([x_lower x_upper])
    ylim([y_lower y_upper]);

    %Adding annotations
    onbox1 = area([5 65],[y_upper y_upper]);
    onbox1.BaseValue = y_lower;
    onbox1.FaceColor = [1 1 1];
    onbox1.EdgeColor = 'none';
    uistack(onbox1,'bottom');
    hold on

    %Plot Formatting
    box off
    xlabel({'Time (seconds)'});
    ylabel({'Cyt \itf\rm Redox Changes (\DeltaI/Ix10^{3})'});
    h = gca;
    h.Color = [0.8 0.8 0.8];
    h.XMinorTick = 'on';
    h.YMinorTick = 'on';
    h.TickDir = 'out';
    h.FontName = 'Helvetica Ltd Std';
    h.FontSize = 17;
    h.LineWidth = 1;
    set(h ,'Layer', 'Top');
    hold off

    % Scaling and saving image
    pbaspect([1 1.3 1]);
    set(gcf, 'Renderer', 'painter');
    set(gcf,'color','w');
    set(gcf, 'Position',  [100, 100, 500, 600])
    set(gcf, 'InvertHardCopy', 'off');
    saveas(gcf,append('Cytf_ThylSol_Curve_',plot_names(n)),'svg')
    
    close all

end


%% Plotting Absolute Cytb Parameters
close all

for i = 1: no_conditions;
    
    p_Cytb_ThylSol_MaxAbs(i) = errorbar(lightintensities_uE,Cytb_ThylSol_MaxAbs(:,no_replicates+1,i),Cytb_ThylSol_MaxAbs(:,no_replicates+2,i),'Color',colors(i,:),'LineWidth',3);
    hold on

end

legend([p_Cytb_ThylSol_MaxAbs],condition_names,'location','southeast');
legend box off

xlabel({'Light Intensity (\mumol photons m^{-2} s^{-1})'});
ylabel({'Steady State Cyt \itb\rm Oxidation (\DeltaI/Ix10^{3})'});
box off

xlim([lightintensities_uE(1) lightintensities_uE(end)])
    
pbaspect([1 1 1]);
h = gca;
h.XAxis.TickLength = [0.005 0.005];
h.XMinorTick = 'off';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize= 17;
h.LineWidth = 1;
hold on

% Scaling and saving image

pbaspect([1 1.3 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'Cytb_ThylSol_MaxAbs','svg')

%% Plotting Absolute Cytf Parameters
close all

for i = 1: no_conditions;
    
    p_Cytf_ThylSol_MaxAbs(i) = errorbar(lightintensities_uE,Cytf_ThylSol_MaxAbs(:,no_replicates+1,i),Cytf_ThylSol_MaxAbs(:,no_replicates+2,i),'Color',colors(i,:),'LineWidth',3);
    hold on

end

% legend([p_Cytf_ThylSol_MaxAbs],condition_names,'location','northeast');
% legend box off

xlabel({'Light Intensity (\mumol photons m^{-2} s^{-1})'});
ylabel({'Steady State Cyt \itf\rm Oxidation (\DeltaI/Ix10^{3})'});
box off

xlim([lightintensities_uE(1) lightintensities_uE(end)])
    
pbaspect([1 1 1]);
h = gca;
h.XAxis.TickLength = [0.005 0.005];
h.XMinorTick = 'off';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize= 17;
h.LineWidth = 1;
hold on

% Scaling and saving image

pbaspect([1 1.3 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'Cytf_ThylSol_MaxAbs','svg')
