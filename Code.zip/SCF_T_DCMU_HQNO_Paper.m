%% Stepped Chronoamperommetry Thylakoid Membranes + Soluble Fraction + Filtered Soluble Fraction

% Dependencies: shadedErrorBar.m, Minimiser_Baseliner.m, Cottrell_Solver_Baseline_SCF
% 
%% Data Input 

% Input Parameters
no_conditions = 3; %How many conditions will be compared
no_replicates = 3; %How many biolgical replicates per condition
potentials_mV = [-100 -100:100:400]; %Potentials tested in mV, including repeat potentials. 
light_on = 90; %Time at which first light period starts
light_off = 120; %Time at which first dark period starts
time_per_potential = 150; %How many seconds per potential
sampling_rate = 0.1; %sampling reate of chronoamp data
electrode_surface_area = 0.75; %Surface area of electrode in cm^2

%Normalisation options
normalise_maxdarkcurrent = 1;
normalise_chl = 1;
std_or_se = 1; %0 for standard deviation, 1 for standard error
linear_potentials =  [3 4 ; 3 4 ; 3 4];
intensity = 4;
light_stabilisation_time = 25; %Point at which photocurrent reaches steady-state
dark_stabilisation_time = 20; %Point at which dark current reaches steady-state
spike_stabilisation_time = 15; %Point at which light current reaches steady state, normally 15 seconds
radius = 5000; %Radius of electrode based on spherical treatment
sampling_rate = 0.1; %scan rate 

%Plotting options
include_first_potential = 0; %should the first potential in the stepped chrono be excluded
dark_time_window = 17; %How much of the dark period should be visible in the plot
condition_names = ["TMs + 1% DMSO" "+ 100 \muM DCMU" "+ 10 \muM HQNO"];
load NatureColours.mat
colors = [ greens(3,:) ; blues(3,:) ; reds(3,:)]; %RGB numbers for each condition
alter_y_axis = [-100 20]; %Will alter lower and upper bounds of graph y axis. + is extend, - contract. First position for lower and second for upper bound. 
uA_units = 0; %change scale of y axis to uA rather than nA

%Data information
directory_name = ""; %Ensure all files are stored in the same directory
file_names = ["SCF_T+DMSO_NJ1" "SCF_T+DMSO_NJ2" "SCF_T+DMSO_NJ3" "SCF_T+DCMU_NJ1" "SCF_T+DCMU_NJ2" "SCF_T+DCMU_NJ3" "SCF_T+HQNO_NI2" "SCF_T+HQNO_NO3" "SCF_T+HQNO_NI1"];
file_extension = ".ascii";
chl_nM = [5.613 4.753 5.220 5.768 6.226 5.298 14.793 13.543 14.283]; %For chlorophyll normalisation. Set as an array of 1s for each dataset if no normalisation is required. 

%% Concatenating, normalising and averaging
no_potentials = length(potentials_mV); 
xtime = sampling_rate:sampling_rate:no_potentials*time_per_potential;
SCF_T_DCMU_HQNO = zeros(length(xtime),(2*no_replicates)+3,no_conditions);

%Normalsising to chlorophyll and surface area
if normalise_chl == 0;
    chl_nM = ones(1,length(chl_nM));
else
end

for h = 1:no_conditions;
    SCF_T_DCMU_HQNO(:,1,h) = xtime;
    for i = 1:no_replicates;
        input = dlmread(append(directory_name,file_names((h*no_replicates)-no_replicates+i),file_extension));
        SCF_T_DCMU_HQNO(:,i+1,h) = ((input(1:length(xtime),2) *10^9) /electrode_surface_area) / chl_nM(((h-1)*no_replicates)+i);
        clear input
    end
end

%Normalising to maximum dark current
spacing_time = light_off-light_on;

if normalise_maxdarkcurrent == 1;
    j = light_on;
    while j < xtime(end)+light_on;   
        current_range = ((j-dark_time_window)/sampling_rate):((j+dark_time_window+spacing_time)/sampling_rate);
        max_dark_current_mean = mean(SCF_T_DCMU_HQNO(current_range(length(current_range)),2:1+no_replicates,:)); %Calculates the largest final current value recorded across each replicate   
        diff_dark_current = max_dark_current_mean(:,:,:) - SCF_T_DCMU_HQNO(((j+dark_time_window+spacing_time)/sampling_rate),2:1+no_replicates,:);
        SCF_T_DCMU_HQNO(current_range,2+no_replicates:1+(2*no_replicates),:) = SCF_T_DCMU_HQNO(current_range,2:1+no_replicates,:) + diff_dark_current(:,:,:);
        j = j + 150;   
    end
else
end

% Mean and error calculation


    
for h = 1:no_conditions;
  
    if std_or_se == 0;  
        error_normaliser = 1;
    else
        error_normaliser = sqrt(no_replicates); 
    end
 

    SCF_T_DCMU_HQNO(:,2+(2*no_replicates),:) = mean(SCF_T_DCMU_HQNO(:,1+no_replicates+[1:no_replicates],:),2);
    SCF_T_DCMU_HQNO(:,3+(2*no_replicates),:) = std(SCF_T_DCMU_HQNO(:,1+no_replicates+[1:no_replicates],:),0,2)/error_normaliser;
    
end

%% Plotting and formatting stepped chronoamperometry plot

close all 

% Seperates scans at each applied potential into a seperate dataset
k = 0;
l = 1;
while k < xtime(end);   
    current_range = ((k+light_on-dark_time_window)/sampling_rate):((k+light_off+dark_time_window)/sampling_rate); %values to plot
    xc_T_TF_TP(:,l,:) = SCF_T_DCMU_HQNO(current_range,1,:); %time
    yc_T_TF_TP(:,l,:) = SCF_T_DCMU_HQNO(current_range,2+(2*no_replicates),:); %current (mean)
    eyc_T_TF_TP(:,l,:) = SCF_T_DCMU_HQNO(current_range,3+(2*no_replicates),:); %current (std)
    bounds(:,l) = [k k+light_on-dark_time_window]; %Axis break bounds
    k = k + time_per_potential;   
    l = l + 1;   
  end

% Plotting scans
for m = 1:no_conditions;
    for n = 1:1:width(xc_T_TF_TP);
        shift = n*range(bounds(:,n,:)); 
        xc_T_TS_TFS_altered(:,n,m) = xc_T_TF_TP(:,n,m) - (xc_T_TF_TP(:,n,m) >= bounds(2,n,:))*shift; %altering x axis to cutout dark current
        p_SCF_T_DCMU_HQNO(m,n) = shadedErrorBar(xc_T_TS_TFS_altered(:,n,m),yc_T_TF_TP(:,n,m),eyc_T_TF_TP(:,n,m),'lineProps',{'LineWidth',2.5,'color',colors(m,:)}); %plotting curve 
        hold on
    end
end

% Scaling x and y axis
min_current = floor(min(min(SCF_T_DCMU_HQNO(:,end-1,:))));
min_current_range = (floor(min_current*10^-(numel(num2str(abs(min_current)))-1))) * 10^(numel(num2str(abs(min_current)))-1);
max_current = ceil(max(max(SCF_T_DCMU_HQNO(:,end-1,:))));
max_current_range = (ceil(max_current*10^-(numel(num2str(abs(max_current)))-1))) * 10^(numel(num2str(abs(max_current)))-1);

x_spacing = (xc_T_TS_TFS_altered(1,2,1) - xc_T_TS_TFS_altered(end,1,1))/2;
x_lower = xc_T_TS_TFS_altered(1,2-include_first_potential,1)-x_spacing;
x_upper= xc_T_TS_TFS_altered(end,end,1)+x_spacing;
y_lower = min_current_range-alter_y_axis(1);
y_upper = max_current_range+alter_y_axis(2);

xlim([x_lower x_upper]);
ylim([y_lower y_upper]);
xtics = x_lower+x_spacing:dark_time_window:x_upper-x_spacing;
 
% General formatting
box off
xlabel({' ','Time (seconds)'});

if uA_units == 0; %change scale of y axis to uA rather than nA
    ylabel({'Current Density (nA [nmol Chl \ita\rm]^{-1} cm^{-2})'});
else
    ylabel({'Current Density (\muA [nmol Chl \ita\rm]^{-1} cm^{-2})'});
end

h = gca;
h.Color = [0.8 0.8 0.8];
h.XMinorTick = 'on';
% h.XMinorTick = [xtics];
h.XTickLabel = [];
h.XAxis.TickLength = [0.005 0.005];
h.XMinorTick = 'off';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1;

%Adding annotations
for o = 2-include_first_potential:1:width(xc_T_TF_TP); 
    
    qx1 = xc_T_TS_TFS_altered(1,o,1)+dark_time_window;
    qx2 = xc_T_TS_TFS_altered(end,o,1)-dark_time_window;
    qx3 = qx1+((qx2-qx1)/2);
    qy = y_lower-((y_upper-y_lower)/22);

    onbox = area([qx1 qx2],[y_upper y_upper]); %inserting light boxes
    onbox.BaseValue = y_lower-1000;
    onbox.FaceColor = [1 1 1];
    onbox.EdgeColor = 'none';
    uistack(onbox,'bottom');
    
    if potentials_mV(o) <= 0;
        text(qx3,qy,append(num2str(potentials_mV(o))," mV"),'HorizontalAlignment','Center','FontName','Helvetica Ltd Std','FontSize',17)
    else; 
        text(qx3,qy,append("+",num2str(potentials_mV(o))," mV"),'HorizontalAlignment','Center','FontName','Helvetica Ltd Std','FontSize',17)
    end

    hold on

end;

line([x_lower x_upper],[y_lower y_lower],'LineWidth',1.5,'Color','black'); 
for p = 2-include_first_potential:1:width(xc_T_TF_TP)-1; 
    text(xc_T_TS_TFS_altered(end,p,1)+(0.5*x_spacing),min_current_range-alter_y_axis(1),'//','Color','black','FontSize',20); %inserting break symbols
    line([xc_T_TS_TFS_altered(end,p,1)+(0.9*x_spacing)  xc_T_TS_TFS_altered(end,p,1)+(1.3*x_spacing)],[min_current_range-alter_y_axis(1) min_current_range-alter_y_axis(1)],'LineWidth',2,'Color','white'); 
end
hold on
    
%Adding legend
legend([p_SCF_T_DCMU_HQNO(:).mainLine],condition_names,'location','northwest');
legend box off

% Scaling and saving image
pbaspect([4 1.3 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [0, 0, 2150, 800])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'SCF_T_DCMU_HQNO_Curve','svg')


%% Calculating photocurrents, dark currents and spike charges
close all

for s = 1:no_conditions
    for t = 1:no_replicates
        
        tinput = SCF_T_DCMU_HQNO(:,1,s); %time data 
        Iinput = SCF_T_DCMU_HQNO(:,t+1,s); %current data
        
        chl = chl_nM((s*no_replicates)-no_replicates+t); %chlorophyll concentration in any unit used
            
        u = 1;
        
        for v = 2-include_first_potential:1:no_potentials;
        
            if ismember(v,linear_potentials(s,:)) == 1
                linear_baseline = 1;
            else
                linear_baseline = 0;
            end

            start_time = 85 +(time_per_potential*(v-1));
            light_on = 90 + (time_per_potential*(v-1));
            light_off = 120 + (time_per_potential*(v-1));
            end_time = 149.5 + (time_per_potential*(v-1));
            spacing_time = end_time-start_time;
            
            Cottrell_Solver_Baseliner_SCF

            SCF_T_DCMU_HQNO_dark_currents(u,t,s) = dark_current;
            SCF_T_DCMU_HQNO_photocurrents(u,t,s) = photocurrent;
            SCF_T_DCMU_HQNO_spike_charges(u,t,s) = spike_charge;
            SCF_T_DCMU_HQNO_dip_charges(u,t,s) = dip_charge;
            
            u = u + 1;
        end
    end
end

% Mean and error calculation

for h = 1:no_conditions;
   
    if std_or_se == 0;  
        error_normaliser = 1;
    else
        error_normaliser = sqrt(no_replicates); 
    end
 

    SCF_T_DCMU_HQNO_dark_currents(:,no_replicates+1,h) = mean(SCF_T_DCMU_HQNO_dark_currents(:,1:no_replicates,h),2); %dark currents in nA
    SCF_T_DCMU_HQNO_dark_currents(:,no_replicates+2,h) = std(SCF_T_DCMU_HQNO_dark_currents(:,1:no_replicates,h),0,2)/error_normaliser;
    SCF_T_DCMU_HQNO_photocurrents(:,no_replicates+1,h) = mean(SCF_T_DCMU_HQNO_photocurrents(:,1:no_replicates,h),2); %photocurrents in nA
    SCF_T_DCMU_HQNO_photocurrents(:,no_replicates+2,h) = std(SCF_T_DCMU_HQNO_photocurrents(:,1:no_replicates,h),0,2)/error_normaliser;
    SCF_T_DCMU_HQNO_spike_charges(:,no_replicates+1,h) = mean(SCF_T_DCMU_HQNO_spike_charges(:,1:no_replicates,h)/1000,2); %spike charges in uQ
    SCF_T_DCMU_HQNO_spike_charges(:,no_replicates+2,h) = std(SCF_T_DCMU_HQNO_spike_charges(:,1:no_replicates,h)/1000,0,2)/error_normaliser;
    SCF_T_DCMU_HQNO_dip_charges(:,no_replicates+1,h) = mean(SCF_T_DCMU_HQNO_dip_charges(:,1:no_replicates,h)/1000,2); %dip charges in uQ
    SCF_T_DCMU_HQNO_dip_charges(:,no_replicates+2,h) = std(SCF_T_DCMU_HQNO_dip_charges(:,1:no_replicates,h)/1000,0,2)/error_normaliser;
    
end

%% Plotting photocurrent parameters

close all

x_spacing = potentials_mV(end)-potentials_mV(end-1);
x_lower = potentials_mV(1)-(x_spacing/10);
x_upper = potentials_mV(end)+(x_spacing/10);

for w = 1:no_conditions;
    
    % subplot(2,2,1)
    p_SCF_T_DCMU_HQNO_dark_currents(w) = errorbar(potentials_mV(2-include_first_potential:end),SCF_T_DCMU_HQNO_dark_currents(:,no_replicates+1,w),SCF_T_DCMU_HQNO_dark_currents(:,no_replicates+2,w),'Color',colors(w,:),'LineWidth',2.5);
    % if w == 3;
    %     legend([p_SCF_T_DCMU_HQNO_dark_currents(4) p_SCF_T_DCMU_HQNO_dark_currents(3) p_SCF_T_DCMU_HQNO_dark_currents(2) p_SCF_T_DCMU_HQNO_dark_currents(1)],condition_names,'location','northwest');
    %     legend box off
    % else
    % end
    xlabel({'Potential (mV vs SHE)'});
    if normalise_chl == 1;
        ylabel({'Dark Current Density',' (nA [nmol Chl \ita\rm]^{-1} cm^{-2})'});
    else
        ylabel({'Dark Current Density',' (nA cm^{-2})'});
    end
    box off
    xlim([x_lower x_upper]);
    h = gca;
    set(get(gca(),'XAxis'),'MinorTickValues',potentials_mV(2-include_first_potential:end))
    h.XAxis.TickLength = [0.01 0.01];
    h.XMinorTick = 'on';
    h.YMinorTick = 'on';
    h.TickDir = 'out';
    h.FontName = 'Helvetica Ltd Std';
    h.FontSize = 17;
    h.LineWidth = 1;
    hold on

end

% Scaling and saving image
pbaspect([1 1.3 1]);
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'SCF_T_DCMU_HQNO_Dc','svg')

hold off 

for w = 1:no_conditions;
    
    % subplot(2,2,2)
    p_SCF_T_DCMU_HQNO_photocurrents(w) = errorbar(potentials_mV(2-include_first_potential:end),SCF_T_DCMU_HQNO_photocurrents(:,no_replicates+1,w),SCF_T_DCMU_HQNO_photocurrents(:,no_replicates+2,w),'Color',colors(w,:),'LineWidth',2.5);
    if w == no_conditions;
        legend([p_SCF_T_DCMU_HQNO_photocurrents],condition_names,'location','northwest');
        legend box off
    else
    end
    xlabel({'Potential (mV vs SHE)'});
    if normalise_chl == 1;
        ylabel({'Steady State Photocurrent (nA [nmol Chl \ita\rm]^{-1} cm^{-2})'});
    else
        ylabel({'Steady State Photocurrent (nA cm^{-2})'});
    end
    box off
    xlim([x_lower x_upper]);
    ylim([0 60]);
    h = gca;
    set(get(gca(),'XAxis'),'MinorTickValues',potentials_mV(2-include_first_potential:end))
    h.XAxis.TickLength = [0.01 0.01];
    h.XMinorTick = 'on';
    h.YMinorTick = 'on';
    h.TickDir = 'out';
    h.FontName = 'Helvetica Ltd Std';
    h.FontSize = 17;
    h.LineWidth = 1;
    ytickformat('%.1f')
    hold on

end

% Scaling and saving image
pbaspect([1 1.3 1]);
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'SCF_T_DCMU_HQNO_Pc','svg')

hold off

for w = 1:no_conditions;

    % subplot(2,2,3)
    p_SCF_T_DCMU_HQNO_spike_charges(w) = errorbar(potentials_mV(2-include_first_potential:end),SCF_T_DCMU_HQNO_spike_charges(:,no_replicates+1,w),SCF_T_DCMU_HQNO_spike_charges(:,no_replicates+2,w),'Color',colors(w,:),'LineWidth',2.5);
    % if w == 3;
    %     legend([p_SCF_T_DCMU_HQNO_spike_charges(4) p_SCF_T_DCMU_HQNO_spike_charges(3) p_SCF_T_DCMU_HQNO_spike_charges(2) p_SCF_T_DCMU_HQNO_spike_charges(1)],condition_names,'location','northeast');
    %     legend box off
    % else
    % end
    xlabel({'Potential (mV vs SHE)'});
    if normalise_chl == 1;
        ylabel({'Spike Charge (\muC [nmol Chl \ita\rm]^{-1} cm^{-2})'});
    else
        ylabel({'Spike Charge (\muC cm^{-2})'});
    end
    box off
    xlim([x_lower x_upper]);
    pbaspect([1.5 1 1]);
    h = gca;
    set(get(gca(),'XAxis'),'MinorTickValues',potentials_mV(2-include_first_potential:end))
    h.XAxis.TickLength = [0.01 0.01];
    h.XMinorTick = 'on';
    h.YMinorTick = 'on';
    h.TickDir = 'out';
    h.FontName = 'Helvetica Ltd Std';
    h.FontSize = 17;
    h.LineWidth = 1;
    ytickformat('%.2f')
    hold on

end

% Scaling and saving image
pbaspect([1 1.3 1]);
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'SCF_T_DCMU_HQNO_Sp','svg')

hold off

for w = 1:no_conditions;

    % subplot(2,2,4)
    p_SCF_T_DCMU_HQNO_dip_charges(w) = errorbar(potentials_mV(2-include_first_potential:end),SCF_T_DCMU_HQNO_dip_charges(:,no_replicates+1,w),SCF_T_DCMU_HQNO_dip_charges(:,no_replicates+2,w),'Color',colors(w,:),'LineWidth',2.5);
%     if w == 3;
%     legend([p_SCF_T_DCMU_HQNO_dip_charges(4) p_SCF_T_DCMU_HQNO_dip_charges(3) p_SCF_T_DCMU_HQNO_dip_charges(2) p_SCF_T_DCMU_HQNO_dip_charges(1)],condition_names,'location','northwest');
%         legend box off
%     else
%     end
    xlabel({'Potential (mV vs SHE)'});
    if normalise_chl == 1;
        ylabel({'Dip Charge Density',' (\muC [nmol Chl \ita\rm]^{-1} cm^{-2})'});
    else
        ylabel({'Dip Charge Density',' (\muC cm^{-2})'});
    end
    box off
    xlim([x_lower x_upper]);
    h = gca;
    set(get(gca(),'XAxis'),'MinorTickValues',potentials_mV(2-include_first_potential:end))
    h.XAxis.TickLength = [0.01 0.01];
    h.XMinorTick = 'on';
    h.YMinorTick = 'on';
    h.TickDir = 'out';
    h.FontName = 'Helvetica Ltd Std';
    h.FontSize = 17;
    h.LineWidth = 1;
    ytickformat('%.2f')
    hold on

end

% Scaling and saving image
pbaspect([1 1.3 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'SCF_T_DCMU_HQNO_Di','svg')
