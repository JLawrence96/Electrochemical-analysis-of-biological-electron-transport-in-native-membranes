%% QCM Flow

%% Data Input
QCM_TMs_Flow_Electrolyte = csvread("QCM_TM_Flow_Electrolyte.csv");
QCM_TMs_Flow_ElectrolyteCa = csvread("QCM_TM_Flow_ElectrolyteCa.csv");
load NatureColours.mat
colors1 = [greens(1,:) ; greens(2,:) ; greens(4,:) ; greens(5,:)];
colors2 = [blues(1,:) ; blues(2,:) ; blues(4,:) ; blues(5,:)];

%% Frequency
for i = 1:4;
    % p_QCM_TMs_Flow_Electrolyte_Freq(i) = plot((QCM_TMs_Flow_Electrolyte(:,1)./60)-0.7,QCM_TMs_Flow_Electrolyte(:,i+1),'color',colors1(i,:),'LineWidth',3);
    % hold on
    p_QCM_TMs_Flow_ElectrolyteCa_Freq(i) = plot(QCM_TMs_Flow_ElectrolyteCa(:,1)./60,QCM_TMs_Flow_ElectrolyteCa(:,i+1),'color',colors1(i,:),'LineWidth',3);
    hold on
end

%Plot Formatting
box off

% lege = legend([p_QCM_TMs_Flow_Electrolyte_Freq(1) p_QCM_TMs_Flow_Electrolyte_Freq(2) p_QCM_TMs_Flow_Electrolyte_Freq(3) p_QCM_TMs_Flow_Electrolyte_Freq(4) p_QCM_TMs_Flow_ElectrolyteCa_Freq(1) p_QCM_TMs_Flow_ElectrolyteCa_Freq(2) p_QCM_TMs_Flow_ElectrolyteCa_Freq(3) p_QCM_TMs_Flow_ElectrolyteCa_Freq(4)],["3" "5" "7" "9" "3" "5" "7" "9"],'location','southeast')
lege = legend([p_QCM_TMs_Flow_ElectrolyteCa_Freq(1) p_QCM_TMs_Flow_ElectrolyteCa_Freq(2) p_QCM_TMs_Flow_ElectrolyteCa_Freq(3) p_QCM_TMs_Flow_ElectrolyteCa_Freq(4) ],["F3" "F5" "F7" "F9"],'location','southeast')
legend box off

xlim([0 20])
ylim([-370 5])
xlabel({'Time (min)'});
ylabel({'Frequency (Hz)'});
h = gca;
h.XMinorTick = 'on';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1;
set(h ,'Layer', 'Top');
hold off

% Scaling and saving image
pbaspect([1.8 1.2 1]);
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 900, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'QCM_TMs_Flow_Electrolyte_Freq_Curve_Paper','svg')

%% Frequency
for i = 1:4;
    %p_QCM_TMs_Flow_Electrolyte_Diss(i) = plot((QCM_TMs_Flow_Electrolyte(:,1)./60)-0.7,QCM_TMs_Flow_Electrolyte(:,i+5),'color',colors1(i,:),'LineWidth',3);
    %hold on
    p_QCM_TMs_Flow_ElectrolyteCa_Diss(i) = plot(QCM_TMs_Flow_ElectrolyteCa(:,1)./60,QCM_TMs_Flow_ElectrolyteCa(:,i+5),'color',colors1(i,:),'LineWidth',3);
    hold on
end

%Plot Formatting
box off

% lege = legend([p_QCM_TMs_Flow_Electrolyte_Diss(1) p_QCM_TMs_Flow_Electrolyte_Diss(2) p_QCM_TMs_Flow_Electrolyte_Diss(3) p_QCM_TMs_Flow_Electrolyte_Diss(4) p_QCM_TMs_Flow_ElectrolyteCa_Diss(1) p_QCM_TMs_Flow_ElectrolyteCa_Diss(2) p_QCM_TMs_Flow_ElectrolyteCa_Diss(3) p_QCM_TMs_Flow_ElectrolyteCa_Diss(4)],["D3" "D5" "D7" "D9" "D3" "D5" "D7" "D9"],'location','northeast')
lege = legend([p_QCM_TMs_Flow_ElectrolyteCa_Diss(1) p_QCM_TMs_Flow_ElectrolyteCa_Diss(2) p_QCM_TMs_Flow_ElectrolyteCa_Diss(3) p_QCM_TMs_Flow_ElectrolyteCa_Diss(4)],["D3" "D5" "D7" "D9"],'location','northeast')
legend box off

xlim([0 20])
ylim([-5 140])
xlabel({'Time (min)'});
ylabel({'Dissipation (AU)'});
h = gca;
h.XMinorTick = 'on';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1;
set(h ,'Layer', 'Top');
hold off

% Scaling and saving image
pbaspect([1.8 1.2 1]);
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 900, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'QCM_TMs_Flow_Electrolyte_Diss_Curve_Paper','svg')
