%% Chronoamperommetry Thylakoid Membranes
% Dependencies: shadedErrorBar.m, Minimiser_Baseliner.m,Cottrell_Solver_Baseline_C

%% Data Input 

% Input Parameters
no_replicates = 3; %How many biolgical replicates per condition
no_scans = 3; %How many scans should be averaged

% Fitting Conditions
intensities = [5 5 5]; %Computing intensities for curve fitting
start_times = [125 125 125]; %Start time of first scan
light_on_times = [130 130 130]; %Time at which first light period starts
light_off_times = [190 190 190]; %Time at which first dark period starts
end_times = [250 250 250]; %End time of first scan
linear_baselines = [1 1 1]; %0 = fits dark current with cottrel equation, 1 = fits dark current with straight line.
light_stabilisation_time = 30; %Point at which photocurrent reaches steady-state
dark_stabilisation_time = 45; %Point at which dark current reaches steady-state
spike_stabilisation_time = 15; %Point at which light current reaches steady state, normally 15 seconds
spacing_time = 120; %space between scans
radius = 5000; %radius of spherical electrode (um). Assumes porous electrodes are 1000x single pore radius.  
sampling_rate = 0.1; %sampling reate of chronoamp data
electrode_surface_area = 0.75; %Surface area of electrode in cm^2

%Normalisation options
normalise_chl = 1;
std_or_se = 1; %0 for standard deviation, 1 for standard error

%Plotting options
xtime = (0.1:0.1:125)'; %Time range of x axis, should be end_time - start_time
load NatureColours.mat
colors = [greens(3,:)]; %Select colours to use. Number of colours should equal number of concentrations
alter_y_axis = [-1.6 1]; %Will alter lower and upper bounds of graph y axis. + is extend, - contract. First position for lower and second for upper bound. 
alter_y_axis_decay = [0.4 0.5];
decay_rep = 3;

%Data information
directory_name = ""; %Ensure all files are stored in the same directory
file_names = ["C03_PT_1_2" "C03_PT_2_2" "C03_PT_3_2"];
file_extension = ".ascii";
chl_nM = [81.7168534 90.90879561 92.10277242]; %For chlorophyll normalisation. Set as an array of 1s for each dataset if no normalisation is required.

%% Processing
   
C03_T_Nbenthamiana(:,1) = xtime;

if normalise_chl == 0;
    chl_nM = ones(1,no_replicates);
else
end
        
for j = 1:no_replicates;
                    
    input = dlmread(append(directory_name,file_names(j),file_extension));
    tinput = input(:,1);
    Iinput = ((input(:,2)*10^9) /electrode_surface_area) / chl_nM(j);
    intensity = intensities(j); 
    start_time = start_times(j); 
    light_on = light_on_times(j);
    light_off = light_off_times(j);
    end_time = end_times(j);
    linear_baseline = linear_baselines(j);
            
    for k = 1:no_scans;
            
        Cottrell_Solver_Baseliner_Chrono %Calls baselining function
            
        C03_T_Nbenthamiana(:,((j-1)*no_scans)+k+1) =  Iplot_baseline_corrected;

        start_time = start_time+spacing_time; 
        light_on = light_on+spacing_time;
        light_off = light_off+spacing_time;
        end_time = end_time+spacing_time;
            
    end
end


%% Averaging and calculating percentage changes;

%Averaging scans
for l = 1:no_replicates;
    C03_T_Nbenthamiana(:,(no_scans*no_replicates)+1+l) = mean(C03_T_Nbenthamiana(:,((l-1)*no_scans)+2:((l-1)*no_scans)+no_scans+1),2);
end


%Averaging replicates and calculating errors

if std_or_se == 0;
    error_normaliser = 1;
else
    error_normaliser = sqrt(no_replicates);
end

C03_T_Nbenthamiana(:,(no_scans*no_replicates)+no_replicates+2) = mean(C03_T_Nbenthamiana(:,(no_scans*no_replicates)+2:(no_scans*no_replicates)+no_replicates+1),2);
C03_T_Nbenthamiana(:,(no_scans*no_replicates)+no_replicates+3) = std(C03_T_Nbenthamiana(:,(no_scans*no_replicates)+2:(no_scans*no_replicates)+no_replicates+1),0,2)/error_normaliser;


%% Plotting Chronoampeormetry Curve
close all

%Plotting curves
p_C03_T_Nbenthamiana = shadedErrorBar(C03_T_Nbenthamiana(:,1),C03_T_Nbenthamiana(:,(no_scans*no_replicates)+no_replicates+2),C03_T_Nbenthamiana(:,(no_scans*no_replicates)+no_replicates+3),'lineProps',{'LineWidth',2.5,'color',colors});

hold on    

%Graph limits
max_current = ceil(max(max(C03_T_Nbenthamiana(:,(no_scans*no_replicates)+no_replicates+2,:))));
max_current_range = (ceil(max_current*10^-(numel(num2str(abs(max_current)))-1))) * 10^(numel(num2str(abs(max_current)))-1);

x_lower = 0;
x_upper = xtime(end);
y_lower = -2-alter_y_axis(1);
y_upper = max_current_range+alter_y_axis(2); 

xlim([x_lower x_upper])
ylim([y_lower y_upper]);

%Adding annotations
onbox = area([light_on_times(1)-start_times(1) light_off_times(1)-start_times(1)],[y_upper y_upper]);
onbox.BaseValue = y_lower;
onbox.FaceColor = [1 1 1];
onbox.EdgeColor = 'none';
uistack(onbox,'bottom');
hold on

%Plot Formatting
box off
xlabel({'Time (s)'});
if normalise_chl == 1;
    ylabel({'Photocurrent Density (nA [nmol Chl \ita\rm + \itb\rm]^{-1} cm^{-2})'});
else
    ylabel({'Photocurrent Density (nA cm^{-2})'});
end

h = gca;
h.Color = [0.8 0.8 0.8];
h.XMinorTick = 'on';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1;
set(h ,'Layer', 'Top');
hold off

% Scaling and saving image
pbaspect([1 1.3 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_Nbenthamiana_Curve','svg')

%% Plotting Decay Curve
close all

%Plotting curves
for i = 1:no_replicates;
    p_C03_T_Nbenthamiana_Decay = plot(C03_T_Nbenthamiana(:,1)+(spacing_time*(i-1)),C03_T_Nbenthamiana(:,((decay_rep-1)*no_replicates)+i+1),'LineWidth',2.5,'color',colors);
    hold on
end
    
%Graph limits
max_current = ceil(max(max(C03_T_Nbenthamiana(:,(no_scans*no_replicates)+no_replicates+2,:))));
max_current_range = (ceil(max_current*10^-(numel(num2str(abs(max_current)))-1))) * 10^(numel(num2str(abs(max_current)))-1);

x_lower = 0;
x_upper = xtime(end)+(spacing_time*(no_replicates-1));
y_lower = 0-alter_y_axis_decay(1);
y_upper = max_current_range+alter_y_axis_decay(2);

xlim([x_lower x_upper])
ylim([y_lower y_upper]);

%Adding annotations
onbox = area([light_on_times(1)-start_times(1) light_off_times(1)-start_times(1)],[y_upper y_upper]);
onbox.BaseValue = y_lower;
onbox.FaceColor = [1 1 1];
onbox.EdgeColor = 'none';
uistack(onbox,'bottom');
hold on
onbox2 = area([light_on_times(1)-start_times(1)+120 light_off_times(1)-start_times(1)+120],[y_upper y_upper]);
onbox2.BaseValue = y_lower;
onbox2.FaceColor = [1 1 1];
onbox2.EdgeColor = 'none';
uistack(onbox2,'bottom');
hold on
onbox3 = area([light_on_times(1)-start_times(1)+240 light_off_times(1)-start_times(1)+240],[y_upper y_upper]);
onbox3.BaseValue = y_lower;
onbox3.FaceColor = [1 1 1];
onbox3.EdgeColor = 'none';
uistack(onbox3,'bottom');
hold on

%Plot Formatting
box off
xlabel({'Time (s)'});
ylabel({'Photocurrent Density (nA [nmol Chl \ita\rm + \itb\rm]^{-1} cm^{-2})'});
h = gca;
h.Color = [0.8 0.8 0.8];
h.XMinorTick = 'on';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1;
set(h ,'Layer', 'Top');
hold off

% Scaling and saving image
pbaspect([2.6 1.3 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 1200, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_Nbenthamiana_Decay','svg')