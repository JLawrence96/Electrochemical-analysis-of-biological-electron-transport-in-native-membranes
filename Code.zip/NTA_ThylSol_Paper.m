%% F = NTA Analysis
colors = [greens(3,:)];

NTA_data = csvread('NTA_TMs.csv');
NTA_data_adjusted(:,1) = NTA_data(:,1);
NTA_data_adjusted(:,2:4) = NTA_data(:,2:4) * 500 ./ 1000;

NTA_total_particles_mean = mean(sum(NTA_data_adjusted(:,2:4)))
NTA_total_particles_std = std(sum(NTA_data_adjusted(:,2:4)))./3

NTA_bins = NTA_data_adjusted(:,1);
NTA_mean = mean(NTA_data_adjusted(:,2:4),2);
NTA_std = std(NTA_data_adjusted(:,2:4),0,2)/sqrt(3);

NTA_AverageSize_mean = mean(sum((NTA_data_adjusted(:,2:4) .* NTA_data_adjusted(:,1))) ./ sum(NTA_data_adjusted(:,2:4)))
NTA_AverageSize_std = std(sum((NTA_data_adjusted(:,2:4) .* NTA_data_adjusted(:,1))) ./ sum(NTA_data_adjusted(:,2:4)))./3

Chl_liposome = (((2 * 10^-6) / 893.509) / NTA_total_particles_mean) * 6.022 * 10 ^23;
PSII_chl = 70;
PSI_chl = 270;
PSI_PSII_ratio = 2.5; 
Chl_PETC = 70 + (270*2.5);

PETC_liposome = Chl_liposome / Chl_PETC


p_NTA = shadedErrorBar(NTA_bins,NTA_mean./10^6,NTA_std./10^6,'lineProps',{'LineWidth',2.5,'color',colors});
hold on

%Plot Formatting
xlim([0 400]);
ylim([0 2]);
box off
xlabel({'Particle Diameter (nm)'});
ylabel({'Concentration (10^{6} Particles \muL^{-1})'});
h = gca;
h.XMinorTick = 'on';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1;
set(h ,'Layer', 'Top');
hold off

% Scaling and saving image
pbaspect([1 1.3 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'NTA_ThylSol','svg')

