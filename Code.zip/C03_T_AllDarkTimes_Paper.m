%% Plotting spike dark time changes

%% Data Input
treatment_names = ["WT TMs" "+ 1 mM NADPH" "+ 5 mM Succinate" "\Delta\itcox\rm\Delta\itcyd\rm\Delta\itarto\rm TMs"];
dark_time_names = ["T" "T_NADPH" "T_Succinate" "3X"];
load NatureColours.mat
dark_times_colors = [greens(3,:) ; blues(3,:) ; reds(3,:) ; browns(3,:)];
times_plot = [10 30 60 120 300 600]; %Potentials tested in mV, including repeat potentials.
largest_replicate_number = 3;
normalise_chl = 1;

alter_x_axis = [0 0];
alter_y_axis_dark_currents = [0 50];
alter_y_axis_photocurrents = [0 0];
alter_y_axis_spike_charges = [0 0.7];
alter_y_axis_dip_charges = [0 0];

%% Processing
for z = 1:length(dark_time_names)
    run(append("C03_",dark_time_names(z),"_DarkTime_Paper"))
    close all 
      
    C03_T_AllDarkTimes_dark_currents(:,:,z) = C03_T_DarkTime_dark_currents();
    C03_T_AllDarkTimes_photocurrents(:,:,z) = C03_T_DarkTime_photocurrents;
    C03_T_AllDarkTimes_spike_charges(:,:,z) = C03_T_DarkTime_spike_charges;
    C03_T_AllDarkTimes_dip_charges(:,:,z) = C03_T_DarkTime_dip_charges;

    clear times_s;
    clear C03_T_DarkTime_dark_currents;
    clear C03_T_DarkTime_photocurrents;
    clear C03_T_DarkTime_spike_charges;
    clear C03_T_DarkTime_dip_charges;
    clear C03_T_DarkTime_dark_currents_relative;
    clear C03_T_DarkTime_photocurrents_relative;
    clear C03_T_DarkTime_spike_charges_relative;
    clear C03_T_DarkTime_dip_charges_relative;  
    clear C03_T_DarkTime_dark_currents;
    clear C03_T_DarkTime_photocurrents;
    clear C03_T_DarkTime_spike_charges;
    clear C03_T_DarkTime_dip_charges;
end

%Significance testing
all_combinations = nchoosek(1:length(dark_time_names)*length(times_plot),2);
dark_time_combinations = ceil(all_combinations./length(dark_time_names));
condition_combinations = all_combinations - (dark_time_combinations-1)*length(dark_time_names);

for n = 1:length(all_combinations);
     [h_photocurrents(n),p_photocurrents(n)] = ttest2(C03_T_AllDarkTimes_photocurrents(dark_time_combinations(n,1),no_replicates*no_scans+1:no_replicates*no_scans+no_replicates,condition_combinations(n,1)),C03_T_AllDarkTimes_photocurrents(dark_time_combinations(n,2),no_replicates*no_scans+1:no_replicates*no_scans+no_replicates,condition_combinations(n,2)));
     [h_spike_charges(n),p_spike_charges(n)] = ttest2(C03_T_AllDarkTimes_spike_charges(dark_time_combinations(n,1),no_replicates*no_scans+1:no_replicates*no_scans+no_replicates,condition_combinations(n,1)),C03_T_AllDarkTimes_spike_charges(dark_time_combinations(n,2),no_replicates*no_scans+1:no_replicates*no_scans+no_replicates,condition_combinations(n,2)));
end

%% Plotting

% dark_currents
x_lower = 0;
x_upper = times_plot(end);

for y = 1:length(dark_time_names)
    p_C03_T_AllDarkTimes_dark_currents(y) = errorbar(times_plot,C03_T_AllDarkTimes_dark_currents(:,end-1,y),C03_T_AllDarkTimes_dark_currents(:,end,y),'Color',dark_times_colors(y,:),'LineWidth',2.5);
    hold on
end

xlabel({append("Dark Adaptation Time (",time_units,")")});
if normalise_chl == 1;
    ylabel({'Dark Current (nA [nmol Chl \ita\rm]^{-1} cm^{-2})'});
else
    ylabel({'Dark Current (nA cm^{-2})'});
end
box off 

legend([p_C03_T_AllDarkTimes_dark_currents(1:length(dark_time_names))],[treatment_names],'location','northwest');
legend('AutoUpdate','off')
legend box off

current_ylim = ylim;
y_lower_dark_currents = 0;
y_lower_dark_currents = y_lower_dark_currents-alter_y_axis_dark_currents(1);
y_upper_dark_currents = current_ylim(2);
y_upper_dark_currents = y_upper_dark_currents+alter_y_axis_dark_currents(2);

h = gca;
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1.5;

hold off

x_lower_dark_currents = x_lower-alter_x_axis(1);
x_upper_dark_currents = x_upper+alter_x_axis(2);

xlim([x_lower x_upper])
ylim([y_lower_dark_currents y_upper_dark_currents])    

% Scaling and saving image
pbaspect([1 1.3 1]);
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_AllDarkTimes_Dc','svg')

% Photocurrents
for y = 1:length(dark_time_names)
    p_C03_T_AllDarkTimes_photocurrents(y) = errorbar(times_plot,C03_T_AllDarkTimes_photocurrents(:,end-1,y),C03_T_AllDarkTimes_photocurrents(:,end,y),'Color',dark_times_colors(y,:),'LineWidth',2.5);
    hold on
end

xlabel({append("Dark Adaptation Time (",time_units,")")});
if normalise_chl == 1;
    ylabel({'Steady State Photocurrent (nA [nmol Chl \ita\rm]^{-1} cm^{-2})'});
else
    ylabel({'Steady State Photocurrent (nA cm^{-2})'});
end
box off 

% legend([p_C03_T_AllDarkTimes_photocurrents(1:length(dark_time_names))],[treatment_names],'location','northwest');
% legend('AutoUpdate','off')
% legend box off

current_ylim = ylim;
y_lower_photocurrents = 0;
y_lower_photocurrents = y_lower_photocurrents-alter_y_axis_photocurrents(1);
y_upper_photocurrents = current_ylim(2);
y_upper_photocurrents = y_upper_photocurrents+alter_y_axis_photocurrents(2);

h = gca;
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1.5;

hold off

x_lower_photocurrents = x_lower-alter_x_axis(1);
x_upper_photocurrents = x_upper+alter_x_axis(2);

xlim([x_lower x_upper])
ylim([y_lower_photocurrents y_upper_photocurrents])    

% Scaling and saving image
pbaspect([1 1.3 1]);
% h.XTickLabel{1} = [];
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_AllDarkTimes_Pc','svg')

% spike_charges
for y = 1:length(dark_time_names)
    p_C03_T_AllDarkTimes_spike_charges(y) = errorbar(times_plot,C03_T_AllDarkTimes_spike_charges(:,end-1,y)./1000,C03_T_AllDarkTimes_spike_charges(:,end,y)./1000,'Color',dark_times_colors(y,:),'LineWidth',2.5);
    hold on
end

xlabel({append("Dark Adaptation Time (",time_units,")")});
if normalise_chl == 1;
    ylabel({'Spike Charge Density (\muC [nmol Chl \ita\rm]^{-1} cm^{-2})'});
else
    ylabel({'Spike Charge Density (\muC cm^{-2})'});
end
box off 

legend([p_C03_T_AllDarkTimes_spike_charges(1:length(dark_time_names))],[treatment_names],'location','northwest');
legend('AutoUpdate','off')
legend box off

current_ylim = ylim;
y_lower_spike_charges = 0;
y_lower_spike_charges = y_lower_spike_charges-alter_y_axis_spike_charges(1);
y_upper_spike_charges = current_ylim(2);
y_upper_spike_charges = y_upper_spike_charges+alter_y_axis_spike_charges(2);

h = gca;
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1.5;

hold off

x_lower_spike_charges = x_lower-alter_x_axis(1);
x_upper_spike_charges = x_upper+alter_x_axis(2);

xlim([x_lower x_upper])
ylim([y_lower_spike_charges y_upper_spike_charges])    

% Scaling and saving image
pbaspect([1 1.3 1]);
% h.XTickLabel{1} = [];
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_AllDarkTimes_Sp','svg')

% Dip charge
for y = 1:length(dark_time_names)
    p_C03_T_AllDarkTimes_dip_charges(y) = errorbar(times_plot,C03_T_AllDarkTimes_dip_charges(:,end-1,y),C03_T_AllDarkTimes_dip_charges(:,end,y),'Color',dark_times_colors(y,:),'LineWidth',2.5);
    hold on
end

xlabel({append("Dark Adaptation Time (",time_units,")")});
if normalise_chl == 1;
    ylabel({'Dip Charge Density (nC [nmol Chl \ita\rm]^{-1} cm^{-2})'});
else
    ylabel({'Dip Charge Density (nC cm^{-2})'});
end
box off 

legend([p_C03_T_AllDarkTimes_dip_charges(1:length(dark_time_names))],[treatment_names],'location','northwest');
legend('AutoUpdate','off')
legend box off

current_ylim = ylim;
y_lower_dip_charges = 0;
y_lower_dip_charges = y_lower_dip_charges-alter_y_axis_dip_charges(1);
y_upper_dip_charges = current_ylim(2);
y_upper_dip_charges = y_upper_dip_charges+alter_y_axis_dip_charges(2);

h = gca;
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1.5;

x_lower_dip_charges = x_lower-alter_x_axis(1);
x_upper_dip_charges = x_upper+alter_x_axis(2);

xlim([x_lower x_upper])
ylim([y_lower_dip_charges y_upper_dip_charges])    

% Scaling and saving image
pbaspect([1 1.3 1]);
% h.XTickLabel{1} = [];
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_AllDarkTimes_Di','svg')

%% Photocurrents Bar chart
close all
selected_dark_time = 3;

for y = 1:length(dark_time_names)
    bar_spacing = 1/length(dark_time_names)/1.2;
    p_C03_T_AllDarkTimes_photocurrents_bar(y) = bar((y-1)*bar_spacing,C03_T_AllDarkTimes_photocurrents(selected_dark_time,end-1,y),'BarWidth',bar_spacing*0.9,'FaceColor',dark_times_colors(y,:),'LineWidth',1);
    hold on
    p_C03_T_AllDarkTimes_photocurrents_error(y) = errorbar((y-1)*bar_spacing,C03_T_AllDarkTimes_photocurrents(selected_dark_time,end-1,y),C03_T_AllDarkTimes_photocurrents(selected_dark_time,end,y),'.','Color','k','LineWidth',1);
    hold on
end

significant_index_photocurrents = intersect(intersect(find(dark_time_combinations(:,1)==selected_dark_time),find(dark_time_combinations(:,2)==selected_dark_time)),find(p_photocurrents<0.05));
sig_bar_positions_photocurrents = num2cell((condition_combinations(significant_index_photocurrents,:)*bar_spacing)-bar_spacing,2)';
sig_p_values_photocurrents = p_photocurrents(significant_index_photocurrents);
p_C03_T_AllDarkTimes_photocurrents_sigstar = sigstar(sig_bar_positions_photocurrents,sig_p_values_photocurrents,1);

h = gca;
xlim([0-(bar_spacing/1.5) ((y-1)*bar_spacing)+(bar_spacing/1.5)])
ylim([0 8]);

if normalise_chl == 1;
    ylabel({'Steady State Photocurrent (nA [nmol Chl \ita\rm]^{-1} cm^{-2})'});
else
    ylabel({'Steady State Photocurrent (nA cm^{-2})'});
end
box off 

% legend([p_C03_T_AllDarkTimes_photocurrents_bar(1:length(dark_time_names))],[treatment_names],'position',[0.7 0.65 0.1 0.1]);
% legend('AutoUpdate','off')
% legend box off

box off
h.XTick = ((1:length(dark_time_names))-1)*bar_spacing; %[((1:length(dark_time_names))-1)*bar_spacing];
h.XTickLabel = treatment_names;
xtickangle(20)
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1;
hold on

% Scaling and saving image
pbaspect([1 1.3 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 700])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_AllDarkTimes_Pc60','svg')