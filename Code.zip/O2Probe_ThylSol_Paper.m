%% Correlated JTS P700 measurements JTS thylakoids + 100 uM DCMU +/- 1 mM NADPH
% Dependencies: shadedErrorBar.m, Minimiser_Baseliner.m,Cottrell_Solver_Baseline_C

%% Data Input 

% Input Parameters
no_conditions = 2; %How many conditions
no_samples = 2;
no_replicates = 3; %How many biolgical replicates per condition

% Fitting Conditions for Chronoamperometry
start_times = [655 190 833 ; 498 660 578 ; 59 41 44 ; 498 660 578]; %Start time of first scan, first at 9.989
light_on_times = [665 200 843 ; 508 670 588 ; 69 51 54 ; 508 670 588]; %Time at which first, second and third light period starts
light_off_times = [785 320 963 ; 628 790 708 ; 189 171 174 ; 628 790 708]; %Time at which first dark period starts
end_times = [905 440 1083; 748 910 828 ; 309 291 294 ; 748 910 828 ]; %End time of first scan
experiment_time = 240; %Length of light period and dark period combined
light_time = 120; %time of light period
preequilibration_time = 10; %Number of seconds prior to first light which are used for baselining
light_stabilisation_time = 60; %Point at which dark absorbance reaches steady-state 
dark_stabilisation_time = 110; %Point at which dark absorbance reaches steady-state 
sampling_rate = [1]; %sampling reate of JTS data
chl = [40 ; 20]; %chl a quantity in ug
volume = [1 ; 1]; %volume in mL

%Normalisation options
std_or_se = 1; %0 for standard deviation, 1 for standard error

%Plotting options
load NatureColours.mat
colors = [greens(2,:) ; greens(4,:)];
condition_names = ["PSII" "PSI"];
sample_names = ["TMs" "Cells"];
alter_y_axis = [1 5 ; 0 0]; %Will alter lower and upper bounds of graph y axis. + is extend, - contract. First position for lower and second for upper bound. 

%Data information
directory_name = ""; %Ensure all files are stored in the same directory
file_names = ["Clark_PSII_ThylSol_NP1" "Clark_PSII_ThylSol_NP2" "Clark_PSII_ThylSol_NP3"; "Clark_PSII_Cells_NP1" "Clark_PSII_Cells_NP2" "Clark_PSII_Cells_NP3"; "Clark_PSI_ThylSol_T1" "Clark_PSI_ThylSol_T2" "Clark_PSI_ThylSol_T3" ; "Clark_PSI_Cells_NP1" "Clark_PSI_Cells_NP2" "Clark_PSI_Cells_NP3"];
file_extension = ".ascii";


%% Processing Clark Traces
for i = 1:no_conditions; 
    for j = 1:no_replicates;   
        for k = 1:no_samples;
    
        input = dlmread(append(directory_name,file_names(((i-1)*no_samples)+k,j),file_extension));
        if i == 2 && k == 1;
            tinput = input(1:2:end,1);
            Iinput = input(1:2:end,2);
        else
            tinput = input(:,1);
            Iinput = input(:,2);
        end

        experiment_time = experiment_time;
        light_time = light_time;
        preequilibration_time = preequilibration_time;
        sampling_rate = sampling_rate;
        dark_stabilisation_time = dark_stabilisation_time;
                      
        start_time = start_times(((i-1)*no_samples)+k,j); 
        light_on = light_on_times(((i-1)*no_samples)+k,j);
        light_off = light_off_times(((i-1)*no_samples)+k,j);
        end_time = end_times(((i-1)*no_samples)+k,j);

        Linear_Baseliner_JTS_StartOnlyFlatClark %Calls baselining function
            
        Clark_ThylSol{i}(:,1,k) = tplot;
        Clark_ThylSol{i}(:,j+1,k) =  Iplot_baseline_corrected;

    end
    end
end

%% Calculating parameters

O2_rate = @(c,x) c(1)*x + c(2);

for i = 1:no_conditions;
    for k = 1:no_samples
    
    O2_tplot = [1:1:light_time]';
    
    for j = 1:no_replicates;

        
        O2_Iplot_light = Clark_ThylSol{i}(zeroed_light_on_index+1:zeroed_light_off_index,j+1,k)
        O2_fit_params_light{i}(:,j,k) = lsqcurvefit(O2_rate,[1 1],O2_tplot,O2_Iplot_light);
        O2_fitplot_light = O2_rate(O2_fit_params_light{i}(:,j,k),O2_tplot);

        O2_Iplot_dark = Clark_ThylSol{i}(zeroed_light_off_index+1:zeroed_end_time_index,j+1,k)
        O2_fit_params_dark{i}(:,j,k) = lsqcurvefit(O2_rate,[1 1],O2_tplot,O2_Iplot_dark);
        O2_fitplot_dark = O2_rate(O2_fit_params_dark{i}(:,j,k),O2_tplot);
        
        Clark_ThylSol_O2_rate{i}(k,j,1) = (O2_fit_params_light{i}(1,j,k).*3600.*1000)./(1000*(chl(i)/893.509))./1000;
        Clark_ThylSol_O2_rate{i}(k,j,2) = (O2_fit_params_dark{i}(1,j,k).*3600.*1000)./(1000*(chl(i)/893.509))./1000;
        Clark_ThylSol_O2_rate{i}(k,j,3) = abs(Clark_ThylSol_O2_rate{i}(k,j,1) - Clark_ThylSol_O2_rate{i}(k,j,2));

        subplot(2,1,1)
        plot(O2_tplot,O2_Iplot_light);
        hold on
        plot(O2_tplot,O2_fitplot_light);
        hold on

        subplot(2,1,2)
        plot(O2_tplot,O2_Iplot_dark);
        hold on
        plot(O2_tplot,O2_fitplot_dark);
        hold on

    end
end
end
%% Averaging

if std_or_se == 0;
    error_normaliser = 1;
else
    error_normaliser = sqrt(no_replicates);
end

%Averaging Scans for Clark
for i = 1:no_conditions
    for l = 1:no_replicates;
        for k = 1:no_samples;

        Clark_ThylSol_O2_rate{i}(k,no_replicates+1,:) = mean(Clark_ThylSol_O2_rate{i}(k,1:no_replicates,:),2);

        Clark_ThylSol_O2_rate{i}(k,no_replicates+2,:) = std(Clark_ThylSol_O2_rate{i}(k,1:no_replicates,:),0,2)./error_normaliser;
    end
    end
end

%% Plotting Absolute Parameters

%O2 Rate

close all

for w = 1:no_conditions;
    for u = 1:no_samples;
  
  bar_spacing = 1/no_conditions;
  
  p_Clark_ThylSol_O2_rate_bar(w,u) = bar((w-1)+((u-1)*bar_spacing)+((w-1)*bar_spacing),abs(Clark_ThylSol_O2_rate{w}(u,end-1,3)),'BarWidth',bar_spacing*0.9,'FaceColor',colors(u,:),'LineWidth',1.5);
  hold on
  p_Clark_ThylSol_O2_rate_error(w,u) = errorbar((w-1)+((u-1)*bar_spacing)+((w-1)*bar_spacing),abs(Clark_ThylSol_O2_rate{w}(u,end-1,3)),Clark_ThylSol_O2_rate{w}(u,end,3),'Color','k','LineWidth',1.5);
  hold on

end
end

legend([p_Clark_ThylSol_O2_rate_bar(1,1:no_samples)],sample_names,'position',[0.12 0.85 0.4 0.01]);
legend box off

ylabel({'Electron Transfer Rate (\Deltanmol O_{2} [nmol chl \ita\rm]^{-1} hr^{-1})'});

xlim([0-(bar_spacing/1.5) (w-1)+((u-1)*bar_spacing)+((w-1)*bar_spacing)+(bar_spacing/2)])
ylim([0.10000001 10^2])

annotation("textbox",[0.77 0.185 0.4 0.01],'String','n.d.','FontName','Helvetica Ltd Std','FontSize',17,'EdgeColor','none');

box off
h = gca;
h.YScale = 'log';
h.XTick = [((1:no_conditions)-1)+0.25+(((1:no_conditions)-1)*bar_spacing)];
h.XTickLabel = condition_names;
h.YMinorTick = 'on';
h.YTickLabel = [1 10 100];
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1.5;
h.YAxis.LineWidth = 1.75;
hold on


% Scaling and saving image
pbaspect([1 1.3 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 610])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'Clark_ThylSol_O2_rate_flat','svg')

hold off
