%% Correlated JTS P700 measurements JTS thylakoids + 100 uM DCMU +/- 1 mM NADPH
% Dependencies: shadedErrorBar.m, Minimiser_Baseliner.m,Cottrell_Solver_Baseline_C

%% Data Input 

% Input Parameters
no_conditions = 2; %How many conditions
no_replicates = 3; %How many biolgical replicates per condition
no_lightintensities = 8; %How many light intensities
lightintensities_uE = [10 25 50 100 250 500 750 1000]; %Potentials tested in mV, including repeat potentials.

% Fitting Conditions for Chronoamperometry
start_times = [123.438 243.98 364.823 484.666 604.708 724.651 844.594 964.537]; %Start time of first scan, first at 9.989
light_on_times = [128.438 248.98 369.823 489.666 609.708 729.651 849.594 969.537]; %Time at which first, second and third light period starts
light_off_times = [188.438 308.98 429.823 549.666 669.708 789.651 909.594 1029.537]; %Time at which first dark period starts
end_times = [248.438 368.98 489.823 609.666 729.708 849.651 969.594 1089.537]; %End time of first scan
experiment_time = 120; %Length of light period and dark period combined
light_time = 60; %time of light period
preequilibration_time = 5; %Number of seconds prior to first light which are used for baselining
Fm_light_stabilisation_time = 30; %Point at which dark absorbance reaches steady-state 
light_stabilisation_time = 50; %Point at which dark absorbance reaches steady-state 
dark_stabilisation_time = 45; %Point at which dark absorbance reaches steady-state 
sampling_rate = 0.1; %sampling reate of JTS data

%Normalisation options
std_or_se = 1; %0 for standard deviation, 1 for standard error

%Plotting options
load NatureColours.mat
colors = [greens(3,:) ; blues(3,:)];
colors_intensities = [createcolormap(no_lightintensities, greens(1,:), greens(3,:), greens(6,:)) ; createcolormap(no_lightintensities, blues(1,:), blues(3,:), blues(6,:))]; %Select colours to use. Number of colours should equal number of concentrations
plot_names = ["" "DCMU"];
condition_names = ["TMs" "+100 \muM DCMU"];
alter_y_axis = [0 10 ; 0 10 ; 0 0]; %Will alter lower and upper bounds of graph y axis. + is extend, - contract. First position for lower and second for upper bound. 

%Data information
directory_name = ""; %Ensure all files are stored in the same directory
file_names = ["PAM_JTS_ThylSol+FCN_ND1" "PAM_JTS_ThylSol+FCN_ND2" "PAM_JTS_ThylSol+FCN_ND3" ; "PAM_JTS_ThylSol+FCN+DCMU_ND1" "PAM_JTS_ThylSol+FCN+DCMU_ND2" "PAM_JTS_ThylSol+FCN+DCMU_ND3"];
file_extension = ".ascii";


%% Processing PAM Traces
for i = 1:no_conditions; 
    for j = 1:no_replicates;   
    
            input = dlmread(append(directory_name,file_names(i,j),file_extension));
            tinput = input(:,1);
            Iinput = input(:,2)*10^3;
            experiment_time = experiment_time;
            light_time = light_time;
            preequilibration_time = preequilibration_time;
            sampling_rate = sampling_rate;
            dark_stabilisation_time = dark_stabilisation_time;
            
        for k = 1:no_lightintensities;
            
            start_time = start_times(k); 
            light_on = light_on_times(k);
            light_off = light_off_times(k);
            end_time = end_times(k);

            Linear_Baseliner_JTS %Calls baselining function
            
            PAM_ThylSol{i}(:,1,k) = tplot;
            PAM_ThylSol{i}(:,j+1,k) =  Iplot_baseline_corrected;

        end
    end
end

%% Calculating parameters

for i = 1:no_conditions;
    for k = 1:no_lightintensities;
        for j = 1:no_replicates;

            PAM_ThylSol_Fmdash(k,j,i) = max(PAM_ThylSol{i}((preequilibration_time+Fm_light_stabilisation_time)/sampling_rate:(preequilibration_time+light_time)/sampling_rate,j+1,k));
        
            PAM_ThylSol_MaxFlu(k,j,i) = mean(PAM_ThylSol{i}((preequilibration_time+light_stabilisation_time)/sampling_rate:(preequilibration_time+light_time)/sampling_rate,j+1,k));

            PAM_ThylSol_PhiPSII(k,j,i) = (PAM_ThylSol_Fmdash(k,j,i) - PAM_ThylSol_MaxFlu(k,j,i)) ./ PAM_ThylSol_Fmdash(k,j,i);
       
        end
    end
end

%% Averaging

if std_or_se == 0;
    error_normaliser = 1;
else
    error_normaliser = sqrt(no_replicates);
end

%Averaging Scans for PAM
for i = 1:no_conditions
    for l = 1:no_replicates;

        PAM_ThylSol{i}(:,no_replicates+2,:) = mean(PAM_ThylSol{i}(:,2:no_replicates+1,:),2);
        PAM_ThylSol_PhiPSII(:,no_replicates+1,i) = mean(PAM_ThylSol_PhiPSII(:,1:no_replicates,i),2);

        PAM_ThylSol{i}(:,no_replicates+3,:) = std(PAM_ThylSol{i}(:,2:no_replicates+1,:),0,2)./error_normaliser;
        PAM_ThylSol_PhiPSII(:,no_replicates+2,i) = std(PAM_ThylSol_PhiPSII(:,1:no_replicates,i),0,2)./error_normaliser;
    end
end


%% Plotting PAM Curve
close all

%Plotting curves
for n = 1:no_conditions
    for m = 1:no_lightintensities;
        intensity_names(m) = append(num2str(lightintensities_uE(m))," \muE m^{-2} s^{-1}");
    
        p_PAM_ThylSol(n,m) = shadedErrorBar(PAM_ThylSol{n}(:,1,1),PAM_ThylSol{n}(:,no_replicates+2,m),PAM_ThylSol{n}(:,no_replicates+3,m),'lineProps',{'LineWidth',2.5,'color',colors_intensities(((n-1)*no_lightintensities)+m,:)});
        if m == no_conditions;

        else
        end
        hold on
    
    end

    % legend('AutoUpdate','off')
    % legend([p_PAM_ThylSol(n,1:end).mainLine],intensity_names,'location','northwest');
    % legend box off
    
    %Graph limits
    max_abs = max(max(PAM_ThylSol{n}(:,no_replicates+2,:)));
    max_abs_range = round(max_abs,1,'significant');

    x_lower = 0;
    x_upper = tplot(end);
    y_lower = 0-alter_y_axis(n,1);
    y_upper = max_abs_range+alter_y_axis(n,2);
    xlim([x_lower x_upper])
    ylim([y_lower y_upper]);

    %Adding annotations
    onbox2 = area([45 46],[y_upper y_upper]);
    onbox2.BaseValue = y_lower;
    onbox2.FaceColor = [1 0 0];
    onbox2.EdgeColor = 'none';
    uistack(onbox2,'bottom');
    onbox3 = area([105 106],[y_upper y_upper]);
    onbox3.BaseValue = y_lower;
    onbox3.FaceColor = [1 0 0];
    onbox3.EdgeColor = 'none';
    uistack(onbox3,'bottom');
    onbox1 = area([5 65],[y_upper y_upper]);
    onbox1.BaseValue = y_lower;
    onbox1.FaceColor = [1 1 1];
    onbox1.EdgeColor = 'none';
    uistack(onbox1,'bottom');
    hold on

    %Plot Formatting
    box off
    xlabel({'Time (seconds)'});
    ylabel({'Chl Fluorescence (A.U.)'});
    h = gca;
    h.Color = [0.8 0.8 0.8];
    h.XMinorTick = 'on';
    h.YMinorTick = 'on';
    h.TickDir = 'out';
    h.FontName = 'Helvetica Ltd Std';
    h.FontSize = 17;
    h.LineWidth = 1;
    set(h ,'Layer', 'Top');
    hold off

    % Scaling and saving image
    pbaspect([1 1.3 1]);
    set(gcf, 'Renderer', 'painter');
    set(gcf,'color','w');
    set(gcf, 'Position',  [100, 100, 500, 600])
    set(gcf, 'InvertHardCopy', 'off');
    saveas(gcf,append('PAM_ThylSol_Curve_',plot_names(n)),'svg')
    
    close all

end

%% Plotting Absolute Parameters

for i = 1: no_conditions;
    
    p_PAM_ThylSol_Phi(i) = errorbar(lightintensities_uE,PAM_ThylSol_PhiPSII(:,no_replicates+1,i),PAM_ThylSol_PhiPSII(:,no_replicates+2,i),'Color',colors(i,:),'LineWidth',3);
    hold on

end

legend([p_PAM_ThylSol_Phi],condition_names,'location','northeast');
legend box off

xlabel({'Light Intensity (\mumol photons m^{-2} s^{-1})'});
ylabel({'\Phi_{PSII}'});
box off

xlim([lightintensities_uE(1) lightintensities_uE(end)])
    
pbaspect([1 1 1]);
h = gca;
h.XAxis.TickLength = [0.005 0.005];
h.XMinorTick = 'off';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize= 17;
h.LineWidth = 1;
hold on

% Scaling and saving image

pbaspect([1 1.3 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'PAM_ThylSol_PhiPSII','svg')
