%% Chronoamperommetry Thylakoid Membranes + preequilibration
% Dependencies: shadedErrorBar.m, Minimiser_Baseliner.m,Cottrell_Solver_Baseline_C

%% Data Input 

% Input Parameters
no_conditions = 2; %How many conditions will be compared
no_replicates = 3; %How many biolgical replicates per condition
no_scans = 3; %How many scans should be averaged

% Fitting Conditions
intensities = [5 5 5 ; 5 5 5]; %Computing intensities for curve fitting
start_times = [125 125 125 ; 125 125 124.9]; %Start time of first scan
light_on_times = [130 130 130 ; 130 130 129.9]; %Time at which first light period starts
light_off_times = [190 190 190 ; 190 190 189.9]; %Time at which first dark period starts
end_times = [250 250 250 ; 250 250 249.9]; %End time of first scan
linear_baselines = [1 1 1 ; 1 1 1 ; 1 1 1 ; 1 1 1]; %0 = fits dark current with cottrel equation, 1 = fits dark current with straight line.
light_stabilisation_time = 30; %Point at which photocurrent reaches steady-state
dark_stabilisation_time = 45; %Point at which dark current reaches steady-state
spike_stabilisation_time = 15; %Point at which light current reaches steady state, normally 15 seconds
spacing_time = 120; %space between scans
radius = 5000; %radius of spherical electrode (um). Assumes porous electrodes are 1000x single pore radius.  
sampling_rate = 0.1; %sampling reate of chronoamp data
electrode_surface_area = 0.75; %Surface area of electrode in cm^2

%Normalisation options
normalise_chl = 1;
std_or_se = 1; %0 for standard deviation, 1 for standard error

%Plotting options
xtime = (0.1:0.1:125)'; %Time range of x axis, should be end_time - start_time
load NatureColours.mat
colors = [greens([4 2],:)]; %Select colours to use. Number of colours should equal number of concentrations
condition_names = ["-O_{2}" "+O_{2}"]; %Potentials tested in mV, including repeat potentials.
alter_y_axis = [0 0]; %Will alter lower and upper bounds of graph y axis. + is extend, - contract. First position for lower and second for upper bound. 
flip_axis = 0;

%Data information
directory_name = ""; %Ensure all files are stored in the same directory
file_names = ["C03_T_O1" "C03_T_Q3" "C03_T_O3" ; "C03_T+O2_O1" "C03_T+O2_Q3" "C03_T+O2_O3"];
file_extension = ".ascii";
chl_nM = [20.63384121 31.16073985 18.3380814]; %For chlorophyll normalisation. Set as an array of 1s for each dataset if no normalisation is required.

%% Processing
for h = 1:no_conditions;
        
        if flip_axis == 1;
            i = no_conditions-h+1;
        else
            i = h;
        end

        C03_T_Oxygen(:,1,i) = xtime;

    for j = 1:no_replicates;
                    
            input = dlmread(append(directory_name,file_names(i,j),file_extension));
            tinput = input(:,1);
            Iinput = ((input(:,2)*10^9) /electrode_surface_area) / chl_nM(j);
            intensity = intensities(i,j); 
            start_time = start_times(i,j); 
            light_on = light_on_times(i,j);
            light_off = light_off_times(i,j);
            end_time = end_times(i,j);
            linear_baseline = linear_baselines(i,j);
            
        for k = 1:no_scans;
            
            Cottrell_Solver_Baseliner_Chrono %Calls baselining function
            
            C03_T_Oxygen(:,((j-1)*no_scans)+k+1,i) =  Iplot_baseline_corrected;
            C03_T_Oxygen_dark_currents(i,((j-1)*no_scans)+k) = dark_current;
            C03_T_Oxygen_photocurrents(i,((j-1)*no_scans)+k) = photocurrent;
            C03_T_Oxygen_spike_charges(i,((j-1)*no_scans)+k) = spike_charge;
            C03_T_Oxygen_dip_charges(i,((j-1)*no_scans)+k) = dip_charge;
            
            start_time = start_time+spacing_time; 
            light_on = light_on+spacing_time;
            light_off = light_off+spacing_time;
            end_time = end_time+spacing_time;
            
        end
    end
end

%% Averaging and calculating percentage changes;

%Averaging scans
for l = 1:no_replicates;
    C03_T_Oxygen(:,(no_scans*no_replicates)+1+l,:) = mean(C03_T_Oxygen(:,((l-1)*no_scans)+2:((l-1)*no_scans)+no_scans+1,:),2);
    C03_T_Oxygen_dark_currents(:,(no_scans*no_replicates)+l) = mean(C03_T_Oxygen_dark_currents(:,((l-1)*no_scans)+1:((l-1)*no_scans)+no_scans),2);
    C03_T_Oxygen_photocurrents(:,(no_scans*no_replicates)+l) = mean(C03_T_Oxygen_photocurrents(:,((l-1)*no_scans)+1:((l-1)*no_scans)+no_scans),2);
    C03_T_Oxygen_spike_charges(:,(no_scans*no_replicates)+l) = mean(C03_T_Oxygen_spike_charges(:,((l-1)*no_scans)+1:((l-1)*no_scans)+no_scans),2);
    C03_T_Oxygen_dip_charges(:,(no_scans*no_replicates)+l) = mean(C03_T_Oxygen_dip_charges(:,((l-1)*no_scans)+1:((l-1)*no_scans)+no_scans),2);
end


%Averaging replicates and calculating errors

if std_or_se == 0;
    error_normaliser = 1;
else
    error_normaliser = sqrt(no_replicates);
end

C03_T_Oxygen(:,(no_scans*no_replicates)+no_replicates+2,:) = mean(C03_T_Oxygen(:,(no_scans*no_replicates)+2:(no_scans*no_replicates)+no_replicates+1,:),2);
C03_T_Oxygen(:,(no_scans*no_replicates)+no_replicates+3,:) = std(C03_T_Oxygen(:,(no_scans*no_replicates)+2:(no_scans*no_replicates)+no_replicates+1,:),0,2)/error_normaliser;
C03_T_Oxygen_dark_currents(:,(no_scans*no_replicates)+no_replicates+1) = mean(C03_T_Oxygen_dark_currents(:,(no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates),2);
C03_T_Oxygen_dark_currents(:,(no_scans*no_replicates)+no_replicates+2) = std(C03_T_Oxygen_dark_currents(:,(no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates),0,2)/error_normaliser;
C03_T_Oxygen_photocurrents(:,(no_scans*no_replicates)+no_replicates+1) = mean(C03_T_Oxygen_photocurrents(:,(no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates),2);
C03_T_Oxygen_photocurrents(:,(no_scans*no_replicates)+no_replicates+2) = std(C03_T_Oxygen_photocurrents(:,(no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates),0,2)/error_normaliser;
C03_T_Oxygen_spike_charges(:,(no_scans*no_replicates)+no_replicates+1) = mean(C03_T_Oxygen_spike_charges(:,(no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates),2);
C03_T_Oxygen_spike_charges(:,(no_scans*no_replicates)+no_replicates+2) = std(C03_T_Oxygen_spike_charges(:,(no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates),0,2)/error_normaliser;
C03_T_Oxygen_dip_charges(:,(no_scans*no_replicates)+no_replicates+1) = mean(C03_T_Oxygen_dip_charges(:,(no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates),2);
C03_T_Oxygen_dip_charges(:,(no_scans*no_replicates)+no_replicates+2) = std(C03_T_Oxygen_dip_charges(:,(no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates),0,2)/error_normaliser;

%Calculating relative changes to parameters

C03_T_Oxygen_dark_currents_relative(1,1:no_replicates) = 0;
C03_T_Oxygen_dark_currents_relative(2:no_conditions,1:no_replicates) = (C03_T_Oxygen_dark_currents(2:end,no_scans*no_replicates+1:(no_scans*no_replicates)+no_replicates) - C03_T_Oxygen_dark_currents(1,no_scans*no_replicates+1:(no_scans*no_replicates)+no_replicates));
C03_T_Oxygen_photocurrents_relative(1,1:no_replicates) = 100;
C03_T_Oxygen_photocurrents_relative(2:no_conditions,1:no_replicates) = (C03_T_Oxygen_photocurrents(2:end,no_scans*no_replicates+1:(no_scans*no_replicates)+no_replicates) ./ C03_T_Oxygen_photocurrents(1,no_scans*no_replicates+1:(no_scans*no_replicates)+no_replicates)) *100;
C03_T_Oxygen_spike_charges_relative(1,1:no_replicates) = 100;
C03_T_Oxygen_spike_charges_relative(2:no_conditions,1:no_replicates) = (C03_T_Oxygen_spike_charges(2:end,no_scans*no_replicates+1:(no_scans*no_replicates)+no_replicates) ./ C03_T_Oxygen_spike_charges(1,no_scans*no_replicates+1:(no_scans*no_replicates)+no_replicates)) *100;
C03_T_Oxygen_dip_charges_relative(1,1:no_replicates) = 100;
C03_T_Oxygen_dip_charges_relative(2:no_conditions,1:no_replicates) = (C03_T_Oxygen_dip_charges(2:end,no_scans*no_replicates+1:(no_scans*no_replicates)+no_replicates) ./ C03_T_Oxygen_dip_charges(1,no_scans*no_replicates+1:(no_scans*no_replicates)+no_replicates)) *100;

%Averaging replicates and calculating errors of relative measurements

C03_T_Oxygen_dark_currents_relative(:,no_replicates+1) = mean(C03_T_Oxygen_dark_currents_relative(:,1:no_replicates),2);
C03_T_Oxygen_dark_currents_relative(:,no_replicates+2) = std(C03_T_Oxygen_dark_currents_relative(:,1:no_replicates),0,2)/error_normaliser;
C03_T_Oxygen_photocurrents_relative(:,no_replicates+1) = mean(C03_T_Oxygen_photocurrents_relative(:,1:no_replicates),2);
C03_T_Oxygen_photocurrents_relative(:,no_replicates+2) = std(C03_T_Oxygen_photocurrents_relative(:,1:no_replicates),0,2)/error_normaliser;
C03_T_Oxygen_spike_charges_relative(:,no_replicates+1) = mean(C03_T_Oxygen_spike_charges_relative(:,1:no_replicates),2);
C03_T_Oxygen_spike_charges_relative(:,no_replicates+2) = std(C03_T_Oxygen_spike_charges_relative(:,1:no_replicates),0,2)/error_normaliser;
C03_T_Oxygen_dip_charges_relative(:,no_replicates+1) = mean(C03_T_Oxygen_dip_charges_relative(:,1:no_replicates),2);
C03_T_Oxygen_dip_charges_relative(:,no_replicates+2) = std(C03_T_Oxygen_dip_charges_relative(:,1:no_replicates),0,2)/error_normaliser;

%Significance testing

all_combinations = nchoosek(1:no_conditions,2);

for n = 1:height(all_combinations);
    [h_photocurrents(n),p_photocurrents(n)] = ttest2(C03_T_Oxygen_photocurrents(all_combinations(n,1),no_replicates*no_scans+1:no_replicates*no_scans+no_replicates),C03_T_Oxygen_photocurrents(all_combinations(n,2),no_replicates*no_scans+1:no_replicates*no_scans+no_replicates));
    [h_spike_charges(n),p_spike_charges(n)] = ttest2(C03_T_Oxygen_spike_charges(all_combinations(n,1),no_replicates*no_scans+1:no_replicates*no_scans+no_replicates),C03_T_Oxygen_spike_charges(all_combinations(n,2),no_replicates*no_scans+1:no_replicates*no_scans+no_replicates));
end

%% Plotting Chronoampeormetry Curve
close all

%Plotting curves
for m = no_conditions:-1:1;
    
    p_C03_T_Oxygen(m) = shadedErrorBar(C03_T_Oxygen(:,1),C03_T_Oxygen(:,(no_scans*no_replicates)+no_replicates+2,m),C03_T_Oxygen(:,(no_scans*no_replicates)+no_replicates+3,m),'lineProps',{'LineWidth',2.5,'color',colors(m,:)});
    if m == 1;
        legend('AutoUpdate','off')
        leg = legend([p_C03_T_Oxygen.mainLine],condition_names,'location','northeast');
        legend box off
    else
    end
    hold on
    
end

%Graph limits
max_current = ceil(max(max(C03_T_Oxygen(:,(no_scans*no_replicates)+no_replicates+2,:))));
max_current_range = (ceil(max_current*10^-(numel(num2str(abs(max_current)))-1))) * 10^(numel(num2str(abs(max_current)))-1);

x_lower = 0;
x_upper = xtime(end);
y_lower = -2-alter_y_axis(1);
y_upper = max_current_range+alter_y_axis(2); 

xlim([x_lower x_upper])
ylim([y_lower y_upper]);

%Adding annotations
onbox = area([light_on_times(1)-start_times(1) light_off_times(1)-start_times(1)],[y_upper y_upper]);
onbox.BaseValue = y_lower;
onbox.FaceColor = [1 1 1];
onbox.EdgeColor = 'none';
uistack(onbox,'bottom');
hold on

%Plot Formatting
box off
xlabel({'Time (seconds)'});
ylabel({'Photocurrent Density (nA [nmol Chl \ita\rm]^{-1} cm^{-2})'});
h = gca;
h.Color = [0.8 0.8 0.8];
h.XMinorTick = 'on';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1;
set(h ,'Layer', 'Top');
hold off

% Scaling and saving image
pbaspect([1 1.3 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_Oxygen_Curve','svg')


%% Absolute changes

%Photocurrent
for m = 1:no_conditions;
    bar_spacing = 1/no_conditions/1.2;
    
        p_C03_T_Oxygen_photocurrents_bar(m) = bar((m-1)*bar_spacing,C03_T_Oxygen_photocurrents(m,end-1),'BarWidth',bar_spacing*0.9,'FaceColor',colors(m,:),'LineWidth',1);
        hold on
        p_C03_T_Oxygen_photocurrents_error(m) = errorbar((m-1)*bar_spacing,C03_T_Oxygen_photocurrents(m,end-1),C03_T_Oxygen_photocurrents(m,end),'.','Color','k','LineWidth',1);
        hold on   

end

significant_index_photocurrents = find(p_photocurrents<0.05);
sig_bar_positions_photocurrents = num2cell((all_combinations(significant_index_photocurrents,:)*bar_spacing)-bar_spacing,2)';
sig_p_values_photocurrents = p_photocurrents(significant_index_photocurrents);
p_C03_T_AllDarkTimes_photocurrents_sigstar = sigstar(sig_bar_positions_photocurrents,sig_p_values_photocurrents,1);


xlim([0-(bar_spacing/1.5) ((m-1)*bar_spacing)+(bar_spacing/1.5)])
h = gca;

if normalise_chl == 1;
    y_lab = ylabel({'Steady State Photocurrent (nA [nmol Chl \ita\rm]^{-1} cm^{-2})'},'VerticalAlignment', 'bottom');
else
    y_lab = ylabel({'Steady State Photocurrent (nA cm^{-2})'},'VerticalAlignment', 'bottom');
end

box off
h.XTick = [((1:no_conditions)-1)*bar_spacing];
h.XTickLabel = condition_names;
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1;
hold on

% Scaling and saving image
pbaspect([0.5 1.5 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 320, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_Oxygen_Pc','svg')

hold off

%% 
%Spike charge
for m = 1:no_conditions;
    bar_spacing = 1/no_conditions/1.2;
    
        p_C03_T_Oxygen_spike_charges_bar(m) = bar((m-1)*bar_spacing,C03_T_Oxygen_spike_charges(m,end-1)./1000,'BarWidth',bar_spacing*0.9,'FaceColor',colors(m,:),'LineWidth',1);
        hold on
        p_C03_T_Oxygen_spike_charges_error(m) = errorbar((m-1)*bar_spacing,C03_T_Oxygen_spike_charges(m,end-1)./1000,C03_T_Oxygen_spike_charges(m,end)./1000,'.','Color','k','LineWidth',1);
        hold on   

end

significant_index_spike_charges = find(p_spike_charges<0.05);
sig_bar_positions_spike_charges = num2cell((all_combinations(significant_index_spike_charges,:)*bar_spacing)-bar_spacing,2)';
sig_p_values_spike_charges = p_spike_charges(significant_index_spike_charges);
p_C03_T_AllDarkTimes_spike_charges_sigstar = sigstar(sig_bar_positions_spike_charges,sig_p_values_spike_charges,1);

h = gca;
xlim([0-(bar_spacing/1.5) ((m-1)*bar_spacing)+(bar_spacing/1.5)])

if normalise_chl == 1;
    y_lab = ylabel({'Spike Charge Density (\muC [nmol Chl \ita\rm]^{-1} cm^{-2})'});
else
    y_lab = ylabel({'Spike Charge Density (\muC cm^{-2})'});
end

box off
h.XTick = [((1:no_conditions)-1)*bar_spacing];
h.XTickLabel = condition_names;
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1;
hold on

% Scaling and saving image
pbaspect([0.5 1.5 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 320, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_Oxygen_Sp','svg')

hold off

