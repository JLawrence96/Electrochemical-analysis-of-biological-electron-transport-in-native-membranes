%% Chronoamperommetry Synechocystis_ind thylakoids
% Dependencies: shadedErrorBar.m, Minimiser_Baseliner.m,Cottrell_Solver_Baseline_C

%% Data Input 

% Input Parameters
no_replicates = 3; %How many biolgical replicates per condition
no_scans = 3; %How many scans should be averaged

% Fitting Conditions
intensities = [5 5 5]; %Computing intensities for curve fitting
start_times = [125 125 125]; %Start time of first scan
light_on_times = [130 130 130]; %Time at which first light period starts
light_off_times = [190 190 190]; %Time at which first dark period starts
end_times = [250 250 250]; %End time of first scan
linear_baselines = [1 1 1]; %0 = fits dark current with cottrel equation, 1 = fits dark current with straight line.
light_stabilisation_time = 30; %Point at which photocurrent reaches steady-state
dark_stabilisation_time = 45; %Point at which dark current reaches steady-state
spike_stabilisation_time = 15; %Point at which light current reaches steady state, normally 15 seconds
spacing_time = 120; %space between scans
radius = 5000; %radius of spherical electrode (um). Assumes porous electrodes are 1000x single pore radius.  
sampling_rate = 0.1; %sampling reate of chronoamp data
electrode_surface_area = 0.75; %Surface area of electrode in cm^2

%Normalisation options
normalise_chl = 1;
std_or_se = 1; %0 for standard deviation, 1 for standard error

%Plotting options
xtime = (0.1:0.1:125)'; %Time range of x axis, should be end_time - start_time
load NatureColours.mat
colors = [greens([4 3 2],:) ; blues(3,:) ; oranges(3,:) ; purples(3,:)]; %Select colours to use. Number of colours should equal number of concentrations
condition_names = ["Replicate 1" "Replicate 2" "Replicate 3"];
alter_y_axis = [2 0]; %Will alter lower and upper bounds of graph y axis. + is extend, - contract. First position for lower and second for upper bound. 


%Data information
directory_name = ""; %Ensure all files are stored in the same directory
file_names = ["C03_T_O1" "C03_T_Q3" "C03_T_O3"];
file_extension = ".ascii";
chl_nM = [20.63384121 31.16073985 18.3380814]; %For chlorophyll normalisation. Set as an array of 1s for each dataset if no normalisation is required.

%% Processing
C03_T_Synechocystis_ind(:,1) = 0.1:0.1:490;
C03_T_Synechocystis_ind_baseline(:,1) = xtime;

for j = 1:no_replicates;   
    
    input = dlmread(append(directory_name,file_names(j),file_extension));
    tinput = input(:,1);
    Iinput = ((input(:,2)*10^9) /electrode_surface_area);
    
    C03_T_Synechocystis_ind(:,j+1) = ((input(1:4900,2)*10^9)./electrode_surface_area)+(1600*j);
    
    intensity = intensities(j); 
    start_time = start_times(j); 
    light_on = light_on_times(j);
    light_off = light_off_times(j);
    end_time = end_times(j);
    linear_baseline = linear_baselines(j);
    
    for k = 1:no_scans;   
              
        Cottrell_Solver_Baseliner_Chrono %Calls baselining function

        C03_T_Synechocystis(:,((j-1)*no_scans)+k+1) =  Iplot_baseline_corrected;
        C03_T_Synechocystis_dark_currents(((j-1)*no_scans)+k) = dark_current;
        C03_T_Synechocystis_photocurrents(((j-1)*no_scans)+k) = photocurrent;
        C03_T_Synechocystis_spike_charges(((j-1)*no_scans)+k) = spike_charge;
        C03_T_Synechocystis_dip_charges(((j-1)*no_scans)+k) = dip_charge;
        
        start_time = start_time+spacing_time; 
        light_on = light_on+spacing_time;
        light_off = light_off+spacing_time;
        end_time = end_time+spacing_time;

        C03_T_Synechocystis_ind_baseline(:,k,j) = optim_guess+(1600*j);

    end
        
end
 


%% Plotting Chronoampeormetry Curve
close all

%Plotting curves
for j = 1:no_replicates 
    p_C03_T_Synechocystis_ind(j) = plot(C03_T_Synechocystis_ind(:,1),C03_T_Synechocystis_ind(:,(j+1)), 'LineWidth',2.5,'color',colors(j,:));
    hold on
end

legend('AutoUpdate','off')
legend([p_C03_T_Synechocystis_ind(no_replicates:-1:1)],condition_names,'location','northeast');
legend box off

for j = 1:no_replicates;
    for k = 1:no_scans;
        p_C03_T_Synechocystis_ind_baseline(j,k) = plot((xtime + (k * 120)),C03_T_Synechocystis_ind_baseline(:,k,j),':', 'LineWidth',1.5,'color',colors(k+no_replicates,:));
        hold on
    end
end

%Graph limits
xlim([0 490])
ylim([1400 7400]);

%Adding annotations
boxtimes = [10 70];
for m = 1:no_scans+1
    
    onbox = area([boxtimes(1) boxtimes(2)],[7400 7400]);
    onbox.BaseValue = 1400;
    onbox.FaceColor = [1 1 1];
    onbox.EdgeColor = 'none';
    uistack(onbox,'bottom');
    hold on

    boxtimes = boxtimes + spacing_time;

end

%Plot Formatting
box off
xlabel({'Time (s)'});
ylabel({'Photocurrent Density (nA cm^{-2})',''});
h = gca;
% h.YAxis.Visible = 'off';
h.Color = [0.8 0.8 0.8];
h.XMinorTick = 'on';
h.YMinorTick = 'on';
h.YTickLabel = [];
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1;
set(h ,'Layer', 'Top');
hold off

% Scaling and saving image
pbaspect([2 1 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [0, 0, 1200, 680])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_Averaging_Curve','svg')
