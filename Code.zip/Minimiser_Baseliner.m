% Cottrell Solver
% Dimensionless Parameter Minimiser

function Minimiser_Baseliner(tdata,Idata,rad) %I only feed in time, current and electrode radius, and then solve lambda and diffusion coefficient. 

initial_guess=[rand(1) rand(1)];
options=optimset('TolFun', 1e-15, 'MaxIter', 1e100000, 'MaxfunEvals', 1e1000); %This should be plenty
param_min=fminsearch(@fitting, initial_guess, options);

assignin('base','lambda_value',param_min(1))
assignin('base','D_value',param_min(2))

function data=cottrell_sphere(lambda, D, tdata,rad) %This is the cotterel equation function
        data=lambda * D *(((pi * D * tdata).^-1/2) + (rad^-1)); %This is the spherical treatment of the cotterel function, so change that to the standard treatment. 
end
    
 function error2=fitting(param_guess) %This is the error fitting function
        lambda_guess=param_guess(1); 
        D_guess=param_guess(2);
        simulation=cottrell_sphere(lambda_guess, D_guess, tdata, rad);
        error2=round((sum((simulation-Idata).^2)),5);
        assignin('base','error_value',error2);
 end


end

%Once the code has finished running please remember to save the final
%optimised parameters (e.g. D_findal = D_guess after the function). 