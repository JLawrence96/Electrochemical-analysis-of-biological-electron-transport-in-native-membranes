% Linear_Baseliner_JTS

%% Input processing

light_on_index = find(round(tinput-light_on,1)==0);
light_off_index = light_on_index + (light_time / sampling_rate);
start_time_index = light_on_index - (preequilibration_time / sampling_rate);
end_time_index = light_on_index + (experiment_time / sampling_rate);
plotting_index = start_time_index:end_time_index;
baselining_index = [start_time_index:light_on_index end_time_index-(experiment_time-light_time-dark_stabilisation_time)/sampling_rate:end_time_index];

zeroed_start_time_index = start_time_index - start_time_index(1) + 1;
zeroed_light_on_index = light_on_index - start_time_index(1) + 1;
zeroed_light_off_index = light_off_index - start_time_index(1) + 1;
zeroed_end_time_index = end_time_index - start_time_index(1) + 1;

tdata = tinput(baselining_index);
tdata = tdata-tdata(1)+sampling_rate;
Idata = Iinput(baselining_index);
Idata = Idata;
 
tplot = tinput(plotting_index);
tplot = tplot-tplot(1)+sampling_rate;
Iplot = Iinput(plotting_index);
Iplot = Iplot;

%% Curve Fitting

linear_baseline = @(a,x) a(1)*x + a(2);

linear_fit_params = lsqcurvefit(linear_baseline,zeros(2,1),tdata,Idata);
optim_guess = linear_baseline(linear_fit_params,tplot);


%% Baselining and Plotting

Iplot_baseline_corrected = (Iplot-optim_guess);
    
subplot(1,2,1);
plot(tplot,Iplot);
hold on
plot(tplot,optim_guess);
hold on

subplot(1,2,2);
plot(tplot,Iplot_baseline_corrected);
hold on
