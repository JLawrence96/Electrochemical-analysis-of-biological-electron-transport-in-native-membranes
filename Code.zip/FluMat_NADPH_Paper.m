%% Fluoresecence Matrices
% Dependencies: heatmap.m

%% Data Input
Excitations = 200:5:800; 
Emissions = 800:-5:200; 
FluMat_NADPH = csvread("FluMat_LysisNADPH.csv");
FluMat_NADPH = flip(FluMat_NADPH);

colors = brewermap(1000,['YlOrBr']);
% %% Plotting Soluble Fraction
% close all
% 
% p_FluMat_NADPH = heatmap(FluMat_NADPH,Excitations,Emissions,[],'MaxColorValue',30,'Colormap',colors,'ColorBar',1)
% 
% box off 
% 
% pbaspect([1 1 1]);
% set(gcf, 'Position',  [100, 100, 1000, 1000])
% 
% xlabel({' ','Excitation Wavelength (nm)'})
% ylabel({'Emission Wavelength (nm)',' '})
% 
% h = gca;
% h.XTick = 1:20:121
% h.XTickLabel = [200:100:800];
% h.YTick = 1:20:121
% h.YTickLabel = [800:-100:200];
% 
% h.TickDir = 'out';
% h.FontName = 'Helvetica Ltd Std';
% h.FontSize = 25;
% h.LineWidth = 2.5;
% 
% c = colorbar;
% c.FontSize = 25;
% c.Box = 'off';
% c.TickLength = 0;
% c.LineWidth = 0.00001;
% 
% set(gcf, 'InvertHardCopy', 'off');
% saveas(gcf,'FluMat_NADPH_30max','svg')
% 
% %% Plotting Soluble Fraction # 2
% close all
% 
% p_FluMat_NADPH = heatmap(FluMat_NADPH,Excitations,Emissions,[],'MaxColorValue',15,'Colormap',colors,'ColorBar',1)
% 
% box off 
% 
% pbaspect([1 1 1]);
% set(gcf, 'Position',  [100, 100, 1000, 1000])
% 
% xlabel({' ','Excitation Wavelength (nm)'})
% ylabel({'Emission Wavelength (nm)',' '})
% 
% h = gca;
% h.XTick = 1:20:121
% h.XTickLabel = [200:100:800];
% h.YTick = 1:20:121
% h.YTickLabel = [800:-100:200];
% 
% h.TickDir = 'out';
% h.FontName = 'Helvetica Ltd Std';
% h.FontSize = 25;
% h.LineWidth = 2.5;
% 
% c = colorbar;
% c.FontSize = 25;
% c.Box = 'off';
% c.TickLength = 0;
% c.LineWidth = 0.00001;
% 
% set(gcf, 'InvertHardCopy', 'off');
% saveas(gcf,'FluMat_NADPH_15max','svg')

%% Plotting Soluble Fraction
close all

p_FluMat_NADPH = heatmap(FluMat_NADPH,Excitations,Emissions,[],'MinColorValue',1,'MaxColorValue',20,'Colormap',colors,'ColorBar',1)

box off 

box off 
% xlim([5 111])
ylim([11 111])

xlabel({'Excitation Wavelength (nm)'})
ylabel({'Emission Wavelength (nm)'})

h = gca;
h.XTick = 21:20:101
h.XTickLabel = [300:100:700];
h.YTick = 21:20:121
h.YTickLabel = [800:-100:300];
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1;

c = colorbar;
c.FontSize = 17;
c.Box = 'off';
c.TickLength = 0;
c.LineWidth = 0.00001;

% Scaling and saving image
pbaspect([1 1.5 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'FluMat_NADPH','svg')