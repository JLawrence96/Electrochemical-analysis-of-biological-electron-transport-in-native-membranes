%% Chronoamperommetry Thylakoid Membranes + NADPH_DarkTime
% Dependencies: shadedErrorBar.m, Minimiser_Baseliner.m,Cottrell_Solver_Baseline_C

%% Data Input 

% Input Parameters
no_darktimes = 6; %How many conditions will be compared
no_replicates = 3; %How many biolgical replicates per condition
no_scans = 3; %How many scans should be averaged
times_s = [10 30 60 120 300 600]; %Potentials tested in mV, including repeat potentials.
time_units = "s";

% Fitting Conditions
intensities = [5 5 5 5 5 5 ; 5 5 5 5 5 5 ; 5 5 5 5 5 5]; %Computing intensities for curve fitting
start_times = [75 415 845 2085 3005 5585; 75 415 815 1375 2355 4335 ; 75 395 805 1365 2305 4095]; %Start time of first scan
light_on_times = [80 420 850 2090 3010 5590 ; 80 420 820 1380 2360 4340 ; 80 400 810 1370 2310 4100]; %Time at which first light period starts
light_off_times = [140 480 910 2150 3070 5650 ; 140 480 880 1440 2420 4400 ; 140 460 870 1430 2370 4160]; %Time at which first dark period starts
end_times = [150 510 970 2270 3370 6250 ; 150 510 940 1560 2720 5000 ; 150 490 930 1550 2670 4760]; %End time of first scan
linear_baselines = [1 1 1 1 1 1 ; 1 1 1 1 1 1 ; 1 1 1 1 1 1]; %0 = fits dark current with cottrel equation, 1 = fits dark current with straight line.
light_stabilisation_time = 50; %Point at which photocurrent reaches steady-state
dark_stabilisation_times = [9 25 45 45 45 45]; %Point at which dark current reaches steady-state
spike_stabilisation_time = 15; %Point at which light current reaches steady state, normally 15 seconds
spacing_time = [70 90 120 180 360 660]; %space between scans
radius = 5000; %radius of spherical electrode (um). Assumes porous electrodes are 1000x single pore radius.  
sampling_rate = 0.1; %sampling reate of chronoamp data
electrode_surface_area = 0.75; %Surface area of electrode in cm^2

%Normalisation options
normalise_chl = 1;
std_or_se = 1; %0 for standard deviation, 1 for standard error

%Plotting options
xtime = (0.1:0.1:665)';
load NatureColours.mat
colors = [greens(1:6,:)]; %Select colours to use. Number of colours should equal number of concentrations
alter_x_axis = [0 -540]; %Will alter lower and upper bounds of graph y axis. + is extend, - contract. First position for lower and second for upper bound. 
alter_y_axis = [-2 45]; %Will alter lower and upper bounds of graph y axis. + is extend, - contract. First position for lower and second for upper bound. 

%Data information
directory_name = ""; %Ensure all files are stored in the same directory
file_names = ["C03D_DCMU700_N2" "C03D_DCMU700_O1" "C03D_DCMU700_O3"];
file_extension = ".ascii";
chl_nM = [19.906 22.566 16.462]; %For chlorophyll normalisation. Set as an array of 1s for each dataset if no normalisation is required.

%% Processing
C03_T_DarkTime = NaN(length(xtime),(no_replicates*no_scans)+no_replicates+3,no_darktimes);

for i = 1:no_darktimes;
    
        C03_T_DarkTime(:,1,i) = xtime;
        
    for j = 1:no_replicates;
                    
            input = dlmread(append(directory_name,file_names(j),file_extension));
            tinput = input(:,1);
            Iinput = ((input(:,2)*10^9) /electrode_surface_area) / chl_nM(j);
            intensity = intensities(j,i); 
            start_time = start_times(j,i); 
            light_on = light_on_times(j,i);
            light_off = light_off_times(j,i);
            end_time = end_times(j,i);
            linear_baseline = linear_baselines(j,i);
            dark_stabilisation_time = dark_stabilisation_times(i); %Point at which dark current reaches steady-state 

        for k = 1:no_scans;
            
            Cottrell_Solver_Baseliner_Chrono %Calls baselining function
            
            C03_T_DarkTime(1:length(Iplot_baseline_corrected),((j-1)*no_scans)+k+1,i) =  Iplot_baseline_corrected;
            C03_T_DarkTime_dark_currents(i,((j-1)*no_scans)+k) = dark_current;
            C03_T_DarkTime_photocurrents(i,((j-1)*no_scans)+k) = photocurrent;
            C03_T_DarkTime_spike_charges(i,((j-1)*no_scans)+k) = spike_charge;
            C03_T_DarkTime_dip_charges(i,((j-1)*no_scans)+k) = dip_charge;
            
            start_time = start_time+spacing_time(i); 
            light_on = light_on+spacing_time(i);
            light_off = light_off+spacing_time(i);
            end_time = end_time+spacing_time(i);
            
        end
    end
end

%% Averaging and calculating percentage changes;

%Averaging scans
for l = 1:no_replicates;
    C03_T_DarkTime(:,(no_scans*no_replicates)+1+l,:) = mean(C03_T_DarkTime(:,((l-1)*no_scans)+2:((l-1)*no_scans)+no_scans+1,:),2);
    C03_T_DarkTime_dark_currents(:,(no_scans*no_replicates)+l) = mean(C03_T_DarkTime_dark_currents(:,((l-1)*no_scans)+1:((l-1)*no_scans)+no_scans),2);
    C03_T_DarkTime_photocurrents(:,(no_scans*no_replicates)+l) = mean(C03_T_DarkTime_photocurrents(:,((l-1)*no_scans)+1:((l-1)*no_scans)+no_scans),2);
    C03_T_DarkTime_spike_charges(:,(no_scans*no_replicates)+l) = mean(C03_T_DarkTime_spike_charges(:,((l-1)*no_scans)+1:((l-1)*no_scans)+no_scans),2);
    C03_T_DarkTime_dip_charges(:,(no_scans*no_replicates)+l) = mean(C03_T_DarkTime_dip_charges(:,((l-1)*no_scans)+1:((l-1)*no_scans)+no_scans),2);
end


%Averaging replicates and calculating errors

if std_or_se == 0;
    error_normaliser = 1;
else
    error_normaliser = sqrt(no_replicates);
end

C03_T_DarkTime(:,(no_scans*no_replicates)+no_replicates+2,:) = mean(C03_T_DarkTime(:,(no_scans*no_replicates)+2:(no_scans*no_replicates)+no_replicates+1,:),2);
C03_T_DarkTime(:,(no_scans*no_replicates)+no_replicates+3,:) = std(C03_T_DarkTime(:,(no_scans*no_replicates)+2:(no_scans*no_replicates)+no_replicates+1,:),0,2)/error_normaliser;
C03_T_DarkTime_dark_currents(:,(no_scans*no_replicates)+no_replicates+1) = mean(C03_T_DarkTime_dark_currents(:,(no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates),2);
C03_T_DarkTime_dark_currents(:,(no_scans*no_replicates)+no_replicates+2) = std(C03_T_DarkTime_dark_currents(:,(no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates),0,2)/error_normaliser;
C03_T_DarkTime_photocurrents(:,(no_scans*no_replicates)+no_replicates+1) = mean(C03_T_DarkTime_photocurrents(:,(no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates),2);
C03_T_DarkTime_photocurrents(:,(no_scans*no_replicates)+no_replicates+2) = std(C03_T_DarkTime_photocurrents(:,(no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates),0,2)/error_normaliser;
C03_T_DarkTime_spike_charges(:,(no_scans*no_replicates)+no_replicates+1) = mean(C03_T_DarkTime_spike_charges(:,(no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates),2);
C03_T_DarkTime_spike_charges(:,(no_scans*no_replicates)+no_replicates+2) = std(C03_T_DarkTime_spike_charges(:,(no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates),0,2)/error_normaliser;
C03_T_DarkTime_dip_charges(:,(no_scans*no_replicates)+no_replicates+1) = mean(C03_T_DarkTime_dip_charges(:,(no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates),2);
C03_T_DarkTime_dip_charges(:,(no_scans*no_replicates)+no_replicates+2) = std(C03_T_DarkTime_dip_charges(:,(no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates),0,2)/error_normaliser;

%Averaging replicates and calculating errors of relative measurements

C03_T_DarkTime_dark_currents(:,no_replicates+1) = mean(C03_T_DarkTime_dark_currents(:,1:no_replicates),2);
C03_T_DarkTime_dark_currents(:,no_replicates+2) = std(C03_T_DarkTime_dark_currents(:,1:no_replicates),0,2)/error_normaliser;
C03_T_DarkTime_photocurrents(:,no_replicates+1) = mean(C03_T_DarkTime_photocurrents(:,1:no_replicates),2);
C03_T_DarkTime_photocurrents(:,no_replicates+2) = std(C03_T_DarkTime_photocurrents(:,1:no_replicates),0,2)/error_normaliser;
C03_T_DarkTime_spike_charges(:,no_replicates+1) = mean(C03_T_DarkTime_spike_charges(:,1:no_replicates),2);
C03_T_DarkTime_spike_charges(:,no_replicates+2) = std(C03_T_DarkTime_spike_charges(:,1:no_replicates),0,2)/error_normaliser;
C03_T_DarkTime_dip_charges(:,no_replicates+1) = mean(C03_T_DarkTime_dip_charges(:,1:no_replicates),2);
C03_T_DarkTime_dip_charges(:,no_replicates+2) = std(C03_T_DarkTime_dip_charges(:,1:no_replicates),0,2)/error_normaliser;

%% Plotting Chronoampeormetry Curve
close all

%Plotting curves
for m = 1:no_darktimes;
    condition_names(m) = append(num2str(times_s(m))," ",time_units);
    
    p_C03_T_DarkTime(m) = shadedErrorBar(C03_T_DarkTime(:,1),C03_T_DarkTime(:,(no_scans*no_replicates)+no_replicates+2,m),C03_T_DarkTime(:,(no_scans*no_replicates)+no_replicates+3,m),'lineProps',{'LineWidth',2.5,'color',colors(m,:)});
    if m == no_darktimes;
        legend('AutoUpdate','off')
        leg = legend([p_C03_T_DarkTime.mainLine],condition_names,'location','northeast');
        tit = title(leg,'                  Dark Adaptation Time:')
        legend box off
    else
    end
    hold on
    
end

tit.FontWeight = 'normal';
% tit.FontName = 'Helvetica Ltd Std';
% tit.FontSize = 17;

%Graph limits
max_current = ceil(max(max(C03_T_DarkTime(:,(no_scans*no_replicates)+no_replicates+2,:))));
max_current_range = (ceil(max_current*10^-(numel(num2str(abs(max_current)))-1))) * 10^(numel(num2str(abs(max_current)))-1);

x_lower = 0 + alter_x_axis(1);
x_upper = xtime(end) + alter_x_axis(2);
y_lower = -2 + alter_y_axis(1);
y_upper = max_current_range+5 + alter_y_axis(2);

xlim([x_lower x_upper])
ylim([y_lower y_upper]);

%Adding annotations
onbox = area([light_on_times(1)-start_times(1) light_off_times(1)-start_times(1)],[y_upper+100 y_upper+100]);
onbox.BaseValue = y_lower-100;
onbox.FaceColor = [1 1 1];
onbox.EdgeColor = 'none';
uistack(onbox,'bottom');
hold on

%Plot Formatting
box off
xlabel({'Time (s)'});
ylabel({'Photocurrent Density (nA [nmol Chl \ita\rm]^{-1} cm^{-2})'});
h = gca;
h.Color = [0.8 0.8 0.8];
h.XMinorTick = 'on';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1;
set(h ,'Layer', 'Top');

% Scaling and saving image
pbaspect([1 1.3 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_DarkTime_Curve','svg')

xlim([4 15]);
ylim([-2 45]);
pbaspect([1 1.3 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_DarkTime_CurveZoom','svg')

xlim([63 85]);
ylim([-3 10]);
pbaspect([1 1.3 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_DarkTime_CurveZoom2','svg')

%% Plotting absolute changes
close all

% subplot(1,3,1)
p_C03_T_DarkTime_dark_currents = errorbar(times_s,C03_T_DarkTime_dark_currents(:,end-1),C03_T_DarkTime_dark_currents(:,end),'Color',colors(round(no_darktimes/2),:),'LineWidth',2.5);
xlabel({append("Dark Adaptation Time (",time_units,")")});
if normalise_chl == 1;
    ylabel({'Dark Current Density',' (nA [nmol Chl \ita\rm]^{-1} cm^{-2})'});
else
    ylabel({'Dark Current Density',' (nA cm^{-2})'});
end
box off
 
xlim([0 times_s(end)])
% ylim([0 150])    
    
h = gca;
h.XAxis.TickLength = [0.005 0.005];
h.XMinorTick = 'off';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1;
hold off

% Scaling and saving image
pbaspect([1 1.3 1]);
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_DarkTimeDc','svg')

% subplot(1,3,2)
p_C03_T_DarkTime_photocurrents = errorbar(times_s,C03_T_DarkTime_photocurrents(:,end-1),C03_T_DarkTime_photocurrents(:,end),'Color',colors(round(no_darktimes/2),:),'LineWidth',2.5);
xlabel({append("Dark Adaptation Time (",time_units,")")});
if normalise_chl == 1;
    ylabel({'Steady State Photocurrent Density (nA [nmol Chl \ita\rm]^{-1} cm^{-2})'});
else
    ylabel({'Steady State Photocurrent Density (nA cm^{-2})'});
end
box off
 
xlim([0 times_s(end)])
% ylim([0 150])    
    
h = gca;
h.XAxis.TickLength = [0.005 0.005];
h.XMinorTick = 'off';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1;
hold off

% Scaling and saving image
pbaspect([1 1.3 1]);
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_DarkTimePc','svg')


% subplot(1,3,3)
p_C03_T_DarkTime_spike_charges = errorbar(times_s,C03_T_DarkTime_spike_charges(:,end-1)./1000,C03_T_DarkTime_spike_charges(:,end)./1000,'Color',colors(round(no_darktimes/2),:),'LineWidth',2.5);
xlabel({append("Dark Adaptation Time (",time_units,")")});
if normalise_chl == 1;
    ylabel({'Spike Charge Density (\muC [nmol Chl \ita\rm]^{-1} cm^{-2})'});
else
    ylabel({'Spike Charge Density (\muC cm^{-2})'});
end
box off
 
xlim([0 times_s(end)])
% ylim([0 150])    
    
h = gca;
h.XAxis.TickLength = [0.005 0.005];
h.XMinorTick = 'off';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1;
hold off

% Scaling and saving image
pbaspect([1 1.3 1]);
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_DarkTimeSp','svg')

% subplot(2,2,4)
p_C03_T_DarkTime_dip_charges = errorbar(times_s,C03_T_DarkTime_dip_charges(:,end-1),C03_T_DarkTime_dip_charges(:,end),'Color',colors(round(no_darktimes/2),:),'LineWidth',2.5);
xlabel({append("Dark Adaptation Time (",time_units,")")});
if normalise_chl == 1;
    ylabel({'Dip Charge Density',' (\muC [nmol Chl \ita\rm]^{-1} cm^{-2})'});
else
    ylabel({'Dip Charge Density',' (\muC cm^{-2})'});
end
box off
 
xlim([0 times_s(end)])
% ylim([0 150])    
    
h = gca;
h.XAxis.TickLength = [0.005 0.005];
h.XMinorTick = 'off';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1;
hold off

% Scaling and saving image
pbaspect([1 1.3 1]);
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_DarkTimeDi','svg')

