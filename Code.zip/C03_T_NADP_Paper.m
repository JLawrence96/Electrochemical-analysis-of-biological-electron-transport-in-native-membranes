%% Chronoamperommetry Thylakoid Membranes + NADP
% Dependencies: shadedErrorBar.m, Minimiser_Baseliner.m,Cottrell_Solver_Baseline_C

%% Data Input 

% Input Parameters
no_concentrations = 6; %How many conditions will be compared
no_replicates = 3; %How many biolgical replicates per condition
no_scans = 3; %How many scans should be averaged
concentrations_uM = [0 0.01 0.1 0.5 1 5]; %Potentials tested in mV, including repeat potentials.
chemical_units = "mM";

% Fitting Conditions
intensities = [5 5 5 5 5 5 ; 4.9 5 5 5 5 5 ; 5 5 5 5 5 5]; %Computing intensities for curve fitting
start_times = [125 125 125 125 124.9 125 ; 125 125 125 125 125 124.9 ; 125 125 125 125 125 124.8]; %Start time of first scan
light_on_times = [130 130 130 130 129.9 130 ; 130 130 130 130 130 129.9 ; 130 130 130 130 130 129.8]; %Time at which first light period starts
light_off_times = [190 190 190 190 189.9 190 ; 190 190 190 190 190 189.9 ; 190 190 190 190 190 189.8]; %Time at which first dark period starts
end_times = [250 250 250 250 249.9 250 ; 250 250 250 250 250 249.9 ; 250 250 250 250 250 249.8]; %End time of first scan
linear_baselines = [1 1 1 1 1 1 ; 1 1 1 1 1 1 ; 1 1 1 1 1 1]; %0 = fits dark current with cottrel equation, 1 = fits dark current with straight line.
light_stabilisation_time = 30; %Point at which photocurrent reaches steady-state
dark_stabilisation_time = 45; %Point at which dark current reaches steady-state
spike_stabilisation_time = 15; %Point at which light current reaches steady state, normally 15 seconds
spacing_time = 120; %space between scans
radius = 5000; %radius of spherical electrode (um). Assumes porous electrodes are 1000x single pore radius.  
sampling_rate = 0.1; %sampling reate of chronoamp data
electrode_surface_area = 0.75; %Surface area of electrode in cm^2

%Normalisation options
normalise_chl = 1;
std_or_se = 1; %0 for standard deviation, 1 for standard error

%Plotting options
xtime = (0.1:0.1:125)'; %Time range of x axis, should be end_time - start_time
load NatureColours.mat
colors = [greens]; %Select colours to use. Number of colours should equal number of concentrations
parameter_colors = [purples(3,:) ; oranges(3,:)];
alter_x_axis = [0 0]; %Will alter lower and upper bounds of graph y axis. + is extend, - contract. First position for lower and second for upper bound. 
alter_y_axis = [0 15]; %Will alter lower and upper bounds of graph y axis. + is extend, - contract. First position for lower and second for upper bound. 
relative_param_scale = [0 270];

%Data information
directory_name = ""; %Ensure all files are stored in the same directory
file_names = ["C03_T+NADP_NC1" "C03_T+NADP_NC2" "C03_T+NADP_NC3"];
file_extension = ".ascii";
chl_nM = [13.439 14.027 17.554]; %For chlorophyll normalisation. Set as an array of 1s for each dataset if no normalisation is required.
chemical_name = "NADP^{+}";

%% Processing
for i = 1:no_concentrations;
    
        C03_T_NADP(:,1,i) = xtime;
        
    for j = 1:no_replicates;
                    
            input = dlmread(append(directory_name,file_names(j),"_",num2str(i),file_extension));
            tinput = input(:,1);
            Iinput = ((input(:,2)*10^9) /electrode_surface_area) / chl_nM(j);
            intensity = intensities(j,i); 
            start_time = start_times(j,i); 
            light_on = light_on_times(j,i);
            light_off = light_off_times(j,i);
            end_time = end_times(j,i);
            linear_baseline = linear_baselines(j,i);
            
        for k = 1:no_scans;
            
            Cottrell_Solver_Baseliner_Chrono %Calls baselining function
            
            C03_T_NADP(:,((j-1)*no_scans)+k+1,i) =  Iplot_baseline_corrected;
            C03_T_NADP_dark_currents(i,((j-1)*no_scans)+k) = dark_current;
            C03_T_NADP_photocurrents(i,((j-1)*no_scans)+k) = photocurrent;
            C03_T_NADP_spike_charges(i,((j-1)*no_scans)+k) = spike_charge;
            C03_T_NADP_dip_charges(i,((j-1)*no_scans)+k) = dip_charge;
            
            start_time = start_time+spacing_time; 
            light_on = light_on+spacing_time;
            light_off = light_off+spacing_time;
            end_time = end_time+spacing_time;
            
        end
    end
end

%% Averaging and calculating percentage changes;

%Averaging scans
for l = 1:no_replicates;
    C03_T_NADP(:,(no_scans*no_replicates)+1+l,:) = mean(C03_T_NADP(:,((l-1)*no_scans)+2:((l-1)*no_scans)+no_scans+1,:),2);
    C03_T_NADP_dark_currents(:,(no_scans*no_replicates)+l) = mean(C03_T_NADP_dark_currents(:,((l-1)*no_scans)+1:((l-1)*no_scans)+no_scans),2);
    C03_T_NADP_photocurrents(:,(no_scans*no_replicates)+l) = mean(C03_T_NADP_photocurrents(:,((l-1)*no_scans)+1:((l-1)*no_scans)+no_scans),2);
    C03_T_NADP_spike_charges(:,(no_scans*no_replicates)+l) = mean(C03_T_NADP_spike_charges(:,((l-1)*no_scans)+1:((l-1)*no_scans)+no_scans),2);
    C03_T_NADP_dip_charges(:,(no_scans*no_replicates)+l) = mean(C03_T_NADP_dip_charges(:,((l-1)*no_scans)+1:((l-1)*no_scans)+no_scans),2);
end


%Averaging replicates and calculating errors

if std_or_se == 0;
    error_normaliser = 1;
else
    error_normaliser = sqrt(no_replicates);
end

C03_T_NADP(:,(no_scans*no_replicates)+no_replicates+2,:) = mean(C03_T_NADP(:,(no_scans*no_replicates)+2:(no_scans*no_replicates)+no_replicates+1,:),2);
C03_T_NADP(:,(no_scans*no_replicates)+no_replicates+3,:) = std(C03_T_NADP(:,(no_scans*no_replicates)+2:(no_scans*no_replicates)+no_replicates+1,:),0,2)/error_normaliser;
C03_T_NADP_dark_currents(:,(no_scans*no_replicates)+no_replicates+1) = mean(C03_T_NADP_dark_currents(:,(no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates),2);
C03_T_NADP_dark_currents(:,(no_scans*no_replicates)+no_replicates+2) = std(C03_T_NADP_dark_currents(:,(no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates),0,2)/error_normaliser;
C03_T_NADP_photocurrents(:,(no_scans*no_replicates)+no_replicates+1) = mean(C03_T_NADP_photocurrents(:,(no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates),2);
C03_T_NADP_photocurrents(:,(no_scans*no_replicates)+no_replicates+2) = std(C03_T_NADP_photocurrents(:,(no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates),0,2)/error_normaliser;
C03_T_NADP_spike_charges(:,(no_scans*no_replicates)+no_replicates+1) = mean(C03_T_NADP_spike_charges(:,(no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates),2);
C03_T_NADP_spike_charges(:,(no_scans*no_replicates)+no_replicates+2) = std(C03_T_NADP_spike_charges(:,(no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates),0,2)/error_normaliser;
C03_T_NADP_dip_charges(:,(no_scans*no_replicates)+no_replicates+1) = mean(C03_T_NADP_dip_charges(:,(no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates),2);
C03_T_NADP_dip_charges(:,(no_scans*no_replicates)+no_replicates+2) = std(C03_T_NADP_dip_charges(:,(no_scans*no_replicates)+1:(no_scans*no_replicates)+no_replicates),0,2)/error_normaliser;

%Calculating relative changes to parameters

C03_T_NADP_dark_currents_relative(1,1:no_replicates) = 0;
C03_T_NADP_dark_currents_relative(2:no_concentrations,1:no_replicates) = (C03_T_NADP_dark_currents(2:end,no_scans*no_replicates+1:(no_scans*no_replicates)+no_replicates) - C03_T_NADP_dark_currents(1,no_scans*no_replicates+1:(no_scans*no_replicates)+no_replicates));
C03_T_NADP_photocurrents_relative(1,1:no_replicates) = 100;
C03_T_NADP_photocurrents_relative(2:no_concentrations,1:no_replicates) = (C03_T_NADP_photocurrents(2:end,no_scans*no_replicates+1:(no_scans*no_replicates)+no_replicates) ./ C03_T_NADP_photocurrents(1,no_scans*no_replicates+1:(no_scans*no_replicates)+no_replicates)) *100;
C03_T_NADP_spike_charges_relative(1,1:no_replicates) = 100;
C03_T_NADP_spike_charges_relative(2:no_concentrations,1:no_replicates) = (C03_T_NADP_spike_charges(2:end,no_scans*no_replicates+1:(no_scans*no_replicates)+no_replicates) ./ C03_T_NADP_spike_charges(1,no_scans*no_replicates+1:(no_scans*no_replicates)+no_replicates)) *100;
C03_T_NADP_dip_charges_relative(1,1:no_replicates) = 100;
C03_T_NADP_dip_charges_relative(2:no_concentrations,1:no_replicates) = (C03_T_NADP_dip_charges(2:end,no_scans*no_replicates+1:(no_scans*no_replicates)+no_replicates) ./ C03_T_NADP_dip_charges(1,no_scans*no_replicates+1:(no_scans*no_replicates)+no_replicates)) *100;

%Averaging replicates and calculating errors of relative measurements

C03_T_NADP_dark_currents_relative(:,no_replicates+1) = mean(C03_T_NADP_dark_currents_relative(:,1:no_replicates),2);
C03_T_NADP_dark_currents_relative(:,no_replicates+2) = std(C03_T_NADP_dark_currents_relative(:,1:no_replicates),0,2)/error_normaliser;
C03_T_NADP_photocurrents_relative(:,no_replicates+1) = mean(C03_T_NADP_photocurrents_relative(:,1:no_replicates),2);
C03_T_NADP_photocurrents_relative(:,no_replicates+2) = std(C03_T_NADP_photocurrents_relative(:,1:no_replicates),0,2)/error_normaliser;
C03_T_NADP_spike_charges_relative(:,no_replicates+1) = mean(C03_T_NADP_spike_charges_relative(:,1:no_replicates),2);
C03_T_NADP_spike_charges_relative(:,no_replicates+2) = std(C03_T_NADP_spike_charges_relative(:,1:no_replicates),0,2)/error_normaliser;
C03_T_NADP_dip_charges_relative(:,no_replicates+1) = mean(C03_T_NADP_dip_charges_relative(:,1:no_replicates),2);
C03_T_NADP_dip_charges_relative(:,no_replicates+2) = std(C03_T_NADP_dip_charges_relative(:,1:no_replicates),0,2)/error_normaliser;

concentrations_plot = [concentrations_uM(2)/5 ; concentrations_uM(2:end)'];

%% Plotting Chronoampeormetry Curve
close all

%Plotting curves
for m = 1:no_concentrations;
    chemical_names(m) = append(num2str(concentrations_uM(m))," ",chemical_units);
    
    p_C03_T_NADP(m) = shadedErrorBar(C03_T_NADP(:,1),C03_T_NADP(:,end-1,m),C03_T_NADP(:,end,m),'lineProps',{'LineWidth',2.5,'color',colors(m,:)});
    if m == no_concentrations;
        legend('AutoUpdate','off')
        leg = legend([p_C03_T_NADP.mainLine],chemical_names,'location','northeast');
        legend box off
    else
    end
    hold on
    
end

%Graph limits
max_current = ceil(max(max(C03_T_NADP(:,(no_scans*no_replicates)+no_replicates+2,:))));
max_current_range = (ceil(max_current*10^-(numel(num2str(abs(max_current)))-1))) * 10^(numel(num2str(abs(max_current)))-1);

x_lower = 0 + alter_x_axis(1);
x_upper = xtime(end) + alter_x_axis(2);
y_lower = -2 - alter_y_axis(1);
y_upper = max_current_range+5 + alter_y_axis(2);

xlim([x_lower x_upper])
ylim([y_lower y_upper]);

%Adding annotations
onbox = area([light_on_times(1)-start_times(1) light_off_times(1)-start_times(1)],[y_upper y_upper]);
onbox.BaseValue = y_lower;
onbox.FaceColor = [1 1 1];
onbox.EdgeColor = 'none';
uistack(onbox,'bottom');
hold on

%Plot Formatting
box off
xlabel({'Time (seconds)'});
ylabel({'Photocurrent Density (nA [nmol Chl \ita\rm]^{-1} cm^{-2})'});
h = gca;
h.Color = [0.8 0.8 0.8];
h.XMinorTick = 'on';
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1;
set(h ,'Layer', 'Top');
hold off

% Scaling and saving image
pbaspect([1 1.3 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 500, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_NADP_Curve','svg')

%% Plotting absolute changes
close all

yyaxis left
p_C03_T_NADP_photocurrents = errorbar(concentrations_plot,C03_T_NADP_photocurrents(:,end-1),C03_T_NADP_photocurrents(:,end),'Color',parameter_colors(1,:),'LineWidth',2.5);
if normalise_chl == 1;
    ylabel({'Steady State Photocurrent (nA [nmol Chl \ita\rm]^{-1} cm^{-2})'});
else
    ylabel({'Steady State Photocurrent (nA cm^{-2})'});
end
hold on

yyaxis right
p_C03_T_NADP_spike_charges = errorbar(concentrations_plot,C03_T_NADP_spike_charges(:,end-1),C03_T_NADP_spike_charges(:,end),'Color',parameter_colors(2,:),'LineWidth',2.5);
if normalise_chl == 1;
    ylabel({'Spike Charge (nC [nmol Chl \ita\rm]^{-1} cm^{-2})'});
else
    ylabel({'Spike Charge (nC cm^{-2})'});
end
hold on

box off
xlabel({append("[",chemical_name,"]"," (",chemical_units,")")});
xlim([concentrations_plot(1)-concentrations_plot(1)/11 concentrations_plot(end)+(concentrations_plot(end)/5)])

set(gca,'xscale','log')
h = gca;
text(concentrations_plot(1)*1.205,h.YLim(1),'//','Color','black','FontSize',17); %inserting break symbols
h.XTick = [0.01 0.1 1];
h.XTickLabel = [0.01 0.1 1];
h.YAxis(1).Color = parameter_colors(1,:);
h.YAxis(2).Color = parameter_colors(2,:)
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1.5;
hold off

% Scaling and saving image
pbaspect([1 1.3 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 600, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_NADP_AbsoluteParameters','svg')


%% Plotting relative changes
close all

yyaxis left
p_C03_T_NADP_photocurrents_relative = errorbar(concentrations_plot,C03_T_NADP_photocurrents_relative(:,end-1),C03_T_NADP_photocurrents_relative(:,end),'Color',parameter_colors(1,:),'LineWidth',2.5);
if normalise_chl == 1;
    ylabel({'\DeltaSteady State Photocurrent (%)'});
else
    ylabel({'Steady State Photocurrent (%)'});
end
ylim(relative_param_scale)
hold on

yyaxis right
p_C03_T_NADP_spike_charges_relative = errorbar(concentrations_plot,C03_T_NADP_spike_charges_relative(:,end-1),C03_T_NADP_spike_charges_relative(:,end),'Color',parameter_colors(2,:),'LineWidth',2.5);
if normalise_chl == 1;
    ylabel({'\DeltaSpike Charge (%)'});
else
    ylabel({'\DeltaSpike Charge (%)'});
end
ylim(relative_param_scale)
hold on

box off
xlabel({append("[",chemical_name,"]"," (",chemical_units,")")});
xlim([concentrations_plot(1)-concentrations_plot(1)/11 concentrations_plot(end)+(concentrations_plot(end)/5)])

set(gca,'xscale','log')
h = gca;
text(concentrations_plot(1)*1.205,h.YLim(1),'//','Color','black','FontSize',17); %inserting break symbols
h.XTick = [0.01 0.1 1];
h.XTickLabel = [0.01 0.1 1];
h.YAxis(1).Color = parameter_colors(1,:);
h.YAxis(2).Color = parameter_colors(2,:)
h.YMinorTick = 'on';
h.TickDir = 'out';
h.FontName = 'Helvetica Ltd Std';
h.FontSize = 17;
h.LineWidth = 1.5;
hold off

% Scaling and saving image
pbaspect([1 1.3 1]);
set(gcf, 'Renderer', 'painter');
set(gcf,'color','w');
set(gcf, 'Position',  [100, 100, 600, 600])
set(gcf, 'InvertHardCopy', 'off');
saveas(gcf,'C03_T_NADP_RelativeParameters','svg')

